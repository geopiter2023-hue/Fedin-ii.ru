import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { localCourses } from "@/lib/courseData";
import { useNavigate } from "react-router";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  LayoutDashboard,
  BookOpen,
  Users,
  Key,
  MessageSquare,
  Mail,
  Sparkles,
  Trash2,
  Plus,
  RefreshCw,
  ArrowLeft,
  Newspaper,
  CheckCircle,
  XCircle,
  Eye,
  Save,
  X,
  Bot,
} from "lucide-react";

const tabs = [
  { id: "dashboard", label: "Обзор", icon: LayoutDashboard },
  { id: "courses", label: "Курсы", icon: BookOpen },
  { id: "lessons", label: "Уроки", icon: BookOpen },
  { id: "users", label: "Пользователи", icon: Users },
  { id: "keys", label: "Ключи доступа", icon: Key },
  { id: "reviews", label: "Отзывы", icon: MessageSquare },
  { id: "emails", label: "Подписки", icon: Mail },
  { id: "ai", label: "AI Генерация", icon: Bot },
  { id: "news", label: "Новости", icon: Newspaper },
];

// Demo data for offline mode
const demoStats = { courses: 22, users: 156, lessons: 230, purchases: 89, reviews: 45, keys: 12, emails: 234, news: 18 };
const demoUsers = [
  { id: 1, name: "Иван Петров", email: "ivan@example.com", role: "user", createdAt: new Date(), source: "local" },
  { id: 2, name: "Мария Сидорова", email: "maria@example.com", role: "admin", createdAt: new Date(), source: "oauth" },
  { id: 3, name: "Алексей Иванов", email: "alex@example.com", role: "user", createdAt: new Date(), source: "local" },
];
const demoKeys = [
  { id: 1, code: "NEUROTEST2025", type: "test" as const, usesCount: 15, maxUses: 100, isActive: true },
  { id: 2, code: "ADMIN999", type: "lifetime" as const, usesCount: 1, maxUses: 999, isActive: true },
];
const demoReviews = [
  { id: 1, userName: "Анна", rating: 5, text: "Отличные курсы, очень понятно!" },
  { id: 2, userName: "Павел", rating: 4, text: "Много полезной информации" },
];
const demoEmails = [
  { id: 1, email: "user1@mail.ru", name: "User 1", isActive: true },
  { id: 2, email: "user2@gmail.com", name: "User 2", isActive: true },
];
const demoNews = [
  { id: 1, title: "OpenAI запустил GPT-5", source: "Habr AI", category: "AI", publishedAt: new Date() },
  { id: 2, title: "Новый Midjourney v7", source: "Habr AI", category: "AI", publishedAt: new Date() },
];

// Demo mode detection — function (not constant) so it re-checks localStorage each render
const isDemoMode = () => localStorage.getItem("local_auth_token") === "demo_admin_token";

export default function Admin() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("dashboard");

  if (isLoading && !isDemoMode()) {
    return (
      <div className="min-h-screen bg-[#0A0A0F] text-white flex items-center justify-center">
        <RefreshCw className="w-8 h-8 animate-spin text-[#8B5CF6]" />
      </div>
    );
  }

  if ((!user || user.role !== "admin") && !isDemoMode()) {
    return (
      <div className="min-h-screen bg-[#0A0A0F] text-white flex items-center justify-center">
        <Card className="bg-[#12121A] border-white/[0.06] max-w-md">
          <CardContent className="p-8 text-center">
            <XCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">Доступ запрещён</h2>
            <p className="text-slate-400 mb-4">
              Эта страница доступна только администраторам.
            </p>
            <Button
              onClick={() => navigate("/")}
              className="gradient-bg text-white"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              На главную
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0F] text-white">
      {/* Header */}
      <div className="border-b border-white/[0.06] px-4 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl gradient-bg flex items-center justify-center">
              <LayoutDashboard className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold">Админ панель</h1>
                {isDemoMode() && (
                  <Badge className="bg-purple-500/20 text-purple-400 text-xs">ДЕМО РЕЖИМ</Badge>
                )}
              </div>
              <p className="text-xs text-slate-500">
                Управление НейроУниверситетом
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/")}
            className="text-slate-400 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4 mr-1" />
            На сайт
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto flex">
        {/* Sidebar */}
        <aside className="w-56 shrink-0 border-r border-white/[0.06] min-h-[calc(100vh-73px)]">
          <nav className="p-2 space-y-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm transition-all ${
                  activeTab === tab.id
                    ? "bg-[#8B5CF6]/20 text-[#8B5CF6] font-medium"
                    : "text-slate-400 hover:text-white hover:bg-white/[0.04]"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </nav>
        </aside>

        {/* Content */}
        <main className="flex-1 p-6">
          {activeTab === "dashboard" && <DashboardTab />}
          {activeTab === "courses" && <CoursesTab />}
          {activeTab === "lessons" && <LessonsTab />}
          {activeTab === "users" && <UsersTab />}
          {activeTab === "keys" && <KeysTab />}
          {activeTab === "reviews" && <ReviewsTab />}
          {activeTab === "emails" && <EmailsTab />}
          {activeTab === "ai" && <AIGenTab />}
          {activeTab === "news" && <NewsTab />}
        </main>
      </div>
    </div>
  );
}

// ===== DASHBOARD =====
function DashboardTab() {
  const { data: apiStats } = trpc.admin.stats.useQuery();
  const stats = apiStats ?? (isDemoMode() ? demoStats : null);
  const openAll = trpc.admin.openAllCourses.useMutation({
    onSuccess: () => alert("Все курсы открыты для тестирования!"),
  });

  const cards = [
    { label: "Курсов", value: stats?.courses ?? 0, icon: BookOpen, color: "text-purple-400" },
    { label: "Пользователей", value: stats?.users ?? 0, icon: Users, color: "text-cyan-400" },
    { label: "Уроков", value: stats?.lessons ?? 0, icon: BookOpen, color: "text-emerald-400" },
    { label: "Покупок", value: stats?.purchases ?? 0, icon: CheckCircle, color: "text-green-400" },
    { label: "Отзывов", value: stats?.reviews ?? 0, icon: MessageSquare, color: "text-yellow-400" },
    { label: "Ключей", value: stats?.keys ?? 0, icon: Key, color: "text-orange-400" },
    { label: "Подписок", value: stats?.emails ?? 0, icon: Mail, color: "text-pink-400" },
    { label: "Новостей", value: stats?.news ?? 0, icon: Newspaper, color: "text-blue-400" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Обзор системы</h2>
        <Button
          onClick={() => openAll.mutate()}
          className="bg-emerald-600 hover:bg-emerald-700"
          disabled={openAll.isPending}
        >
          <Eye className="w-4 h-4 mr-2" />
          {openAll.isPending ? "Открываем..." : "Открыть все курсы для теста"}
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {cards.map((card) => (
          <Card
            key={card.label}
            className="bg-[#12121A] border-white/[0.06]"
          >
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-slate-500 text-sm">{card.label}</p>
                  <p className="text-3xl font-bold mt-1">{card.value}</p>
                </div>
                <card.icon className={`w-8 h-8 ${card.color} opacity-60`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ===== COURSES =====
function CoursesTab() {
  const utils = trpc.useUtils();
  const { data: apiCoursesList, isLoading } = trpc.admin.courseList.useQuery();
  const coursesList = apiCoursesList ?? (isDemoMode() ? localCourses.map(c => ({...c, id: Number(c.id), createdAt: new Date()})) : []);
  const createCourse = trpc.admin.courseCreate.useMutation({
    onSuccess: () => {
      utils.admin.courseList.invalidate();
      setShowForm(false);
      setForm({ title: "", slug: "", description: "", price: "0", category: "База", level: "beginner" });
    },
  });
  const deleteCourse = trpc.admin.courseDelete.useMutation({
    onSuccess: () => utils.admin.courseList.invalidate(),
  });

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<{
    title: string;
    slug: string;
    description: string;
    price: string;
    category: string;
    level: "beginner" | "intermediate" | "advanced";
  }>({
    title: "",
    slug: "",
    description: "",
    price: "0",
    category: "База",
    level: "beginner",
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Управление курсами</h2>
        <Button
          onClick={() => setShowForm(!showForm)}
          className="gradient-bg text-white"
        >
          <Plus className="w-4 h-4 mr-2" />
          Новый курс
        </Button>
      </div>

      {showForm && (
        <Card className="bg-[#12121A] border-white/[0.06]">
          <CardContent className="p-5 space-y-3">
            <h3 className="font-semibold">Создать курс</h3>
            <div className="grid grid-cols-2 gap-3">
              <Input
                placeholder="Название"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                className="bg-[#0A0A0F] border-white/[0.06]"
              />
              <Input
                placeholder="Slug (URL)"
                value={form.slug}
                onChange={(e) => setForm({ ...form, slug: e.target.value })}
                className="bg-[#0A0A0F] border-white/[0.06]"
              />
            </div>
            <Textarea
              placeholder="Описание"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="bg-[#0A0A0F] border-white/[0.06]"
            />
            <div className="grid grid-cols-3 gap-3">
              <Input
                placeholder="Цена"
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })}
                className="bg-[#0A0A0F] border-white/[0.06]"
              />
              <Select
                value={form.category}
                onValueChange={(v) => setForm({ ...form, category: v })}
              >
                <SelectTrigger className="bg-[#0A0A0F] border-white/[0.06]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {["База", "Для работы", "Продвинутый", "Специальные навыки", "Новинки 2025"].map(
                    (c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    )
                  )}
                </SelectContent>
              </Select>
              <Select
                value={form.level}
                onValueChange={(v) => setForm({ ...form, level: v as "beginner" | "intermediate" | "advanced" })}
              >
                <SelectTrigger className="bg-[#0A0A0F] border-white/[0.06]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[
                    { val: "beginner", label: "Начинающий" },
                    { val: "intermediate", label: "Средний" },
                    { val: "advanced", label: "Продвинутый" },
                  ].map((l) => (
                    <SelectItem key={l.val} value={l.val}>
                      {l.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => createCourse.mutate(form)}
                disabled={!form.title || !form.slug || createCourse.isPending}
                className="gradient-bg text-white"
              >
                <Save className="w-4 h-4 mr-2" />
                Создать
              </Button>
              <Button
                variant="ghost"
                onClick={() => setShowForm(false)}
                className="text-slate-400"
              >
                <X className="w-4 h-4 mr-2" />
                Отмена
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {isLoading ? (
        <div className="text-center py-8 text-slate-500">Загрузка...</div>
      ) : (
        <div className="space-y-2">
          {coursesList?.map((course) => (
            <Card
              key={course.id}
              className="bg-[#12121A] border-white/[0.06]"
            >
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold">{course.title}</h3>
                    <Badge
                      variant={course.isPublished ? "default" : "secondary"}
                      className={
                        course.isPublished
                          ? "bg-emerald-500/20 text-emerald-400"
                          : "bg-slate-500/20 text-slate-400"
                      }
                    >
                      {course.isPublished ? "Опубликован" : "Черновик"}
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-500">
                    {course.slug} | {course.category} | {course.level} |{" "}
                    {course.price} ₽
                  </p>
                </div>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() =>
                      deleteCourse.mutate({ id: course.id })
                    }
                    className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// ===== LESSONS =====
function LessonsTab() {
  const utils = trpc.useUtils();
  const { data: coursesList } = trpc.admin.courseList.useQuery();
  const [selectedCourse, setSelectedCourse] = useState<number>(0);
  const { data: lessonsList } = trpc.admin.lessonList.useQuery(
    selectedCourse ? { courseId: selectedCourse } : undefined
  );

  const createLesson = trpc.admin.lessonCreate.useMutation({
    onSuccess: () => {
      utils.admin.lessonList.invalidate();
      setShowForm(false);
    },
  });
  const deleteLesson = trpc.admin.lessonDelete.useMutation({
    onSuccess: () => utils.admin.lessonList.invalidate(),
  });

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    courseId: 0,
    title: "",
    description: "",
    content: "",
    duration: "30:00",
    order: 1,
    isFree: false,
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Управление уроками</h2>
        <div className="flex gap-2">
          <Select
            value={String(selectedCourse)}
            onValueChange={(v) => setSelectedCourse(Number(v))}
          >
            <SelectTrigger className="w-64 bg-[#0A0A0F] border-white/[0.06]">
              <SelectValue placeholder="Выберите курс" />
            </SelectTrigger>
            <SelectContent>
              {coursesList?.map((c) => (
                <SelectItem key={c.id} value={String(c.id)}>
                  {c.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {selectedCourse > 0 && (
            <Button
              onClick={() => {
                setForm({ ...form, courseId: selectedCourse });
                setShowForm(true);
              }}
              className="gradient-bg text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Добавить урок
            </Button>
          )}
        </div>
      </div>

      {showForm && (
        <Card className="bg-[#12121A] border-white/[0.06]">
          <CardContent className="p-5 space-y-3">
            <h3 className="font-semibold">Новый урок</h3>
            <Input
              placeholder="Название урока"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="bg-[#0A0A0F] border-white/[0.06]"
            />
            <Textarea
              placeholder="Описание"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              className="bg-[#0A0A0F] border-white/[0.06]"
            />
            <Textarea
              placeholder="Контент урока (Markdown)"
              value={form.content}
              onChange={(e) => setForm({ ...form, content: e.target.value })}
              className="bg-[#0A0A0F] border-white/[0.06] min-h-[200px]"
            />
            <div className="grid grid-cols-3 gap-3">
              <Input
                placeholder="Длительность (30:00)"
                value={form.duration}
                onChange={(e) => setForm({ ...form, duration: e.target.value })}
                className="bg-[#0A0A0F] border-white/[0.06]"
              />
              <Input
                type="number"
                placeholder="Порядок"
                value={form.order}
                onChange={(e) => setForm({ ...form, order: Number(e.target.value) })}
                className="bg-[#0A0A0F] border-white/[0.06]"
              />
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={form.isFree}
                  onChange={(e) => setForm({ ...form, isFree: e.target.checked })}
                  className="rounded"
                />
                <span className="text-sm text-slate-400">Бесплатный</span>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => createLesson.mutate(form)}
                disabled={!form.title || createLesson.isPending}
                className="gradient-bg text-white"
              >
                <Save className="w-4 h-4 mr-2" />
                Сохранить
              </Button>
              <Button variant="ghost" onClick={() => setShowForm(false)} className="text-slate-400">
                <X className="w-4 h-4 mr-2" />
                Отмена
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-2">
        {lessonsList?.map((lesson) => (
          <Card key={lesson.id} className="bg-[#12121A] border-white/[0.06]">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-slate-500">#{lesson.order}</span>
                  <h3 className="font-medium">{lesson.title}</h3>
                  {lesson.isFree && (
                    <Badge className="bg-emerald-500/20 text-emerald-400">Бесплатно</Badge>
                  )}
                </div>
                <p className="text-sm text-slate-500">
                  {lesson.duration} | {lesson.description}
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => deleteLesson.mutate({ id: lesson.id })}
                className="text-red-400 hover:text-red-300"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ===== USERS =====
function UsersTab() {
  const { data: apiUsersList, isLoading } = trpc.admin.userList.useQuery();
  const usersList = apiUsersList ?? (isDemoMode() ? demoUsers : []);

  if (isLoading) return <div className="text-center py-8 text-slate-500">Загрузка...</div>;

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Пользователи</h2>
      <div className="space-y-2">
        {usersList?.map((u: any) => (
          <Card key={`${u.source}-${u.id}`} className="bg-[#12121A] border-white/[0.06]">
            <CardContent className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center text-sm font-bold">
                  {(u.name || "?")[0]?.toUpperCase()}
                </div>
                <div>
                  <h3 className="font-medium">{u.name || "Без имени"}</h3>
                  <p className="text-sm text-slate-500">
                    {u.email} | {u.source === "oauth" ? "Kimi" : "Email"} |{" "}
                    <Badge
                      className={
                        u.role === "admin"
                          ? "bg-purple-500/20 text-purple-400"
                          : "bg-slate-500/20 text-slate-400"
                      }
                    >
                      {u.role}
                    </Badge>
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ===== KEYS =====
function KeysTab() {
  const utils = trpc.useUtils();
  const { data: apiKeysList } = trpc.admin.keyList.useQuery();
  const keysList = apiKeysList ?? (isDemoMode() ? demoKeys : []);
  const createKey = trpc.admin.keyCreate.useMutation({
    onSuccess: () => {
      utils.admin.keyList.invalidate();
      setShowForm(false);
    },
  });
  const deleteKey = trpc.admin.keyDelete.useMutation({
    onSuccess: () => utils.admin.keyList.invalidate(),
  });

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ code: "", type: "test" as const, maxUses: 1 });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Ключи доступа</h2>
        <Button onClick={() => setShowForm(!showForm)} className="gradient-bg text-white">
          <Plus className="w-4 h-4 mr-2" />
          Создать ключ
        </Button>
      </div>

      {showForm && (
        <Card className="bg-[#12121A] border-white/[0.06]">
          <CardContent className="p-5 space-y-3">
            <div className="grid grid-cols-3 gap-3">
              <Input
                placeholder="Код ключа"
                value={form.code}
                onChange={(e) => setForm({ ...form, code: e.target.value })}
                className="bg-[#0A0A0F] border-white/[0.06]"
              />
              <Select
                value={form.type}
                onValueChange={(v: any) => setForm({ ...form, type: v })}
              >
                <SelectTrigger className="bg-[#0A0A0F] border-white/[0.06]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="test">Тестовый</SelectItem>
                  <SelectItem value="promo">Промо</SelectItem>
                  <SelectItem value="lifetime">Бессрочный</SelectItem>
                </SelectContent>
              </Select>
              <Input
                type="number"
                placeholder="Макс. использований"
                value={form.maxUses}
                onChange={(e) => setForm({ ...form, maxUses: Number(e.target.value) })}
                className="bg-[#0A0A0F] border-white/[0.06]"
              />
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => createKey.mutate(form)}
                disabled={!form.code}
                className="gradient-bg text-white"
              >
                <Save className="w-4 h-4 mr-2" />
                Создать
              </Button>
              <Button variant="ghost" onClick={() => setShowForm(false)} className="text-slate-400">
                Отмена
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-2">
        {keysList?.map((key) => (
          <Card key={key.id} className="bg-[#12121A] border-white/[0.06]">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <code className="text-cyan-400 font-mono font-bold">{key.code}</code>
                  <Badge
                    className={
                      key.type === "lifetime"
                        ? "bg-purple-500/20 text-purple-400"
                        : key.type === "promo"
                          ? "bg-orange-500/20 text-orange-400"
                          : "bg-blue-500/20 text-blue-400"
                    }
                  >
                    {key.type}
                  </Badge>
                  {key.isActive ? (
                    <Badge className="bg-emerald-500/20 text-emerald-400">Активен</Badge>
                  ) : (
                    <Badge className="bg-red-500/20 text-red-400">Неактивен</Badge>
                  )}
                </div>
                <p className="text-sm text-slate-500">
                  Использований: {key.usesCount} / {key.maxUses}
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => deleteKey.mutate({ id: key.id })}
                className="text-red-400"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ===== REVIEWS =====
function ReviewsTab() {
  const utils = trpc.useUtils();
  const { data: apiReviewsList } = trpc.admin.reviewList.useQuery();
  const reviewsList = apiReviewsList ?? (isDemoMode() ? demoReviews : []);
  const deleteReview = trpc.admin.reviewDelete.useMutation({
    onSuccess: () => utils.admin.reviewList.invalidate(),
  });

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Отзывы</h2>
      <div className="space-y-2">
        {reviewsList?.map((review: any) => (
          <Card key={review.id} className="bg-[#12121A] border-white/[0.06]">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-yellow-400">{"★".repeat(review.rating)}{"☆".repeat(5 - review.rating)}</span>
                  <span className="text-sm text-slate-500">{review.userName || "Аноним"}</span>
                </div>
                <p className="text-sm text-slate-300 mt-1">{review.text}</p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => deleteReview.mutate({ id: review.id })}
                className="text-red-400"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ===== EMAILS =====
function EmailsTab() {
  const { data: apiEmailList } = trpc.admin.emailList.useQuery();
  const emailList = apiEmailList ?? (isDemoMode() ? demoEmails : []);

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Email подписки</h2>
      <div className="space-y-2">
        {emailList?.map((sub: any) => (
          <Card key={sub.id} className="bg-[#12121A] border-white/[0.06]">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-slate-500" />
                <span className="font-medium">{sub.email}</span>
                <span className="text-sm text-slate-500">{sub.name}</span>
                <Badge
                  className={
                    sub.isActive
                      ? "bg-emerald-500/20 text-emerald-400"
                      : "bg-red-500/20 text-red-400"
                  }
                >
                  {sub.isActive ? "Активна" : "Отписан"}
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ===== AI GENERATION =====
function AIGenTab() {
  const [title, setTitle] = useState("");
  const [generated, setGenerated] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);

  const generate = trpc.admin.aiGenerateLesson.useMutation({
    onSuccess: (data) => {
      if (data.success && data.content) {
        setGenerated(data.content);
      }
      setIsGenerating(false);
    },
    onError: () => setIsGenerating(false),
  });

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">AI Генерация контента</h2>
      <p className="text-slate-400 text-sm">
        Введите тему урока — ИИ сгенерирует полноценный образовательный контент через DeepSeek.
      </p>

      <div className="flex gap-2">
        <Input
          placeholder="Тема урока (например: 'Нейросети в маркетинге')"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="bg-[#0A0A0F] border-white/[0.06] flex-1"
          onKeyDown={(e) => {
            if (e.key === "Enter" && title) {
              setIsGenerating(true);
              generate.mutate({ title });
            }
          }}
        />
        <Button
          onClick={() => {
            if (title) {
              setIsGenerating(true);
              generate.mutate({ title });
            }
          }}
          disabled={!title || isGenerating}
          className="gradient-bg text-white"
        >
          <Sparkles className="w-4 h-4 mr-2" />
          {isGenerating ? "Генерация..." : "Сгенерировать"}
        </Button>
      </div>

      {generated && (
        <Card className="bg-[#12121A] border-white/[0.06]">
          <CardHeader>
            <CardTitle className="text-sm flex items-center justify-between">
              <span>Сгенерированный контент</span>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => navigator.clipboard.writeText(generated)}
                className="text-slate-400"
              >
                Копировать
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="text-xs text-slate-300 whitespace-pre-wrap max-h-[600px] overflow-y-auto bg-[#0A0A0F] p-4 rounded-lg">
              {generated}
            </pre>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ===== NEWS =====
function NewsTab() {
  const utils = trpc.useUtils();
  const { data: apiNewsList } = trpc.admin.newsList.useQuery();
  const newsList = apiNewsList ?? (isDemoMode() ? demoNews : []);
  const deleteNews = trpc.admin.newsDelete.useMutation({
    onSuccess: () => utils.admin.newsList.invalidate(),
  });
  const syncNews = trpc.rss.sync.useQuery(undefined, { enabled: false });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">AI Новости</h2>
        <Button
          onClick={() => syncNews.refetch()}
          className="gradient-bg text-white"
        >
          <RefreshCw className="w-4 h-4 mr-2" />
          Синхронизировать RSS
        </Button>
      </div>
      <div className="space-y-2">
        {newsList?.map((news: any) => (
          <Card key={news.id} className="bg-[#12121A] border-white/[0.06]">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <h3 className="font-medium text-sm">{news.title}</h3>
                <p className="text-xs text-slate-500">
                  {news.source} | {news.category} |{" "}
                  {news.publishedAt
                    ? new Date(news.publishedAt).toLocaleDateString("ru-RU")
                    : ""}
                </p>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => deleteNews.mutate({ id: news.id })}
                className="text-red-400"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
