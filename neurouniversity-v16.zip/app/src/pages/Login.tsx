import { useState } from "react";
import { Link } from "react-router";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Brain,
  Key,
  Sparkles,
  BookOpen,
  Users,
  Award,
  Zap,
  CheckCircle,
  ArrowRight,
  LogIn,
  Gift,
} from "lucide-react";

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

const features = [
  { icon: BookOpen, text: "22 курса по нейросетям" },
  { icon: Users, text: "2500+ студентов" },
  { icon: Award, text: "Сертификаты о прохождении" },
  { icon: Zap, text: "Практические навыки без кода" },
];

const testKeys = [
  { code: "NEUROTEST2025", desc: "Полный доступ ко всем курсам" },
  { code: "STUDENT2025", desc: "Студенческий доступ" },
  { code: "BETA2025", desc: "Бета-тестирование" },
];

export default function Login() {
  const [keyInput, setKeyInput] = useState("");
  const [keyMessage, setKeyMessage] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  const handleKeySubmit = () => {
    const key = keyInput.trim().toUpperCase();
    const found = testKeys.find((k) => k.code === key);
    if (found) {
      setKeyMessage({
        type: "success",
        text: `Ключ «${key}» действующий! ${found.desc}. Войдите через Kimi, чтобы активировать.`,
      });
    } else {
      setKeyMessage({ type: "error", text: "Ключ не найден. Попробуйте один из ключей ниже." });
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0F] text-white">
      <div className="max-w-6xl mx-auto px-4 py-8 min-h-screen flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between mb-12">
          <Link to="/" className="flex items-center gap-2">
            <Brain className="w-8 h-8 text-[#8B5CF6]" />
            <span className="text-xl font-bold">
              Нейро<span className="gradient-text">Университет</span>
            </span>
          </Link>
          <Link
            to="/"
            className="text-sm text-slate-400 hover:text-white transition-colors flex items-center gap-1"
          >
            <ArrowRight className="w-4 h-4 rotate-180" />
            На главную
          </Link>
        </div>

        <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left — Info */}
          <div className="space-y-8">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
                Вход в <span className="gradient-text">НейроУниверситет</span>
              </h1>
              <p className="text-lg text-slate-400 leading-relaxed max-w-lg">
                Осваивайте нейросети вместе с тысячами студентов. Понятные курсы,
                AI-консультант, сертификаты и постоянные обновления.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {features.map((f, i) => (
                <div
                  key={i}
                  className="flex items-center gap-3 p-4 rounded-xl bg-[#12121A] border border-white/[0.06]"
                >
                  <div className="w-10 h-10 rounded-lg gradient-bg flex items-center justify-center shrink-0">
                    <f.icon className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-sm text-slate-300">{f.text}</span>
                </div>
              ))}
            </div>

            {/* Test keys info */}
            <Card className="bg-gradient-to-r from-purple-900/20 to-cyan-900/20 border-purple-500/20">
              <CardContent className="p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Gift className="w-5 h-5 text-purple-400" />
                  <h3 className="font-semibold text-white">Тестовые ключи доступа</h3>
                </div>
                <p className="text-sm text-slate-400 mb-4">
                  Уже есть ключ? Войдите в систему и активируйте его в дашборде.
                  Или попробуйте один из наших публичных ключей:
                </p>
                <div className="space-y-2">
                  {testKeys.map((k) => (
                    <div
                      key={k.code}
                      className="flex items-center justify-between bg-[#0A0A0F]/60 rounded-lg px-3 py-2"
                    >
                      <div>
                        <code className="text-cyan-400 text-sm font-mono font-bold">
                          {k.code}
                        </code>
                        <p className="text-slate-500 text-xs">{k.desc}</p>
                      </div>
                      <CheckCircle className="w-4 h-4 text-green-400" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right — Login form */}
          <div className="lg:pl-8">
            <Card className="bg-[#12121A] border-white/[0.06]">
              <CardContent className="p-8">
                {/* OAuth Login */}
                <div className="text-center mb-8">
                  <div className="w-16 h-16 rounded-full gradient-bg flex items-center justify-center mx-auto mb-4">
                    <LogIn className="w-8 h-8 text-white" />
                  </div>
                  <h2 className="text-2xl font-bold text-white mb-2">Войти в систему</h2>
                  <p className="text-sm text-slate-400">
                    Используйте ваш аккаунт Kimi для входа
                  </p>
                </div>

                <Button
                  className="w-full gradient-bg text-white hover:opacity-90 mb-6 py-6 text-base"
                  size="lg"
                  onClick={() => {
                    window.location.href = getOAuthUrl();
                  }}
                >
                  <Sparkles className="w-5 h-5 mr-2" />
                  Войти через Kimi
                </Button>

                {/* Divider */}
                <div className="flex items-center gap-4 mb-6">
                  <div className="flex-1 h-px bg-white/[0.06]" />
                  <span className="text-xs text-slate-500">или проверьте ключ</span>
                  <div className="flex-1 h-px bg-white/[0.06]" />
                </div>

                {/* Key check */}
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <Input
                      value={keyInput}
                      onChange={(e) => setKeyInput(e.target.value)}
                      placeholder="Введите тестовый ключ"
                      className="bg-[#0A0A0F] border-white/[0.06] text-white uppercase"
                      onKeyDown={(e) => e.key === "Enter" && handleKeySubmit()}
                    />
                    <Button
                      onClick={handleKeySubmit}
                      variant="outline"
                      className="border-[#8B5CF6]/30 text-[#8B5CF6] hover:bg-[#8B5CF6]/10"
                    >
                      <Key className="w-4 h-4" />
                    </Button>
                  </div>
                  {keyMessage && (
                    <div
                      className={`flex items-center gap-2 text-sm p-3 rounded-lg ${
                        keyMessage.type === "success"
                          ? "bg-green-500/10 text-green-400"
                          : "bg-red-500/10 text-red-400"
                      }`}
                    >
                      <CheckCircle className="w-4 h-4 shrink-0" />
                      {keyMessage.text}
                    </div>
                  )}
                </div>

                {/* Benefits */}
                <div className="mt-8 pt-6 border-t border-white/[0.06]">
                  <p className="text-xs text-slate-500 mb-3">После входа вы получите:</p>
                  <div className="space-y-2">
                    {[
                      "Доступ к бесплатным урокам",
                      "Возможность купить или активировать курсы",
                      "AI-консультант Нейра",
                      "Сертификаты и прогресс обучения",
                    ].map((item, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm text-slate-400">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        {item}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Browse without login */}
                <div className="mt-6 text-center">
                  <Link
                    to="/courses"
                    className="text-sm text-[#8B5CF6] hover:text-[#EC4899] transition-colors inline-flex items-center gap-1"
                  >
                    Смотреть курсы без входа
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 pt-6 border-t border-white/[0.06] text-center">
          <p className="text-sm text-slate-600">
            НейроУниверситет 2025. Все права защищены.
          </p>
        </div>
      </div>
    </div>
  );
}
