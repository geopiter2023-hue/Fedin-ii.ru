import { useState, useEffect, useRef, useCallback } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import Navbar from "@/components/Navbar";
import {
  Send,
  Sparkles,
  BookOpen,
  GraduationCap,
  Zap,
  User,
  Volume2,
  VolumeX,
  ArrowRight,
} from "lucide-react";

interface Message {
  id: string;
  role: "user" | "assistant";
  text: string;
  isTyping?: boolean;
}

const GREETING = `Привет! Я Нейра — твой цифровой помощник в мире нейросетей. Готова ответить на любые вопросы о наших курсах, помочь выбрать подходящий, или просто рассказать, как работает искусственный интеллект. Чем могу помочь?`;

const QUICK_QUESTIONS = [
  "Какие курсы есть для начинающих?",
  "Расскажи про ChatGPT курс",
  "Что такое Prompt Engineering?",
  "Какой курс выбрать для работы?",
  "Сколько стоят курсы?",
  "Что изучают в курсе по Midjourney?",
];

export default function Assistant() {
  const [messages, setMessages] = useState<Message[]>([
    { id: "greet", role: "assistant", text: GREETING, isTyping: true },
  ]);
  const [input, setInput] = useState("");
  const [displayedText, setDisplayedText] = useState("");
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const { data: courses } = trpc.course.list.useQuery({});

  // Typing effect for greeting
  useEffect(() => {
    if (messages[0]?.isTyping) {
      let i = 0;
      const interval = setInterval(() => {
        setDisplayedText(GREETING.slice(0, i));
        i++;
        if (i > GREETING.length) {
          clearInterval(interval);
          setMessages((prev) =>
            prev.map((m) => (m.id === "greet" ? { ...m, isTyping: false } : m))
          );
        }
      }, 15);
      return () => clearInterval(interval);
    }
  }, []);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, displayedText]);

  // Speech synthesis
  const speak = useCallback(
    (text: string) => {
      if (!soundEnabled) return;
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = "ru-RU";
      utterance.rate = 1.1;
      utterance.pitch = 1.1;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    },
    [soundEnabled]
  );

  const stopSpeaking = useCallback(() => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  }, []);

  // Generate response based on user query and courses data
  const generateResponse = useCallback(
    (query: string): string => {
      const q = query.toLowerCase();
      const allCourses = courses || [];

      // Greeting
      if (q.match(/привет|здравствуй|hi|hello/)) {
        return "Привет! Рада тебя видеть. Я Нейра — твой проводник в мир нейросетей. Спроси меня о любых курсах, и я с радостью помогу!";
      }

      // All courses
      if (q.match(/все курсы|список курсов|какие курсы|что есть/)) {
        const list = allCourses
          .map(
            (c) =>
              `• **${c.title}** — ${c.subtitle} (${c.price}₽, ${c.level === "beginner" ? "начинающий" : c.level === "intermediate" ? "средний" : "продвинутый"})`
          )
          .join("\n");
        return `У нас ${allCourses.length} курсов по нейросетям:\n\n${list}\n\nХочешь узнать подробнее о каком-то из них?`;
      }

      // Beginner courses
      if (q.match(/начинающ|новичок|с нуля|базовый/)) {
        const beginner = allCourses.filter((c) => c.level === "beginner");
        const list = beginner
          .map((c) => `• **${c.title}** — ${c.subtitle} (${c.price}₽)`)
          .join("\n");
        return `Для начинающих у нас ${beginner.length} отличных курса:\n\n${list}\n\nРекомендую начать с **«Нейросети с нуля»** — он даст тебь полную базу, а потом можно углубиться в ChatGPT или Midjourney. С чего хочешь начать?`;
      }

      // Intermediate courses
      if (q.match(/средний|для работы|профессиональный/)) {
        const inter = allCourses.filter((c) => c.level === "intermediate");
        const list = inter
          .map((c) => `• **${c.title}** — ${c.subtitle} (${c.price}₽)`)
          .join("\n");
        return `Курсы среднего уровня для применения в работе:\n\n${list}\n\nЭти курсы помогут тебе внедрить ИИ в профессиональную деятельность.`;
      }

      // Advanced courses
      if (q.match(/продвинутый|эксперт|сложный|мастер/)) {
        const adv = allCourses.filter((c) => c.level === "advanced");
        const list = adv
          .map((c) => `• **${c.title}** — ${c.subtitle} (${c.price}₽)`)
          .join("\n");
        return `Продвинутые курсы для тех, кто хочет стать профи:\n\n${list}\n\nЭти курсы требуют базового понимания нейросетей, но открывают невероятные возможности.`;
      }

      // Price question
      if (q.match(/цена|стоимость|сколько стоит|цен|дешево|дорого/)) {
        const cheapest = [...allCourses].sort(
          (a, b) => parseFloat(a.price) - parseFloat(b.price)
        )[0];
        const expensive = [...allCourses].sort(
          (a, b) => parseFloat(b.price) - parseFloat(a.price)
        )[0];
        return `Цены на наши курсы варьируются от **${cheapest.price}₽** («${cheapest.title}») до **${expensive.price}₽** («${expensive.title}»).\n\nМы часто делаем скидки до 40%! Все курсы — пожизненный доступ, без подписок. При покупке ты получаешь сертификат и доступ к чату поддержки.`;
      }

      // Specific course queries
      const courseMatch = allCourses.find((c) => {
        const titleLower = c.title.toLowerCase();
        const slugLower = c.slug.toLowerCase();
        return (
          q.includes(titleLower) ||
          q.includes(slugLower) ||
          (c.category && q.includes(c.category.toLowerCase()))
        );
      });

      if (courseMatch) {
        return `**${courseMatch.title}**\n\n${courseMatch.description}\n\n📚 ${courseMatch.lessonsCount} уроков | ⏱ ${courseMatch.duration}\n💰 **${courseMatch.price}₽** ${courseMatch.oldPrice ? `(вместо ${courseMatch.oldPrice}₽)` : ""}\n⭐ Рейтинг: ${courseMatch.rating} | 👥 ${courseMatch.studentsCount} студентов\n\n[Посмотреть курс](/courses/${courseMatch.slug})`;
      }

      // ChatGPT
      if (q.match(/chatgpt|чат джи пи ти|gpt/)) {
        const c = allCourses.find((x) => x.slug === "chatgpt-master");
        return c
          ? `**${c.title}** — один из самых популярных курсов!\n\n${c.description}\n\nВ курсе 10 уроков, где ты научишься:\n• Писать идеальные промпты\n• Использовать 50+ готовых шаблонов\n• Автоматизировать рутину\n• Создавать контент и анализировать данные\n\n💰 ${c.price}₽ | [Подробнее](/courses/${c.slug})`
          : "ChatGPT курс — наш бестселлер! 10 уроков для полного освоения ChatGPT.";
      }

      // Midjourney
      if (q.match(/midjourney|миджорни|мидж/)) {
        const c = allCourses.find((x) => x.slug === "midjourney-creative");
        return c
          ? `**${c.title}** — идеально для творческих людей!\n\n${c.description}\n\n8 уроков, на которых ты освоишь:\n• Все параметры Midjourney\n• Создание промптов для разных стилей\n• Фотореализм, аниме, 3D\n• Персонажей, интерьеры, логотипы\n\n💰 ${c.price}₽ | [Подробнее](/courses/${c.slug})`
          : "Курс по Midjourney — 8 уроков для создания потрясающих изображений.";
      }

      // Prompt Engineering
      if (q.match(/prompt engineering|промпт|промт инжиниринг/)) {
        const c = allCourses.find((x) => x.slug === "prompt-engineering");
        return c
          ? `**${c.title}** — ключевой навык эпохи ИИ!\n\n${c.description}\n\n14 уроков с продвинутыми техниками:\n• Chain-of-Thought prompting\n• Few-shot learning\n• Ролевые промпты\n• Автоматизация и оптимизация\n\nЭтот курс для тех, кто хочет выжать максимум из любой нейросети.\n\n💰 ${c.price}₽ | [Подробнее](/courses/${c.slug})`
          : "Prompt Engineering — 14 уроков мастерства общения с ИИ.";
      }

      // AI agents
      if (q.match(/агент|agents?|автоном/)) {
        const c = allCourses.find((x) => x.slug === "ai-agents");
        return c
          ? `**${c.title}** — создавай автономных ИИ-помощников!\n\n${c.description}\n\n10 уроков, где ты научишься создавать агентов, которые выполняют сложные задачи автоматически. No-code подход — не нужно программировать!\n\n💰 ${c.price}₽ | [Подробнее](/courses/${c.slug})`
          : "Курс по AI-агентам — 10 уроков создания автономных помощников.";
      }

      // Video generation
      if (q.match(/видео|sora|runway|генерация видео/)) {
        const c = allCourses.find((x) => x.slug === "ai-video-generation");
        return c
          ? `**${c.title}** — создавай видео без камеры!\n\n${c.description}\n\n8 уроков по созданию видеоконтента с помощью Sora, Runway и других инструментов. Идеально для блогеров, маркетологов и креативщиков!\n\n💰 ${c.price}₽ | [Подробнее](/courses/${c.slug})`
          : "Курс по генерации видео — 8 уроков с Sora и Runway.";
      }

      // Copywriting
      if (q.match(/копирайтинг|тексты|писать|письма/)) {
        const c = allCourses.find((x) => x.slug === "ai-copywriting");
        return c
          ? `**${c.title}** — пиши быстрее и лучше!\n\n${c.description}\n\n10 уроков, которые научат тебя создавать продающие тексты, статьи, email-рассылки и посты с помощью ИИ.\n\n💰 ${c.price}₽ | [Подробнее](/courses/${c.slug})`
          : "AI для копирайтинга — 10 уроков создания текстов.";
      }

      // Security
      if (q.match(/безопасность|защита|данные|безопасн/)) {
        const c = allCourses.find((x) => x.slug === "ai-data-security");
        return c
          ? `**${c.title}** — важнейший курс!\n\n${c.description}\n\n6 уроков о том, как защитить конфиденциальные данные при работе с нейросетями. Узнаешь, что нельзя отправлять в ChatGPT и какие есть локальные альтернативы.\n\n💰 ${c.price}₽ | [Подробнее](/courses/${c.slug})`
          : "Курс по защите данных — 6 уроков безопасной работы с ИИ.";
      }

      // Recommend
      if (q.match(/посовет|рекоменд|помоги выбрать|какой выбрать/)) {
        return `Я рада помочь с выбором! Вот мои рекомендации:\n\n🟢 **Если ты новичок:**\n→ «Нейросети с нуля» — полная база\n→ «ChatGPT: от новичка до эксперта» — самый популярный\n\n🟡 **Для работы:**\n→ «AI для маркетологов» — автоматизация маркетинга\n→ «Нейросети для дизайнеров» — ускорь работу в 5 раз\n\n🔴 **Для экспертов:**\n→ «Prompt Engineering мастерство» — выжми максимум из ИИ\n→ «Создание AI-агентов» — автоматизация без кода\n\nЧем занимаешься? Подберу курс специально под тебя!`;
      }

      // What is AI
      if (q.match(/что такое ии|что такое нейросеть|как работает|объясни/)) {
        return `Искусственный интеллект (ИИ) — это технология, которая позволяет компьютерам "учиться" на примерах и принимать решения, как это делает человеческий мозг.\n\n**Простая аналогия:** представь, что ты учишь ребёнка узнавать кошек. Ты показываешь фото и говоришь "это кошка". Со временем ребёнок сам начинает определять кошек. Нейросеть работает точно так же — получает примеры, находит закономерности, учится принимать решения.\n\nХочешь узнать больше? Курс **«Нейросети с нуля»** объясняет всё это простым языком без кода!`;
      }

      // Default
      return `Отличный вопрос! Я могу помочь тебе с:\n\n• 📚 Рассказать о любом курсе подробно\n• 🎯 Подобрать курс под твои цели\n• 💰 Узнать стоимость и скидки\n• 🧠 Объяснить, что такое нейросети\n\nПросто спроси! Например: "Расскажи про ChatGPT курс" или "Какой курс для начинающих?"`;
    },
    [courses]
  );

  const handleSend = useCallback(
    (text: string) => {
      if (!text.trim()) return;

      stopSpeaking();

      const userMsg: Message = {
        id: Date.now().toString(),
        role: "user",
        text: text.trim(),
      };

      const response = generateResponse(text.trim());
      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        text: response,
        isTyping: true,
      };

      setMessages((prev) => [...prev, userMsg, assistantMsg]);
      setInput("");

      // Type out response
      let i = 0;
      const interval = setInterval(() => {
        i += 3;
        if (i >= response.length) {
          clearInterval(interval);
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantMsg.id ? { ...m, isTyping: false } : m
            )
          );
          speak(response.replace(/\*\*/g, "").replace(/\[.*?\]\(.*?\)/g, ""));
        }
      }, 8);
    },
    [generateResponse, speak, stopSpeaking]
  );

  const handleQuickQuestion = (q: string) => {
    handleSend(q);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSend(input);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0F] flex flex-col">
      <Navbar />

      <div className="flex-1 flex flex-col lg:flex-row pt-16">
        {/* Left: Avatar */}
        <div className="lg:w-[340px] shrink-0 p-6 flex flex-col items-center border-b lg:border-b-0 lg:border-r border-white/[0.06]">
          {/* Avatar with hologram effect */}
          <div className="relative mb-4 animate-float">
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-[#8B5CF6] to-[#EC4899] opacity-40 blur-2xl animate-pulse" />
            <div className="relative w-48 h-48 rounded-full overflow-hidden border-2 border-[#8B5CF6]/30 shadow-2xl animate-hologram">
              <img
                src="/avatar-static.png"
                alt="Нейра"
                className="w-full h-full object-cover"
              />
              {/* Scan line effect */}
              <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#8B5CF6]/10 to-transparent opacity-50 pointer-events-none" style={{ animation: 'hologram-scan 3s linear infinite' }} />
            </div>
            {isSpeaking && (
              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 flex items-end gap-1">
                {[1,2,3,4,5].map(i => (
                  <div key={i} className="sound-bar" style={{ height: 4 }} />
                ))}
              </div>
            )}
            {isSpeaking && (
              <div className="absolute bottom-2 right-2 w-4 h-4 rounded-full bg-emerald-400 border-2 border-[#0A0A0F] animate-pulse" />
            )}
          </div>

          <h2 className="text-xl font-bold text-white mb-1">Нейра</h2>
          <p className="text-sm text-slate-400 mb-4 text-center">
            Твой AI-консультант по курсам
          </p>

          <div className="flex gap-2 mb-6">
            <button
              onClick={() => {
                if (isSpeaking) {
                  stopSpeaking();
                } else {
                  speak(GREETING);
                }
              }}
              className={`p-2.5 rounded-xl transition-colors ${
                isSpeaking
                  ? "bg-emerald-500/20 text-emerald-400"
                  : "bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white"
              }`}
              title={isSpeaking ? "Остановить" : "Озвучить"}
            >
              {isSpeaking ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
            </button>
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`p-2.5 rounded-xl transition-colors ${
                soundEnabled
                  ? "bg-[#8B5CF6]/20 text-[#8B5CF6]"
                  : "bg-white/5 text-slate-500"
              }`}
              title={soundEnabled ? "Звук вкл" : "Звук выкл"}
            >
              {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </button>
          </div>

          {/* Stats */}
          <div className="w-full space-y-3">
            <div className="flex items-center gap-3 p-3 rounded-xl bg-[#12121A] border border-white/[0.06]">
              <BookOpen className="w-5 h-5 text-[#8B5CF6]" />
              <div>
                <p className="text-sm font-medium text-white">{courses?.length || 12} курсов</p>
                <p className="text-xs text-slate-500">В базе знаний</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-xl bg-[#12121A] border border-white/[0.06]">
              <GraduationCap className="w-5 h-5 text-[#EC4899]" />
              <div>
                <p className="text-sm font-medium text-white">116+ уроков</p>
                <p className="text-xs text-slate-500">Для изучения</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-xl bg-[#12121A] border border-white/[0.06]">
              <Zap className="w-5 h-5 text-amber-400" />
              <div>
                <p className="text-sm font-medium text-white">Мгновенные ответы</p>
                <p className="text-xs text-slate-500">24/7 без выходных</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Chat */}
        <div className="flex-1 flex flex-col min-h-0">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
              >
                {/* Avatar */}
                <div
                  className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                    msg.role === "assistant"
                      ? "gradient-bg"
                      : "bg-white/10"
                  }`}
                >
                  {msg.role === "assistant" ? (
                    <Sparkles className="w-4 h-4 text-white" />
                  ) : (
                    <User className="w-4 h-4 text-slate-300" />
                  )}
                </div>

                {/* Bubble */}
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                    msg.role === "user"
                      ? "bg-[#8B5CF6] text-white"
                      : "bg-[#12121A] border border-white/[0.06] text-slate-300"
                  }`}
                >
                  {msg.role === "assistant" && msg.isTyping ? (
                    <TypingText
                      text={msg.text}
                      onComplete={() => {
                        setMessages((prev) =>
                          prev.map((m) =>
                            m.id === msg.id ? { ...m, isTyping: false } : m
                          )
                        );
                      }}
                    />
                  ) : (
                    <div className="prose prose-invert prose-sm max-w-none whitespace-pre-wrap">
                      <FormattedText text={msg.text} />
                    </div>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick questions */}
          {messages.length <= 1 && (
            <div className="px-4 md:px-6 pb-2">
              <p className="text-xs text-slate-500 mb-2">Быстрые вопросы:</p>
              <div className="flex flex-wrap gap-2">
                {QUICK_QUESTIONS.map((q, i) => (
                  <button
                    key={i}
                    onClick={() => handleQuickQuestion(q)}
                    className="px-3 py-1.5 rounded-lg bg-[#12121A] border border-white/[0.06] text-xs text-slate-400 hover:text-white hover:border-[#8B5CF6]/30 transition-all"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input */}
          <div className="p-4 border-t border-white/[0.06]">
            <form onSubmit={handleSubmit} className="flex gap-3">
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Спроси Нейру о курсах..."
                className="flex-1 px-4 py-3 rounded-xl bg-[#12121A] border border-white/[0.06] text-white placeholder:text-slate-600 focus:outline-none focus:border-[#8B5CF6]/50 transition-colors"
              />
              <button
                type="submit"
                disabled={!input.trim()}
                className="px-4 py-3 rounded-xl gradient-bg text-white hover:opacity-90 transition-opacity disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

// Typing effect component
function TypingText({ text, onComplete }: { text: string; onComplete: () => void }) {
  const [displayed, setDisplayed] = useState("");

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      i += 2;
      setDisplayed(text.slice(0, i));
      if (i >= text.length) {
        clearInterval(interval);
        onComplete();
      }
    }, 6);
    return () => clearInterval(interval);
  }, [text, onComplete]);

  return (
    <div className="whitespace-pre-wrap">
      <FormattedText text={displayed} />
      {displayed.length < text.length && (
        <span className="inline-block w-2 h-4 bg-[#8B5CF6] ml-0.5 animate-pulse align-middle" />
      )}
    </div>
  );
}

// Format text with markdown-like syntax
function FormattedText({ text }: { text: string }) {
  // Split by **bold** and render
  const parts = text.split(/(\*\*.*?\*\*)/g);

  return (
    <>
      {parts.map((part, i) => {
        if (part.startsWith("**") && part.endsWith("**")) {
          return <strong key={i} className="text-white font-semibold">{part.slice(2, -2)}</strong>;
        }
        // Handle links like [text](/url)
        const linkMatch = part.match(/\[([^\]]+)\]\(([^)]+)\)/);
        if (linkMatch) {
          const [, linkText, linkUrl] = linkMatch;
          const before = part.split(linkMatch[0])[0];
          const after = part.split(linkMatch[0])[1];
          return (
            <span key={i}>
              {before}
              <Link to={linkUrl} className="text-[#8B5CF6] hover:text-[#EC4899] underline transition-colors">
                {linkText} <ArrowRight className="w-3 h-3 inline" />
              </Link>
              {after}
            </span>
          );
        }
        return <span key={i}>{part}</span>;
      })}
    </>
  );
}
