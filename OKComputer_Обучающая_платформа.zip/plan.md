# План: Платформа онлайн-обучения fedin-ii (новая, с нуля, full-stack)

## Решения пользователя
- Новая платформа с нуля (не доработка старой fedin-ii.ru)
- Полная версия сразу: витрина курсов, ЛК, видеоуроки, оплата/рассрочка, tripwire-магазин инструментов, Telegram-бот-лендинг, ИИ-куратор, геймификация, сертификаты, партнёрка
- Размещение на решении агента (демо-превью)
- Контентная база: стратегия из /mnt/agents/output/research/ + fedin_strategy.agent.final.md

## Build type: FULL-STACK (auth + DB + персистентность)
Stack: Node 20, React 19 + TS, Vite 7.2.4, Tailwind 3.4.19, shadcn/ui; backend: tRPC + Drizzle + Hono + MySQL + Kimi auth.

## Stage 1 — Init + Research (main agent)
- init-webapp.sh → /mnt/agents/output/app
- info.md: краткая выжимка из стратегии (курсы, цены, модули) для дизайнера

## Stage 2 — Design (Pro_Designer subagent)
- design.md + per-page designs → /mnt/agents/output/design/
- Ожидаемые страницы: home, каталог курсов, страница курса, магазин инструментов, страница инструмента, ЛК ученика, страница урока (видео), блог/база знаний, о платформе/эксперте, партнёрка, login (graft)

## Stage 3 — Scaffold (1 subagent): landing + Navbar/Footer/Layout + assets

## Stage 4 — Backend graft (main agent): db, auth; схема: users, courses, modules, lessons, products (инструменты), orders, enrollments, progress, certificates, referrals, reviews

## Stage 5 — Parallel page agents (4-6): каталог+курс, ЛК+уроки+прогресс, магазин+чекаут, о платформе+партнёрка+блог

## Stage 6 — Merge, wire routes, build, build_version (type: dynamic)
