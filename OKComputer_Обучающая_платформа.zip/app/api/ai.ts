import { z } from "zod";
import { eq } from "drizzle-orm";
import * as schema from "@db/schema";
import { getDb } from "./queries/connection";
import { createRouter, authedQuery } from "./middleware";

export const aiRouter = createRouter({
  ask: authedQuery
    .input(
      z.object({
        lessonId: z.number().int().positive().optional(),
        question: z.string().min(1).max(2000),
      }),
    )
    .mutation(async ({ input }) => {
      let lessonTitle: string | null = null;
      if (input.lessonId) {
        const lesson = await getDb().query.lessons.findFirst({
          where: eq(schema.lessons.id, input.lessonId),
        });
        lessonTitle = lesson?.title ?? null;
      }

      // Мок-ответ ИИ-куратора
      const context = lessonTitle
        ? `по уроку «${lessonTitle}»`
        : "по теме нейросетей";
      const answer =
        `Отличный вопрос ${context}! Если коротко: нейросеть — это инструмент, ` +
        `который усиливает вашу экспертизу, а не заменяет её. Начните с чёткой ` +
        `формулировки задачи: опишите контекст, роль для модели и желаемый формат ` +
        `ответа — это уже 80% хорошего промпта. Затем итерируйте: уточняйте запрос, ` +
        `просите примеры и варианты. Для российского стека без VPN попробуйте ` +
        `GigaChat, YandexGPT или DeepSeek — для большинства рабочих задач их ` +
        `достаточно. По вашему вопросу «${input.question.slice(0, 120)}» ` +
        `рекомендую разбить задачу на шаги и проверять результат на каждом этапе. ` +
        `Если хотите разобрать пример подробнее — напишите, и я приведу готовый промпт.`;

      return {
        answer,
        lessonId: input.lessonId ?? null,
        model: "fedin-ai-curator-mock",
      };
    }),
});
