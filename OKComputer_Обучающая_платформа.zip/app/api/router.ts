import { authRouter } from "./auth-router";
import { coursesRouter } from "./courses";
import { productsRouter } from "./products";
import { shopRouter } from "./shop";
import { meRouter } from "./me";
import { certificatesRouter } from "./certificates";
import { partnersRouter } from "./partners";
import { aiRouter } from "./ai";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  courses: coursesRouter,
  products: productsRouter,
  shop: shopRouter,
  me: meRouter,
  certificates: certificatesRouter,
  partners: partnersRouter,
  ai: aiRouter,
});

export type AppRouter = typeof appRouter;
