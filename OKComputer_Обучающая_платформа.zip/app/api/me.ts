import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { and, eq } from "drizzle-orm";
import * as schema from "@db/schema";
import { getDb } from "./queries/connection";
import { createRouter, authedQuery } from "./middleware";

const XP_PER_LESSON = 200;
const XP_PER_LEVEL = 1000;

async function ensureStats(userId: number) {
  const db = getDb();
  const existing = await db.query.userStats.findFirst({
    where: eq(schema.userStats.userId, userId),
  });
  if (existing) return existing;
  await db
    .insert(schema.userStats)
    .values({ userId, xp: 0, level: 1, streakDays: 0 });
  return db.query.userStats.findFirst({
    where: eq(schema.userStats.userId, userId),
  });
}

export const meRouter = createRouter({
  dashboard: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userId = ctx.user.id;

    const myEnrollments = await db.query.enrollments.findMany({
      where: eq(schema.enrollments.userId, userId),
      with: {
        course: { with: { lessons: true } },
      },
    });

    const progressRows = await db.query.lessonProgress.findMany({
      where: and(
        eq(schema.lessonProgress.userId, userId),
        eq(schema.lessonProgress.completed, true),
      ),
    });
    const completedIds = new Set(progressRows.map((p) => p.lessonId));

    const courses = myEnrollments.map((e) => {
      const total = e.course.lessons.length;
      const done = e.course.lessons.filter((l) => completedIds.has(l.id)).length;
      return {
        enrollmentId: e.id,
        tariff: e.tariff,
        enrolledAt: e.createdAt,
        course: {
          id: e.course.id,
          slug: e.course.slug,
          title: e.course.title,
          poster: e.course.poster,
          lessonsCount: total,
        },
        completedLessons: done,
        progressPercent: total > 0 ? Math.round((done / total) * 100) : 0,
      };
    });

    const stats = await ensureStats(userId);
    const myAchievements = await db.query.achievements.findMany({
      where: eq(schema.achievements.userId, userId),
    });

    return { courses, stats, achievements: myAchievements };
  }),

  completeLesson: authedQuery
    .input(z.object({ lessonId: z.number().int().positive() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const userId = ctx.user.id;

      const lesson = await db.query.lessons.findFirst({
        where: eq(schema.lessons.id, input.lessonId),
      });
      if (!lesson) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Урок не найден" });
      }

      const existing = await db.query.lessonProgress.findFirst({
        where: and(
          eq(schema.lessonProgress.userId, userId),
          eq(schema.lessonProgress.lessonId, input.lessonId),
        ),
      });

      let xpGained = 0;
      if (!existing) {
        await db.insert(schema.lessonProgress).values({
          userId,
          lessonId: input.lessonId,
          completed: true,
          completedAt: new Date(),
        });
        xpGained = XP_PER_LESSON;
      } else if (!existing.completed) {
        await db
          .update(schema.lessonProgress)
          .set({ completed: true, completedAt: new Date() })
          .where(eq(schema.lessonProgress.id, existing.id));
        xpGained = XP_PER_LESSON;
      }

      // Обновляем статистику: XP, уровень, стрик
      const stats = await ensureStats(userId);
      const today = new Date().toISOString().slice(0, 10);
      let streakDays = stats?.streakDays ?? 0;
      const last = stats?.lastActiveDate
        ? new Date(stats.lastActiveDate).toISOString().slice(0, 10)
        : null;
      if (last !== today) {
        const yesterday = new Date(Date.now() - 86400000)
          .toISOString()
          .slice(0, 10);
        streakDays = last === yesterday ? streakDays + 1 : 1;
      }
      const xp = (stats?.xp ?? 0) + xpGained;
      const level = Math.floor(xp / XP_PER_LEVEL) + 1;

      await db
        .update(schema.userStats)
        .set({ xp, level, streakDays, lastActiveDate: new Date(today) })
        .where(eq(schema.userStats.userId, userId));

      // Достижение за первый урок
      if (xpGained > 0 && (stats?.xp ?? 0) === 0) {
        await db.insert(schema.achievements).values({
          userId,
          code: "first-lesson",
          title: "Первый шаг в мир нейросетей",
        });
      }

      return { xp, level, streakDays, xpGained };
    }),

  certificates: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db.query.certificates.findMany({
      where: eq(schema.certificates.userId, ctx.user.id),
      with: { course: true },
    });
  }),
});
