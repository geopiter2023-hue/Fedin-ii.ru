import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { eq, desc } from "drizzle-orm";
import * as schema from "@db/schema";
import { getDb } from "./queries/connection";
import { createRouter, publicQuery } from "./middleware";

export const coursesRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db
      .select()
      .from(schema.courses)
      .where(eq(schema.courses.isPublished, true));
  }),

  bySlug: publicQuery
    .input(z.object({ slug: z.string().min(1) }))
    .query(async ({ input }) => {
      const db = getDb();
      const course = await db.query.courses.findFirst({
        where: eq(schema.courses.slug, input.slug),
        with: {
          modules: {
            orderBy: (m, { asc }) => [asc(m.orderIndex)],
            with: {
              lessons: {
                orderBy: (l, { asc }) => [asc(l.orderIndex)],
              },
            },
          },
        },
      });
      if (!course) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Курс не найден" });
      }
      return course;
    }),

  reviews: publicQuery
    .input(z.object({ courseId: z.number().int().positive() }))
    .query(async ({ input }) => {
      const db = getDb();
      const rows = await db.query.reviews.findMany({
        where: eq(schema.reviews.courseId, input.courseId),
        orderBy: [desc(schema.reviews.createdAt)],
        with: { user: true },
      });
      return rows.map((r) => ({
        id: r.id,
        rating: r.rating,
        text: r.text,
        createdAt: r.createdAt,
        userName: r.user?.name ?? "Ученик",
        userAvatar: r.user?.avatar ?? null,
      }));
    }),
});
