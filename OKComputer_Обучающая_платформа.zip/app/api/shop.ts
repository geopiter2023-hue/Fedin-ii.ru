import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { and, eq } from "drizzle-orm";
import * as schema from "@db/schema";
import { getDb } from "./queries/connection";
import { createRouter, authedQuery } from "./middleware";

export const shopRouter = createRouter({
  checkout: authedQuery
    .input(
      z.object({
        itemType: z.enum(["course", "product"]),
        itemId: z.number().int().positive(),
        tariff: z.enum(["basic", "pro"]).optional(),
        installments: z.boolean().optional().default(false),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      let amount: number;

      if (input.itemType === "course") {
        const course = await db.query.courses.findFirst({
          where: eq(schema.courses.id, input.itemId),
        });
        if (!course) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Курс не найден",
          });
        }
        amount =
          input.tariff === "pro" && course.proPrice
            ? course.proPrice
            : course.price;
      } else {
        const product = await db.query.products.findFirst({
          where: eq(schema.products.id, input.itemId),
        });
        if (!product) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Товар не найден",
          });
        }
        amount = product.price;
      }

      // Мок-оплата: заказ сразу получает статус paid
      const [{ id: orderId }] = await db
        .insert(schema.orders)
        .values({
          userId: ctx.user.id,
          itemType: input.itemType,
          itemId: input.itemId,
          amount,
          status: "paid",
          installments: input.installments,
        })
        .$returningId();

      // Для курса — создаём enrollment (идемпотентно)
      if (input.itemType === "course") {
        const existing = await db.query.enrollments.findFirst({
          where: and(
            eq(schema.enrollments.userId, ctx.user.id),
            eq(schema.enrollments.courseId, input.itemId),
          ),
        });
        if (!existing) {
          await db.insert(schema.enrollments).values({
            userId: ctx.user.id,
            courseId: input.itemId,
            tariff: input.tariff ?? "basic",
          });
        }
      }

      return { orderId, status: "paid" as const, amount };
    }),
});
