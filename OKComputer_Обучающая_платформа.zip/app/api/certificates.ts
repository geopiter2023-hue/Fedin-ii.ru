import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { eq } from "drizzle-orm";
import * as schema from "@db/schema";
import { getDb } from "./queries/connection";
import { createRouter, publicQuery } from "./middleware";

export const certificatesRouter = createRouter({
  verify: publicQuery
    .input(z.object({ verifyCode: z.string().min(1) }))
    .query(async ({ input }) => {
      const db = getDb();
      const cert = await db.query.certificates.findFirst({
        where: eq(schema.certificates.verifyCode, input.verifyCode),
        with: { user: true, course: true },
      });
      if (!cert) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Сертификат не найден",
        });
      }
      return {
        verifyCode: cert.verifyCode,
        issuedAt: cert.issuedAt,
        userName: cert.user?.name ?? "Ученик",
        courseTitle: cert.course?.title ?? "",
      };
    }),
});
