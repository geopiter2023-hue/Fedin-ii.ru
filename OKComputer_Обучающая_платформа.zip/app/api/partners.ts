import { eq, sql } from "drizzle-orm";
import * as schema from "@db/schema";
import { getDb } from "./queries/connection";
import { createRouter, authedQuery } from "./middleware";

export const partnersRouter = createRouter({
  stats: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userId = ctx.user.id;

    const rows = await db.query.referrals.findMany({
      where: eq(schema.referrals.userId, userId),
    });

    const [totals] = await db
      .select({
        totalCommission: sql<number>`COALESCE(SUM(${schema.referrals.commission}), 0)`,
        paidCommission: sql<number>`COALESCE(SUM(CASE WHEN ${schema.referrals.status} = 'paid' THEN ${schema.referrals.commission} ELSE 0 END), 0)`,
        pendingCommission: sql<number>`COALESCE(SUM(CASE WHEN ${schema.referrals.status} = 'pending' THEN ${schema.referrals.commission} ELSE 0 END), 0)`,
      })
      .from(schema.referrals)
      .where(eq(schema.referrals.userId, userId));

    return {
      referrals: rows,
      referralsCount: rows.length,
      totalCommission: Number(totals?.totalCommission ?? 0),
      paidCommission: Number(totals?.paidCommission ?? 0),
      pendingCommission: Number(totals?.pendingCommission ?? 0),
    };
  }),

  link: authedQuery.query(({ ctx }) => {
    // Реферальная ссылка партнёра: 20% с продаж
    return {
      url: `https://fedin-ii.ru/?ref=${ctx.user.id}`,
      code: String(ctx.user.id),
      commissionPercent: 20,
    };
  }),
});
