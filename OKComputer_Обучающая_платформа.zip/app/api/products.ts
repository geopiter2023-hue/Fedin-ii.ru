import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { eq } from "drizzle-orm";
import * as schema from "@db/schema";
import { getDb } from "./queries/connection";
import { createRouter, publicQuery } from "./middleware";

export const productsRouter = createRouter({
  list: publicQuery
    .input(
      z
        .object({
          category: z
            .enum(["prompt-pack", "guide", "n8n", "preset", "subscription"])
            .optional(),
        })
        .optional(),
    )
    .query(async ({ input }) => {
      const db = getDb();
      if (input?.category) {
        return db
          .select()
          .from(schema.products)
          .where(eq(schema.products.category, input.category));
      }
      return db.select().from(schema.products);
    }),

  bySlug: publicQuery
    .input(z.object({ slug: z.string().min(1) }))
    .query(async ({ input }) => {
      const db = getDb();
      const product = await db.query.products.findFirst({
        where: eq(schema.products.slug, input.slug),
      });
      if (!product) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Товар не найден" });
      }
      return product;
    }),
});
