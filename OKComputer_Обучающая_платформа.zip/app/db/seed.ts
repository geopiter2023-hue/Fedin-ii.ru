import { eq } from "drizzle-orm";
import { getDb } from "../api/queries/connection";
import * as schema from "./schema";

type LessonSeed = { title: string; durationMin: number; isFree?: boolean };
type ModuleSeed = { title: string; lessons: LessonSeed[] };
type CourseSeed = {
  slug: string;
  title: string;
  subtitle: string;
  description: string;
  category: string;
  level: string;
  price: number;
  proPrice: number;
  oldPrice?: number;
  hours: number;
  poster: string;
  badge?: string;
  modules: ModuleSeed[];
};

// Цены в копейках
const COURSES: CourseSeed[] = [
  {
    slug: "neuroseti-dlya-raboty",
    title: "Нейросети для работы и продуктивности",
    subtitle: "Бесплатный стек без VPN: GigaChat, YandexGPT, DeepSeek",
    description:
      "Бестселлер для новичков. Освойте нейросети для документов, писем, таблиц и презентаций и соберите личный промптбук.",
    category: "Продуктивность",
    level: "Новичкам",
    price: 14900_00,
    proPrice: 29900_00,
    oldPrice: 19900_00,
    hours: 12,
    poster: "/posters/course-productivity.jpg",
    badge: "Бестселлер",
    modules: [
      {
        title: "Старт: бесплатные нейросети без VPN",
        lessons: [
          { title: "Как устроены нейросети: просто о сложном", durationMin: 18, isFree: true },
          { title: "Регистрация и настройка GigaChat, YandexGPT, DeepSeek", durationMin: 22, isFree: true },
          { title: "Правила безопасности и приватности данных", durationMin: 15 },
        ],
      },
      {
        title: "Искусство промптинга",
        lessons: [
          { title: "Анатомия идеального промпта", durationMin: 25 },
          { title: "Роли, контекст и формат ответа", durationMin: 20 },
          { title: "Итеративный диалог: как дожимать модель", durationMin: 20 },
        ],
      },
      {
        title: "Документы и письма",
        lessons: [
          { title: "Деловая переписка за 5 минут", durationMin: 18 },
          { title: "Сводки, протоколы и ТЗ с помощью ИИ", durationMin: 24 },
        ],
      },
      {
        title: "Таблицы, презентации и личный промптбук",
        lessons: [
          { title: "Анализ таблиц и отчётов", durationMin: 26 },
          { title: "Презентации за один вечер", durationMin: 22 },
          { title: "Собираем личный промптбук", durationMin: 20 },
        ],
      },
    ],
  },
  {
    slug: "neuroseti-dlya-kontenta",
    title: "Нейросети для контента: Reels, видео, визуал",
    subtitle: "Kling, Veo, Midjourney, Nano Banana, HeyGen, Suno",
    description:
      "Создавайте вирусные Reels, видео и визуал нейросетями. Отдельный модуль — монетизация контента.",
    category: "Контент",
    level: "Новичкам и практикам",
    price: 19900_00,
    proPrice: 39900_00,
    oldPrice: 24900_00,
    hours: 16,
    poster: "/posters/course-content.jpg",
    badge: "Хит",
    modules: [
      {
        title: "Визуал: Midjourney и Nano Banana",
        lessons: [
          { title: "Генерация изображений: база", durationMin: 24 },
          { title: "Стиль, свет и композиция в промптах", durationMin: 22 },
          { title: "Редактирование и апскейл", durationMin: 18 },
        ],
      },
      {
        title: "Видео: Kling, Veo, HeyGen",
        lessons: [
          { title: "Оживляем картинки: видео из промпта", durationMin: 26 },
          { title: "AI-аватары и озвучка", durationMin: 24 },
          { title: "Музыка и саунд с Suno", durationMin: 16 },
        ],
      },
      {
        title: "Reels-машина",
        lessons: [
          { title: "Сценарии и хуки для Reels", durationMin: 20 },
          { title: "Конвейер: 30 роликов в месяц", durationMin: 28 },
        ],
      },
      {
        title: "Монетизация контента",
        lessons: [
          { title: "Упаковка блога и воронки", durationMin: 22 },
          { title: "Продажа услуг нейроконтента", durationMin: 25 },
        ],
      },
    ],
  },
  {
    slug: "neuroseti-dlya-marketinga",
    title: "Нейросети для маркетинга, SMM и ИИ-агентов",
    subtitle: "От промптов до агентов n8n: автоворонки и GEO",
    description:
      "Программа на 8–10 недель для маркетологов и предпринимателей: SMM, автоворонки, ИИ-агенты на n8n и GEO-оптимизация.",
    category: "Маркетинг",
    level: "Практикам",
    price: 29000_00,
    proPrice: 35000_00,
    oldPrice: 35000_00,
    hours: 24,
    poster: "/posters/course-marketing.jpg",
    modules: [
      {
        title: "ИИ в маркетинге: стратегия",
        lessons: [
          { title: "Карта нейросетей для маркетолога", durationMin: 22 },
          { title: "Анализ ЦА и конкурентов с ИИ", durationMin: 26 },
          { title: "Генерация офферов и УТП", durationMin: 20 },
        ],
      },
      {
        title: "SMM и контент-воронки",
        lessons: [
          { title: "Контент-план за час", durationMin: 24 },
          { title: "Тексты, креативы, посевы", durationMin: 25 },
        ],
      },
      {
        title: "ИИ-агенты на n8n",
        lessons: [
          { title: "Знакомство с n8n: первый сценарий", durationMin: 28 },
          { title: "Агент для обработки заявок", durationMin: 32 },
          { title: "Автоворонка: от лида до продажи", durationMin: 30 },
        ],
      },
      {
        title: "GEO и аналитика",
        lessons: [
          { title: "GEO: продвижение в ответах нейросетей", durationMin: 26 },
          { title: "Сквозная аналитика с ИИ", durationMin: 24 },
        ],
      },
    ],
  },
  {
    slug: "vibe-coding",
    title: "Вайб-кодинг: создай свой продукт без программистов",
    subtitle: "MVP за выходные: Cursor, Bolt, Lovable, n8n",
    description:
      "Соберите работающий MVP своего продукта за выходные без единой строчки кода. Есть менторский тариф.",
    category: "Разработка",
    level: "Без опыта в коде",
    price: 39000_00,
    proPrice: 45000_00,
    hours: 20,
    poster: "/posters/course-vibecoding.jpg",
    badge: "Новинка",
    modules: [
      {
        title: "Мышление вайб-кодера",
        lessons: [
          { title: "Что такое вайб-кодинг и почему это работает", durationMin: 20 },
          { title: "Проектируем MVP: от идеи до ТЗ для ИИ", durationMin: 26 },
        ],
      },
      {
        title: "Инструменты: Cursor, Bolt, Lovable",
        lessons: [
          { title: "Bolt и Lovable: приложение за вечер", durationMin: 30 },
          { title: "Cursor: управляем кодом словами", durationMin: 32 },
          { title: "Отладка: просим ИИ чинить свои ошибки", durationMin: 22 },
          { title: "Базы данных и авторизация без боли", durationMin: 28 },
        ],
      },
      {
        title: "Автоматизация и запуск",
        lessons: [
          { title: "Интеграции через n8n", durationMin: 26 },
          { title: "Деплой, домен и первые пользователи", durationMin: 24 },
        ],
      },
    ],
  },
  {
    slug: "ii-kartochki-marketpleisy",
    title: "ИИ-карточки для маркетплейсов",
    subtitle: "Для селлеров WB и Ozon: карточки, которые продают",
    description:
      "Быстрый трек для селлеров: инфографика, описания и SEO карточек с помощью нейросетей.",
    category: "E-commerce",
    level: "Селлерам",
    price: 14900_00,
    proPrice: 29900_00,
    hours: 8,
    poster: "/posters/course-marketplace.jpg",
    modules: [
      {
        title: "Карточка, которая продаёт",
        lessons: [
          { title: "Разбор продающих карточек WB/Ozon", durationMin: 18 },
          { title: "SEO-названия и описания с ИИ", durationMin: 22 },
          { title: "Ответы на отзывы и вопросы с нейросетью", durationMin: 16 },
        ],
      },
      {
        title: "Инфографика нейросетями",
        lessons: [
          { title: "Генерация фона и предметки", durationMin: 24 },
          { title: "Слайды и rich-контент за час", durationMin: 26 },
        ],
      },
      {
        title: "Конвейер карточек",
        lessons: [
          { title: "Шаблоны и массовая генерация", durationMin: 22 },
          { title: "Фон и инфографика для Ozon: особенности", durationMin: 18 },
          { title: "A/B-тесты и рост конверсии", durationMin: 20 },
        ],
      },
    ],
  },
];

const PRODUCTS: schema.InsertProduct[] = [
  {
    slug: "prompt-pack-marketolog",
    title: "Промпт-пак «Маркетолог»",
    description: "120 готовых промптов для маркетолога: офферы, тексты, аналитика.",
    category: "prompt-pack",
    price: 990_00,
    cover: "/covers/pack-marketolog.jpg",
    fileUrl: "/files/prompt-pack-marketolog.pdf",
    isHit: true,
  },
  {
    slug: "prompt-pack-hr",
    title: "Промпт-пак «HR»",
    description: "Промпты для вакансий, интервью и онбординга.",
    category: "prompt-pack",
    price: 490_00,
    cover: "/covers/pack-hr.jpg",
    fileUrl: "/files/prompt-pack-hr.pdf",
  },
  {
    slug: "prompt-pack-rieltor",
    title: "Промпт-пак «Риелтор»",
    description: "Объявления, скрипты и работа с возражениями.",
    category: "prompt-pack",
    price: 590_00,
    cover: "/covers/pack-rieltor.jpg",
    fileUrl: "/files/prompt-pack-rieltor.pdf",
  },
  {
    slug: "100-promptov-wb-ozon",
    title: "100 промптов для карточек WB/Ozon",
    description: "Названия, описания и инфографика для карточек маркетплейсов.",
    category: "prompt-pack",
    price: 990_00,
    cover: "/covers/pack-wb-ozon.jpg",
    fileUrl: "/files/100-promptov-wb-ozon.pdf",
    isHit: true,
  },
  {
    slug: "guide-oplata-ai-iz-rossii",
    title: "Гайд «Оплата зарубежных ИИ из России»",
    description: "Все рабочие способы оплаты Midjourney, ChatGPT и других сервисов.",
    category: "guide",
    price: 299_00,
    cover: "/covers/guide-oplata.jpg",
    fileUrl: "/files/guide-oplata.pdf",
  },
  {
    slug: "n8n-svyazki-avtomatizaciya",
    title: "N8n-связки автоматизации (.json)",
    description: "Готовые сценарии n8n: заявки, рассылки, отчёты. Импортируй и работай.",
    category: "n8n",
    price: 2990_00,
    oldPrice: 6890_00,
    cover: "/covers/n8n-svyazki.jpg",
    fileUrl: "/files/n8n-svyazki.zip",
    isHit: true,
  },
  {
    slug: "presety-midjourney-nano-banana",
    title: "Библиотека стилевых пресетов Midjourney / Nano Banana",
    description: "50 стилевых пресетов для коммерческого визуала.",
    category: "preset",
    price: 1490_00,
    cover: "/covers/presety.jpg",
    fileUrl: "/files/presety.zip",
  },
  {
    slug: "podpiska-neiroclub",
    title: "Подписка «Нейроклуб»",
    description:
      "Обновления курсов, новые промпт-паки ежемесячно и закрытое комьюнити.",
    category: "subscription",
    price: 990_00,
    cover: "/covers/neiroclub.jpg",
  },
];

const REVIEWS = [
  { rating: 5, text: "Прошла курс по продуктивности — теперь отчёты делаю втрое быстрее. Всё по-русски и без VPN, очень удобно!" },
  { rating: 5, text: "Курс по контенту окупился за две недели: делаю Reels заказчикам нейросетями." },
  { rating: 4, text: "Понравился модуль по n8n-агентам. Хотелось бы ещё больше разборов, но база отличная." },
  { rating: 5, text: "Вайб-кодинг — магия. Собрал MVP своего сервиса за выходные, не зная кода." },
  { rating: 5, text: "ИИ-карточки подняли конверсию моего магазина на WB на 30%. Рекомендую селлерам." },
  { rating: 4, text: "Маркетинговый курс плотный, но структурированный. Куратор отвечает быстро." },
];

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  // Демо-пользователь для отзывов
  let demoUser = await db.query.users.findFirst({
    where: eq(schema.users.unionId, "seed-demo-user"),
  });
  if (!demoUser) {
    const [{ id }] = await db
      .insert(schema.users)
      .values({ unionId: "seed-demo-user", name: "Анна Смирнова" })
      .$returningId();
    demoUser = { id } as schema.User;
  }

  for (const c of COURSES) {
    const existing = await db.query.courses.findFirst({
      where: eq(schema.courses.slug, c.slug),
    });
    if (existing) {
      console.log(`Skip existing course: ${c.slug}`);
      continue;
    }

    const modulesCount = c.modules.length;
    const lessonsCount = c.modules.reduce((n, m) => n + m.lessons.length, 0);

    const [{ id: courseId }] = await db
      .insert(schema.courses)
      .values({
        slug: c.slug,
        title: c.title,
        subtitle: c.subtitle,
        description: c.description,
        category: c.category,
        level: c.level,
        price: c.price,
        proPrice: c.proPrice,
        oldPrice: c.oldPrice,
        modulesCount,
        lessonsCount,
        hours: c.hours,
        poster: c.poster,
        badge: c.badge,
        isPublished: true,
      })
      .$returningId();

    let lessonOrder = 0;
    for (const [mi, m] of c.modules.entries()) {
      const [{ id: moduleId }] = await db
        .insert(schema.courseModules)
        .values({ courseId, title: m.title, orderIndex: mi })
        .$returningId();

      for (const l of m.lessons) {
        await db.insert(schema.lessons).values({
          moduleId,
          courseId,
          title: l.title,
          durationMin: l.durationMin,
          videoUrl: "https://cdn.fedin-ii.ru/video/placeholder.mp4",
          summary: `Конспект урока «${l.title}»: ключевые тезисы и практические шаги.`,
          materialsJson: JSON.stringify([
            { title: "Чек-лист урока", url: "/files/checklist.pdf" },
          ]),
          promptsJson: JSON.stringify([
            { title: "Промпт из урока", prompt: "Опиши контекст, роль и формат ответа..." },
          ]),
          orderIndex: lessonOrder++,
          isFree: l.isFree ?? false,
        });
      }
    }
    console.log(`Seeded course: ${c.slug} (${modulesCount} модулей, ${lessonsCount} уроков)`);
  }

  // Продукты магазина
  for (const p of PRODUCTS) {
    const existing = await db.query.products.findFirst({
      where: eq(schema.products.slug, p.slug),
    });
    if (existing) {
      console.log(`Skip existing product: ${p.slug}`);
      continue;
    }
    await db.insert(schema.products).values(p);
    console.log(`Seeded product: ${p.slug}`);
  }

  // Отзывы к первому курсу
  const firstCourse = await db.query.courses.findFirst({
    where: eq(schema.courses.slug, COURSES[0].slug),
  });
  if (firstCourse) {
    const existingReviews = await db.query.reviews.findMany({
      where: eq(schema.reviews.courseId, firstCourse.id),
    });
    if (existingReviews.length === 0) {
      for (const r of REVIEWS) {
        await db.insert(schema.reviews).values({
          courseId: firstCourse.id,
          userId: demoUser.id,
          rating: r.rating,
          text: r.text,
        });
      }
      console.log(`Seeded ${REVIEWS.length} reviews`);
    }
  }

  console.log("Done.");
  process.exit(0); // close MySQL connection pool
}

seed();
