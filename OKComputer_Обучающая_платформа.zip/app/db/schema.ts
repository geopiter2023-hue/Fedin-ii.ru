import {
  mysqlTable,
  mysqlEnum,

  bigint,
  boolean,
  int,
  varchar,
  text,
  timestamp,
  date,
} from "drizzle-orm/mysql-core";

/** FK column matching serial() PK type: bigint unsigned */
const fk = (name: string) =>
  bigint(name, { mode: "number", unsigned: true }).notNull();

export const users = mysqlTable("users", {
  // bigint unsigned auto_increment — идентично serial(), но генерирует валидный SQL
  id: bigint("id", { mode: "number", unsigned: true })
    .autoincrement()
    .primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ── Курсы ─────────────────────────────────────────────────────

export const courses = mysqlTable("courses", {
  id: bigint("id", { mode: "number", unsigned: true })
    .autoincrement()
    .primaryKey(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  subtitle: varchar("subtitle", { length: 500 }),
  description: text("description"),
  category: varchar("category", { length: 100 }),
  level: varchar("level", { length: 50 }),
  price: int("price").notNull(), // базовый тариф, в копейках
  proPrice: int("proPrice"), // PRO-тариф, в копейках
  oldPrice: int("oldPrice"),
  modulesCount: int("modulesCount").default(0).notNull(),
  lessonsCount: int("lessonsCount").default(0).notNull(),
  hours: int("hours").default(0).notNull(),
  poster: varchar("poster", { length: 500 }),
  badge: varchar("badge", { length: 100 }),
  isPublished: boolean("isPublished").default(true).notNull(),
});

export type Course = typeof courses.$inferSelect;
export type InsertCourse = typeof courses.$inferInsert;

export const courseModules = mysqlTable("courseModules", {
  id: bigint("id", { mode: "number", unsigned: true })
    .autoincrement()
    .primaryKey(),
  courseId: fk("courseId"),
  title: varchar("title", { length: 255 }).notNull(),
  orderIndex: int("orderIndex").default(0).notNull(),
});

export type CourseModule = typeof courseModules.$inferSelect;
export type InsertCourseModule = typeof courseModules.$inferInsert;

export const lessons = mysqlTable("lessons", {
  id: bigint("id", { mode: "number", unsigned: true })
    .autoincrement()
    .primaryKey(),
  moduleId: fk("moduleId"),
  courseId: fk("courseId"),
  title: varchar("title", { length: 255 }).notNull(),
  durationMin: int("durationMin").default(0).notNull(),
  videoUrl: varchar("videoUrl", { length: 500 }),
  summary: text("summary"),
  materialsJson: text("materialsJson"),
  promptsJson: text("promptsJson"),
  orderIndex: int("orderIndex").default(0).notNull(),
  isFree: boolean("isFree").default(false).notNull(),
});

export type Lesson = typeof lessons.$inferSelect;
export type InsertLesson = typeof lessons.$inferInsert;

// ── Магазин ───────────────────────────────────────────────────

export const products = mysqlTable("products", {
  id: bigint("id", { mode: "number", unsigned: true })
    .autoincrement()
    .primaryKey(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  category: mysqlEnum("category", [
    "prompt-pack",
    "guide",
    "n8n",
    "preset",
    "subscription",
  ]).notNull(),
  price: int("price").notNull(), // в копейках
  oldPrice: int("oldPrice"),
  cover: varchar("cover", { length: 500 }),
  fileUrl: varchar("fileUrl", { length: 500 }),
  isHit: boolean("isHit").default(false).notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

export const orders = mysqlTable("orders", {
  id: bigint("id", { mode: "number", unsigned: true })
    .autoincrement()
    .primaryKey(),
  userId: fk("userId"),
  itemType: mysqlEnum("itemType", ["course", "product"]).notNull(),
  itemId: bigint("itemId", { mode: "number", unsigned: true }).notNull(),
  amount: int("amount").notNull(), // в копейках
  status: mysqlEnum("status", ["pending", "paid", "refunded"])
    .default("pending")
    .notNull(),
  installments: boolean("installments").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

// ── Обучение ──────────────────────────────────────────────────

export const enrollments = mysqlTable("enrollments", {
  id: bigint("id", { mode: "number", unsigned: true })
    .autoincrement()
    .primaryKey(),
  userId: fk("userId"),
  courseId: fk("courseId"),
  tariff: mysqlEnum("tariff", ["basic", "pro"]).default("basic").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Enrollment = typeof enrollments.$inferSelect;
export type InsertEnrollment = typeof enrollments.$inferInsert;

export const lessonProgress = mysqlTable("lessonProgress", {
  id: bigint("id", { mode: "number", unsigned: true })
    .autoincrement()
    .primaryKey(),
  userId: fk("userId"),
  lessonId: fk("lessonId"),
  completed: boolean("completed").default(false).notNull(),
  completedAt: timestamp("completedAt"),
});

export type LessonProgress = typeof lessonProgress.$inferSelect;
export type InsertLessonProgress = typeof lessonProgress.$inferInsert;

export const userStats = mysqlTable("userStats", {
  id: bigint("id", { mode: "number", unsigned: true })
    .autoincrement()
    .primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .unique(),
  xp: int("xp").default(0).notNull(),
  level: int("level").default(1).notNull(),
  streakDays: int("streakDays").default(0).notNull(),
  lastActiveDate: date("lastActiveDate"),
});

export type UserStats = typeof userStats.$inferSelect;
export type InsertUserStats = typeof userStats.$inferInsert;

export const achievements = mysqlTable("achievements", {
  id: bigint("id", { mode: "number", unsigned: true })
    .autoincrement()
    .primaryKey(),
  userId: fk("userId"),
  code: varchar("code", { length: 100 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  unlockedAt: timestamp("unlockedAt").defaultNow().notNull(),
});

export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = typeof achievements.$inferInsert;

export const certificates = mysqlTable("certificates", {
  id: bigint("id", { mode: "number", unsigned: true })
    .autoincrement()
    .primaryKey(),
  userId: fk("userId"),
  courseId: fk("courseId"),
  verifyCode: varchar("verifyCode", { length: 64 }).notNull().unique(),
  issuedAt: timestamp("issuedAt").defaultNow().notNull(),
});

export type Certificate = typeof certificates.$inferSelect;
export type InsertCertificate = typeof certificates.$inferInsert;

// ── Партнёрка и отзывы ────────────────────────────────────────

export const referrals = mysqlTable("referrals", {
  id: bigint("id", { mode: "number", unsigned: true })
    .autoincrement()
    .primaryKey(),
  userId: fk("userId"), // партнёр
  referredUserId: bigint("referredUserId", { mode: "number", unsigned: true }),
  orderId: bigint("orderId", { mode: "number", unsigned: true }),
  commission: int("commission").default(0).notNull(), // в копейках
  status: mysqlEnum("status", ["pending", "approved", "paid"])
    .default("pending")
    .notNull(),
});

export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = typeof referrals.$inferInsert;

export const reviews = mysqlTable("reviews", {
  id: bigint("id", { mode: "number", unsigned: true })
    .autoincrement()
    .primaryKey(),
  courseId: fk("courseId"),
  userId: fk("userId"),
  rating: int("rating").notNull(),
  text: text("text"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Review = typeof reviews.$inferSelect;
export type InsertReview = typeof reviews.$inferInsert;
