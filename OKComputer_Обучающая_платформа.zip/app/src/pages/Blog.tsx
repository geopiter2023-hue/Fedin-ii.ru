import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowRight, Clock, Eye, Search } from 'lucide-react'
import { cn } from '@/lib/utils'

export type BlogMeta = {
  id: string
  title: string
  excerpt: string
  category: string
  cover: string
  minutes: number
  date: string
  views: string
}

export const ARTICLES: BlogMeta[] = [
  {
    id: 'payment-2025',
    title: 'Как оплатить ChatGPT и Midjourney из России в 2025',
    excerpt:
      'Все рабочие способы оплаты зарубежных нейросетей: виртуальные карты, посредники, российские альтернативы. С комиссиями и пошаговыми инструкциями.',
    category: 'Оплата и доступ',
    cover: '/blog-1.jpg',
    minutes: 8,
    date: '12 янв 2025',
    views: '4,2 тыс.',
  },
  {
    id: 'gigachat-prompts',
    title: '10 промптов для GigaChat, которые сэкономят час в день',
    excerpt:
      'Готовые промпты для писем, отчётов, планёрок и анализа документов. Копируйте и используйте — без регистрации за рубежом и VPN.',
    category: 'Промптинг',
    cover: '/blog-2.jpg',
    minutes: 6,
    date: '28 дек 2024',
    views: '3,1 тыс.',
  },
  {
    id: 'reels-neuro',
    title: 'Reels нейросетями: от идеи до монтажа за вечер',
    excerpt:
      'Сценарий в чат-боте, озвучка синтезом речи, генерация видео и автоматический монтаж. Разбираем пайплайн по шагам.',
    category: 'Контент и видео',
    cover: '/blog-3.jpg',
    minutes: 9,
    date: '15 дек 2024',
    views: '2,7 тыс.',
  },
  {
    id: 'wb-cards-ctr',
    title: 'ИИ-карточки для WB: как поднять CTR на 30%',
    excerpt:
      'Генерация фонов, инфографика нейросетями и A/B-тесты главных фото. Реальные кейсы продавцов Wildberries и Ozon.',
    category: 'Маркетплейсы',
    cover: '/blog-4.jpg',
    minutes: 7,
    date: '3 дек 2024',
    views: '2,4 тыс.',
  },
  {
    id: 'n8n-start',
    title: 'n8n для новичков: первая автоматизация за час',
    excerpt:
      'Подключаем Telegram-бота к нейросети без программирования: узлы, webhooks и готовый шаблон для старта.',
    category: 'ИИ-агенты',
    cover: '/blog-5.jpg',
    minutes: 10,
    date: '21 ноя 2024',
    views: '1,9 тыс.',
  },
  {
    id: 'vibe-coding-mvp',
    title: 'Вайб-кодинг: как я собрал MVP за выходные',
    excerpt:
      'Личный опыт: от идеи до работающего веб-приложения с Cursor и Claude за два дня. Что получилось, а где нейросеть буксовала.',
    category: 'Карьера',
    cover: '/blog-6.jpg',
    minutes: 8,
    date: '9 ноя 2024',
    views: '2,2 тыс.',
  },
  {
    id: 'deepseek-vs-chatgpt',
    title: 'DeepSeek vs ChatGPT: что выбрать в России',
    excerpt:
      'Сравниваем качество ответов, скорость, цены и доступность из РФ. Честный вывод: когда хватит DeepSeek, а когда нужен ChatGPT.',
    category: 'Для работы',
    cover: '/blog-1.jpg',
    minutes: 7,
    date: '27 окт 2024',
    views: '3,6 тыс.',
  },
  {
    id: 'ai-career-fear',
    title: 'Нейросети отнимут работу? Разбор главного страха',
    excerpt:
      'Какие задачи ИИ уже делает лучше человека, а в каких профессиях он становится усилителем. План перестройки навыков на 2025 год.',
    category: 'Карьера',
    cover: '/blog-2.jpg',
    minutes: 11,
    date: '14 окт 2024',
    views: '5,1 тыс.',
  },
]

const CATEGORIES = [
  'Все',
  'Промптинг',
  'Для работы',
  'Контент и видео',
  'Маркетплейсы',
  'ИИ-агенты',
  'Оплата и доступ',
  'Карьера',
]

const ease = [0.16, 1, 0.3, 1] as [number, number, number, number]

function Meta({ a }: { a: BlogMeta }) {
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[13px] text-[#5C6B84]">
      <span className="inline-flex items-center gap-1.5">
        <Clock className="h-3.5 w-3.5" /> {a.minutes} мин чтения
      </span>
      <span>{a.date}</span>
      {'views' in a && (
        <span className="inline-flex items-center gap-1.5">
          <Eye className="h-3.5 w-3.5" /> {a.views}
        </span>
      )}
    </div>
  )
}

export default function Blog() {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('Все')
  const [visible, setVisible] = useState(6)

  const featured = ARTICLES[0]
  const rest = useMemo(() => {
    const q = query.trim().toLowerCase()
    return ARTICLES.filter((a) => {
      const byCat = category === 'Все' || a.category === category
      const byQuery =
        !q || a.title.toLowerCase().includes(q) || a.excerpt.toLowerCase().includes(q)
      return byCat && byQuery
    })
  }, [query, category])

  const searching = query.trim().length > 0 || category !== 'Все'
  const list = rest.filter((a) => a.id !== featured.id || searching)
  const shown = list.slice(0, visible)

  return (
    <div className="relative overflow-hidden">
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[700px] w-[900px] -translate-x-1/2 glow-violet" />
      <div className="pointer-events-none absolute right-[-200px] top-[600px] h-[600px] w-[600px] glow-cyan" />

      {/* Шапка */}
      <section className="relative mx-auto max-w-[1280px] px-6 pb-10 pt-20 text-center md:pt-28">
        <motion.h1
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease }}
          className="font-display text-4xl font-extrabold md:text-6xl"
        >
          База знаний <span className="text-gradient">FEDIN AI</span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.15, ease }}
          className="mx-auto mt-5 max-w-2xl text-lg text-[#9AA6BC]"
        >
          Гайды, разборы и новости нейросетей — простым языком, с промптами, которые можно
          скопировать.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3, ease }}
          className="group relative mx-auto mt-9 max-w-2xl"
        >
          <Search className="pointer-events-none absolute left-5 top-1/2 h-5 w-5 -translate-y-1/2 text-[#5C6B84]" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Например: как оплатить Midjourney из России"
            className="w-full rounded-2xl border border-white/[0.08] bg-[#0D1117] py-4 pl-12 pr-5 text-[15px] text-[#F2F5FA] placeholder:text-[#5C6B84] outline-none transition-all focus:border-[#7C5CFF]/60 focus:shadow-[0_0_32px_rgba(124,92,255,0.25)]"
          />
        </motion.div>
      </section>

      {/* Рубрики */}
      <div className="sticky top-[72px] z-30 border-b border-white/[0.06] bg-[#07090F]/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1280px] gap-2 overflow-x-auto px-6 py-4 [scrollbar-width:none]">
          {CATEGORIES.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={cn(
                'relative shrink-0 rounded-full px-4 py-1.5 text-[13px] font-medium transition-colors',
                category === c ? 'text-white' : 'text-[#9AA6BC] hover:text-[#F2F5FA]'
              )}
            >
              {category === c && (
                <motion.span
                  layoutId="blog-cat"
                  className="absolute inset-0 rounded-full bg-brand-gradient"
                  transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                />
              )}
              <span className="relative z-10">{c}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="relative mx-auto max-w-[1280px] px-6 py-14">
        {/* Избранная статья */}
        {!searching && (
          <motion.div
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7, ease }}
          >
            <Link
              to={`/blog/${featured.id}`}
              className="group grid overflow-hidden rounded-[20px] glass transition-shadow hover:shadow-[0_0_40px_rgba(124,92,255,0.2)] md:grid-cols-2"
            >
              <div className="overflow-hidden">
                <img
                  src={featured.cover}
                  alt={featured.title}
                  className="aspect-video h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                />
              </div>
              <div className="flex flex-col justify-center gap-4 p-8 md:p-10">
                <span className="chip w-fit bg-ai-gradient text-white">Избранное</span>
                <h2 className="font-display text-2xl font-bold transition-colors group-hover:text-[#22D3EE] md:text-3xl">
                  {featured.title}
                </h2>
                <p className="line-clamp-2 text-[15px] text-[#9AA6BC]">{featured.excerpt}</p>
                <Meta a={featured} />
                <span className="inline-flex items-center gap-2 font-medium text-[#22D3EE]">
                  Читать
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </Link>
          </motion.div>
        )}

        {/* Сетка статей */}
        <motion.div layout className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {shown.map((a, i) => (
              <motion.div
                key={a.id}
                layout
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.5, delay: (i % 3) * 0.07, ease }}
                whileHover={{ y: -5 }}
              >
                <Link
                  to={`/blog/${a.id}`}
                  className="group flex h-full flex-col overflow-hidden rounded-[20px] glass transition-shadow hover:shadow-[0_8px_40px_rgba(124,92,255,0.25)]"
                >
                  <div className="overflow-hidden">
                    <img
                      src={a.cover}
                      alt={a.title}
                      loading="lazy"
                      className="aspect-video w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
                    />
                  </div>
                  <div className="flex flex-1 flex-col gap-3 p-6">
                    <span className="chip w-fit glass-light text-[#22D3EE]">{a.category}</span>
                    <h3 className="font-display text-lg font-bold leading-snug">{a.title}</h3>
                    <p className="line-clamp-1 text-sm text-[#9AA6BC]">{a.excerpt}</p>
                    <div className="mt-auto pt-2">
                      <Meta a={a} />
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {shown.length === 0 && (
          <div className="py-20 text-center text-[#9AA6BC]">
            Ничего не найдено. Попробуйте другой запрос или рубрику.
          </div>
        )}

        {/* CTA-полоса */}
        {!searching && (
          <motion.div
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.7, ease }}
            className="gradient-border relative mt-14 overflow-hidden rounded-[20px] p-8 md:p-12"
          >
            <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 glow-cyan animate-drift" />
            <div className="relative flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
              <div>
                <h3 className="font-display text-2xl font-bold md:text-3xl">
                  Хотите систему, а не статьи?
                </h3>
                <p className="mt-2 max-w-xl text-[#9AA6BC]">
                  Бесплатный интенсив «Нейросети за 3 дня»: первый практический результат уже в
                  первый вечер. 0 ₽, старт сразу после регистрации.
                </p>
              </div>
              <Link to="/intensive" className="btn-primary shrink-0">
                Забрать интенсив — 0 ₽
              </Link>
            </div>
          </motion.div>
        )}

        {/* Пагинация */}
        {list.length > visible && (
          <div className="mt-12 text-center">
            <button onClick={() => setVisible((v) => v + 6)} className="btn-ghost">
              Показать ещё
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
