import { useState } from 'react'
import { Link } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowRight,
  CalendarDays,
  CheckCircle2,
  Clock,
  Gift,
  Loader2,
  Mail,
  PlayCircle,
  Rocket,
  ShieldCheck,
  Sparkles,
  Users,
  Zap,
} from 'lucide-react'
import { cn } from '@/lib/utils'

const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1]

const DAYS = [
  {
    day: 'День 1',
    title: 'Нейросети без VPN за 30 минут',
    points: [
      'Бесплатный российский стек: GigaChat, YandexGPT, DeepSeek',
      'Первый полезный результат уже вечером',
      'Формула промпта, который работает',
    ],
    result: 'Настроенный рабочий стек и 5 готовых промптов',
  },
  {
    day: 'День 2',
    title: 'Автоматизация рутины',
    points: [
      'Документы, письма и таблицы — на автопилоте',
      'Разбор реальных задач участников',
      'Шаблоны для вашей профессии',
    ],
    result: 'Одна ваша рутинная задача полностью автоматизирована',
  },
  {
    day: 'День 3',
    title: 'Контент и монетизация',
    points: [
      'Reels и визуал с ИИ: Kling, Midjourney, Nano Banana',
      'Как ученики зарабатывают на новых навыках',
      'Карта дальнейшего роста + бонусы на курсы',
    ],
    result: 'Готовый контент-план и личная стратегия развития',
  },
]

const FOR_WHOM = [
  'Давно хотели разобраться с нейросетями, но «некогда»',
  'Устали от компиляций бесплатного без системы',
  'Хотите результат без VPN и зарубежных карт',
  'Думаете о курсе, но хотите сначала попробовать',
]

export default function Intensive() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [pending, setPending] = useState(false)
  const [done, setDone] = useState(false)

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!email.trim()) return
    setPending(true)
    // Мок-отправка: имитация сети и success-состояние
    setTimeout(() => {
      setPending(false)
      setDone(true)
    }, 900)
  }

  return (
    <div className="relative overflow-hidden">
      {/* свечения */}
      <div className="pointer-events-none absolute -top-24 left-1/2 h-[700px] w-[900px] -translate-x-1/2 glow-violet" />
      <div className="pointer-events-none absolute right-[-10%] top-[35%] h-[500px] w-[500px] glow-cyan" />
      <div className="pointer-events-none absolute left-[-10%] bottom-[10%] h-[500px] w-[500px] glow-violet animate-drift" />

      {/* Hero */}
      <section className="relative mx-auto max-w-[1280px] px-6 pb-20 pt-20 text-center md:pt-28">
        <motion.span
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: EASE }}
          className="chip glass-light mx-auto text-[#34D399]"
        >
          <Zap className="h-3.5 w-3.5" /> Бесплатно · Онлайн · 3 дня
        </motion.span>
        <h1 className="mx-auto mt-6 max-w-4xl font-display text-[34px] font-extrabold leading-[1.08] md:text-[60px]">
          Интенсив: нейросети <span className="text-gradient">за 3 дня</span>
        </h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.6, ease: EASE }}
          className="mx-auto mt-6 max-w-2xl text-[17px] text-[#9AA6BC] md:text-[20px]"
        >
          3 практических урока, первый результат уже в первый вечер. Российский стек без VPN, 0 ₽, без «воды».
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6, ease: EASE }}
          className="mx-auto mt-10 max-w-xl"
        >
          <SignupForm
            name={name}
            email={email}
            pending={pending}
            done={done}
            setName={setName}
            setEmail={setEmail}
            onSubmit={submit}
          />
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="mt-8 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-[13px] text-[#5C6B84]"
        >
          <span className="flex items-center gap-2"><Users className="h-4 w-4 text-[#22D3EE]" /> 5 200+ учеников платформы</span>
          <span className="flex items-center gap-2"><Clock className="h-4 w-4 text-[#7C5CFF]" /> 30–40 минут в день</span>
          <span className="flex items-center gap-2"><Gift className="h-4 w-4 text-[#E879F9]" /> Бонусы участникам</span>
        </motion.div>
      </section>

      {/* Программа по дням */}
      <section className="relative mx-auto max-w-[1280px] px-6 pb-24">
        <h2 className="text-center font-display text-3xl font-bold md:text-[40px]">
          Программа <span className="text-gradient">по дням</span>
        </h2>
        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {DAYS.map((d, i) => (
            <motion.div
              key={d.day}
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.12, duration: 0.6, ease: EASE }}
              className={cn(
                'rounded-[24px] p-7',
                i === 1 ? 'gradient-border shadow-[0_0_32px_rgba(124,92,255,0.2)]' : 'glass'
              )}
            >
              <div className="flex items-center justify-between">
                <span className="chip bg-brand-gradient font-bold text-white">{d.day}</span>
                <CalendarDays className="h-5 w-5 text-[#5C6B84]" />
              </div>
              <h3 className="mt-5 font-display text-[19px] font-bold leading-snug">{d.title}</h3>
              <ul className="mt-5 space-y-3">
                {d.points.map((p) => (
                  <li key={p} className="flex items-start gap-2.5 text-[14px] text-[#9AA6BC]">
                    <PlayCircle className="mt-0.5 h-4 w-4 shrink-0 text-[#22D3EE]" /> {p}
                  </li>
                ))}
              </ul>
              <div className="mt-6 rounded-[14px] border border-[#34D399]/25 bg-[#34D399]/[0.06] px-4 py-3 text-[13px] text-[#34D399]">
                Результат дня: {d.result}
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Кому подойдёт */}
      <section className="relative border-y border-white/[0.06] bg-[#0D1117]/50 py-20">
        <div className="mx-auto grid max-w-[1280px] items-center gap-12 px-6 lg:grid-cols-2">
          <div>
            <h2 className="font-display text-3xl font-bold md:text-[36px]">
              Этот интенсив — <span className="text-gradient">для вас</span>, если…
            </h2>
            <ul className="mt-8 space-y-4">
              {FOR_WHOM.map((t, i) => (
                <motion.li
                  key={t}
                  initial={{ opacity: 0, x: -24 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.08, duration: 0.5, ease: EASE }}
                  className="flex items-start gap-3 text-[16px] text-[#F2F5FA]"
                >
                  <CheckCircle2 className="mt-1 h-5 w-5 shrink-0 text-[#34D399]" /> {t}
                </motion.li>
              ))}
            </ul>
            <p className="mt-8 flex items-center gap-2 text-[14px] text-[#9AA6BC]">
              <ShieldCheck className="h-5 w-5 text-[#22D3EE]" />
              Никакого спама — только уроки и материалы интенсива.
            </p>
          </div>
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: EASE }}
            className="glass relative overflow-hidden rounded-[24px] p-8"
          >
            <div className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 glow-cyan" />
            <Sparkles className="h-8 w-8 text-[#7C5CFF]" />
            <h3 className="mt-4 font-display text-xl font-bold">Что получите сразу после регистрации</h3>
            <ul className="mt-5 space-y-3 text-[14px] text-[#9AA6BC]">
              <li className="flex gap-2.5"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#22D3EE]" /> Чек-лист «Бесплатный стек нейросетей 2025»</li>
              <li className="flex gap-2.5"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#22D3EE]" /> 20 готовых промптов для работы</li>
              <li className="flex gap-2.5"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#22D3EE]" /> Доступ в чат участников с ИИ-куратором</li>
              <li className="flex gap-2.5"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-[#22D3EE]" /> Скидка 25% на любой курс платформы</li>
            </ul>
            <Link
              to="/courses"
              className="mt-6 inline-flex items-center gap-1.5 text-[14px] font-medium text-[#22D3EE] transition-all hover:gap-2.5"
            >
              Посмотреть курсы <ArrowRight className="h-4 w-4" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Финальный CTA */}
      <section className="relative mx-auto max-w-[1280px] px-6 py-24">
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: EASE }}
          className="gradient-border relative overflow-hidden rounded-[28px] p-10 text-center md:p-16"
        >
          <div className="pointer-events-none absolute -left-24 -top-24 h-[400px] w-[400px] glow-violet animate-drift" />
          <Rocket className="relative mx-auto h-10 w-10 text-[#22D3EE]" />
          <h2 className="relative mt-5 font-display text-3xl font-bold md:text-[40px]">
            Места на поток <span className="text-gradient">ограничены</span>
          </h2>
          <p className="relative mx-auto mt-4 max-w-xl text-[16px] text-[#9AA6BC]">
            Ближайший старт — уже на этой неделе. Займите место сейчас: это бесплатно и ни к чему не обязывает.
          </p>
          <div className="relative mx-auto mt-8 max-w-xl">
            <SignupForm
              name={name}
              email={email}
              pending={pending}
              done={done}
              setName={setName}
              setEmail={setEmail}
              onSubmit={submit}
            />
          </div>
        </motion.div>
      </section>
    </div>
  )
}

/* ─── Форма «Занять место» ─── */
function SignupForm({
  name,
  email,
  pending,
  done,
  setName,
  setEmail,
  onSubmit,
}: {
  name: string
  email: string
  pending: boolean
  done: boolean
  setName: (v: string) => void
  setEmail: (v: string) => void
  onSubmit: (e: React.FormEvent) => void
}) {
  return (
    <AnimatePresence mode="wait">
      {done ? (
        <motion.div
          key="done"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3, ease: EASE }}
          className="glass flex items-center gap-4 rounded-[20px] p-6 text-left"
        >
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#34D399]/15">
            <CheckCircle2 className="h-6 w-6 text-[#34D399]" />
          </span>
          <div>
            <p className="font-display text-[16px] font-bold">Место забронировано!</p>
            <p className="mt-1 text-[14px] text-[#9AA6BC]">
              Письмо со ссылкой и бонусами уже летит на <span className="text-[#F2F5FA]">{email}</span>.
            </p>
          </div>
        </motion.div>
      ) : (
        <motion.form
          key="form"
          exit={{ opacity: 0, scale: 0.97 }}
          onSubmit={onSubmit}
          className="glass flex flex-col gap-3 rounded-[20px] p-4 sm:flex-row sm:items-center"
        >
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Имя"
            className="flex-1 rounded-[12px] border border-white/[0.08] bg-[#0D1117] px-4 py-3.5 text-[15px] text-[#F2F5FA] placeholder-[#5C6B84] focus:border-[#7C5CFF] focus:outline-none focus:shadow-[0_0_24px_rgba(124,92,255,0.25)]"
          />
          <div className="relative flex-1">
            <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#5C6B84]" />
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              className="w-full rounded-[12px] border border-white/[0.08] bg-[#0D1117] py-3.5 pl-10 pr-4 text-[15px] text-[#F2F5FA] placeholder-[#5C6B84] focus:border-[#7C5CFF] focus:outline-none focus:shadow-[0_0_24px_rgba(124,92,255,0.25)]"
            />
          </div>
          <button type="submit" disabled={pending} className="btn-primary whitespace-nowrap disabled:opacity-60">
            {pending ? <Loader2 className="h-5 w-5 animate-spin" /> : <Zap className="h-4 w-4" />}
            {pending ? 'Бронируем…' : 'Занять место'}
          </button>
        </motion.form>
      )}
    </AnimatePresence>
  )
}
