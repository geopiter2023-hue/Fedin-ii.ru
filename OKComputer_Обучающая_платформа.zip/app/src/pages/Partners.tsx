import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowRight,
  BadgePercent,
  Check,
  Copy,
  FileImage,
  Handshake,
  Link2,
  Megaphone,
  Rocket,
  Wallet,
} from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { useAuth } from '@/hooks/useAuth'
import { LOGIN_PATH } from '@/const'
import { cn } from '@/lib/utils'

const ease = [0.16, 1, 0.3, 1] as [number, number, number, number]

const PRODUCTS = [
  { name: 'Промпт-пак', price: 990 },
  { name: 'Нейроклуб (мес)', price: 990 },
  { name: 'Курс «Нейросети для работы»', price: 14900 },
  { name: 'Курс PRO-уровня', price: 35000 },
]

const COMMISSION_ROWS = [
  { product: 'Интенсив-трипваер', price: '990 ₽', commission: '198 ₽', highlight: false },
  { product: 'Промпт-паки', price: '490–990 ₽', commission: '98–198 ₽', highlight: false },
  { product: 'Курс «Нейросети для работы»', price: '14 900 ₽', commission: '2 980 ₽', highlight: false },
  { product: 'Курс PRO-уровня', price: '35 000 ₽', commission: '7 000 ₽', highlight: false },
  { product: 'Менторский тариф', price: '90 000–150 000 ₽', commission: '18 000–30 000 ₽', highlight: false },
  {
    product: 'Нейроклуб (подписка)',
    price: '990 ₽/мес',
    commission: '198 ₽/мес — каждый месяц, пока активна подписка',
    highlight: true,
  },
]

const STEPS = [
  {
    num: '1',
    title: 'Регистрация',
    text: '2 минуты — и у вас уже есть персональная реферальная ссылка. Без договоров и бюрократии.',
    icon: Rocket,
  },
  {
    num: '2',
    title: 'Делитесь',
    text: 'Готовые посты, баннеры и промо-видео — берите в партнёрском кабинете и публикуйте.',
    icon: Megaphone,
  },
  {
    num: '3',
    title: 'Получайте выплаты',
    text: '20% с каждого заказа. Выплаты еженедельно на карту, минимальная сумма — 1 000 ₽.',
    icon: Wallet,
  },
]

const MATERIALS = [
  {
    icon: FileImage,
    title: 'Готовые посты и сторис',
    text: 'Тексты и картинки под Telegram и VK: публикуйте как есть или адаптируйте под себя.',
  },
  {
    icon: Megaphone,
    title: 'Баннеры и промо-видео',
    text: 'Статика и видео всех популярных форматов для каналов, сайтов и рассылок.',
  },
  {
    icon: BadgePercent,
    title: 'Личный промокод −10%',
    text: 'Дополнительный аргумент для вашей аудитории: скидка 10% на все курсы платформы.',
  },
]

const FAQ = [
  {
    q: 'Когда выплаты?',
    a: 'Каждую неделю, по четвергам, на карту любого российского банка. Минимальная сумма выплаты — 1 000 ₽, меньшие суммы накапливаются.',
  },
  {
    q: 'Что если клиент вернул деньги?',
    a: 'Комиссия по возвращённому заказу отменяется. Если выплата уже прошла, сумма вычитается из следующей. Возвраты по нашим курсам — менее 2%.',
  },
  {
    q: 'Можно ли рекламировать в контексте?',
    a: 'Да, контекстная и таргетированная реклама разрешены. Единственное ограничение — нельзя биддить на брендовые запросы «FEDIN AI» и «Федин».',
  },
  {
    q: 'Как отслеживаются продажи?',
    a: 'По реферальной ссылке с cookie на 30 дней: если человек перешёл по ссылке и купил в течение месяца — продажа ваша, даже с другого устройства при входе в аккаунт.',
  },
  {
    q: 'Нужно ли ИП?',
    a: 'Нет. Можно получать выплаты как физлицо (самозанятость — идеальный вариант) или как ИП/юрлицо — по агентскому договору.',
  },
]

/* Мок-данные дашборда */
const MOCK_STATS = [
  { label: 'Переходы', value: '1 240' },
  { label: 'Продажи', value: '36' },
  { label: 'Конверсия', value: '2,9%' },
  { label: 'К выплате', value: '52 400 ₽' },
]

const MOCK_CHART = [12, 18, 14, 22, 19, 28, 24, 32, 27, 38, 34, 30, 42, 39, 48, 44, 52, 47, 58, 53, 61, 57, 66, 62, 70, 68, 76, 72, 81, 86]

const MOCK_SALES = [
  { date: '12 янв', product: 'Курс «Нейросети для работы»', commission: '2 980 ₽', status: 'выплачено' },
  { date: '11 янв', product: 'Нейроклуб (подписка)', commission: '198 ₽', status: 'начислено' },
  { date: '10 янв', product: 'Курс PRO-уровня', commission: '7 000 ₽', status: 'начислено' },
  { date: '9 янв', product: 'Промпт-пак', commission: '198 ₽', status: 'выплачено' },
  { date: '8 янв', product: 'Интенсив-трипваер', commission: '198 ₽', status: 'выплачено' },
]

const fmt = (n: number) => n.toLocaleString('ru-RU')

function AreaChart({ points }: { points: number[] }) {
  const path = useMemo(() => {
    const w = 600
    const h = 180
    const max = Math.max(...points)
    const step = w / (points.length - 1)
    const coords = points.map((p, i) => [i * step, h - (p / max) * (h - 16)] as const)
    const line = coords.map(([x, y], i) => `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`).join(' ')
    return { line, area: `${line} L${w},${h} L0,${h} Z`, w, h }
  }, [points])

  return (
    <svg viewBox={`0 0 ${path.w} ${path.h}`} className="h-44 w-full">
      <defs>
        <linearGradient id="pf-area" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#22D3EE" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#22D3EE" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="pf-line" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#7C5CFF" />
          <stop offset="100%" stopColor="#22D3EE" />
        </linearGradient>
      </defs>
      <path d={path.area} fill="url(#pf-area)" />
      <motion.path
        d={path.line}
        fill="none"
        stroke="url(#pf-line)"
        strokeWidth="2.5"
        initial={{ pathLength: 0 }}
        whileInView={{ pathLength: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1.2, ease: 'easeOut' }}
      />
    </svg>
  )
}

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="glass overflow-hidden rounded-2xl">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left font-medium"
      >
        {q}
        <span
          className={cn(
            'flex h-7 w-7 shrink-0 items-center justify-center rounded-full glass-light transition-transform duration-300',
            open && 'rotate-45'
          )}
        >
          +
        </span>
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease }}
          >
            <p className="px-6 pb-5 text-[15px] text-[#9AA6BC]">{a}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default function Partners() {
  const { isAuthenticated, isLoading } = useAuth()

  const statsQuery = trpc.partners.stats.useQuery(undefined, { enabled: isAuthenticated })
  const linkQuery = trpc.partners.link.useQuery(undefined, { enabled: isAuthenticated })

  const [sales, setSales] = useState(30)
  const [product, setProduct] = useState(PRODUCTS[2])
  const [copied, setCopied] = useState(false)

  const perSale = Math.round(product.price * 0.2)
  const monthly = perSale * sales

  const refUrl = linkQuery.data?.url ?? 'https://fedin-ii.ru/?ref=your-id'

  const copy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
    } catch {
      /* clipboard может быть недоступен */
    }
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const dashStats = statsQuery.data
    ? [
        { label: 'Переходы и продажи', value: fmt(statsQuery.data.referralsCount) },
        { label: 'Всего комиссий', value: `${fmt(statsQuery.data.totalCommission)} ₽` },
        { label: 'Ожидает выплаты', value: `${fmt(statsQuery.data.pendingCommission)} ₽` },
        { label: 'Выплачено', value: `${fmt(statsQuery.data.paidCommission)} ₽` },
      ]
    : MOCK_STATS

  return (
    <div className="relative overflow-x-clip">
      {/* ---------- Hero ---------- */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute left-1/2 top-[-200px] h-[700px] w-[900px] -translate-x-1/2 glow-violet" />
        <svg
          className="pointer-events-none absolute inset-0 h-full w-full opacity-[0.07]"
          aria-hidden
        >
          <defs>
            <pattern id="pf-grid" width="60" height="60" patternUnits="userSpaceOnUse">
              <path d="M60 0H0V60" fill="none" stroke="#22D3EE" strokeWidth="0.6" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#pf-grid)" />
        </svg>
        <div className="relative mx-auto max-w-3xl px-6 pb-20 pt-20 text-center md:pt-28">
          <motion.span
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease }}
            className="chip glass-light text-[#22D3EE]"
          >
            <Handshake className="h-3.5 w-3.5" /> Партнёрская программа
          </motion.span>
          <motion.h1
            initial={{ opacity: 0, y: 28 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1, ease }}
            className="mt-6 font-display text-4xl font-extrabold md:text-6xl"
          >
            Зарабатывайте <span className="text-gradient">20%</span> с каждой продажи
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.25, ease }}
            className="mx-auto mt-6 max-w-xl text-lg text-[#9AA6BC]"
          >
            Рекомендуйте курсы и инструменты FEDIN AI — получайте от 60 ₽ за гайд до 30 000 ₽ за
            менторский тариф. Выплаты каждую неделю на карту.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4, ease }}
            className="mt-9 flex flex-wrap justify-center gap-4"
          >
            <a href={isAuthenticated ? '#partner-dashboard' : LOGIN_PATH} className="btn-primary">
              Стать партнёром — бесплатно
            </a>
            {!isAuthenticated && !isLoading && (
              <Link to={LOGIN_PATH} className="btn-ghost">
                У меня уже есть аккаунт
              </Link>
            )}
          </motion.div>
        </div>
      </section>

      {/* ---------- Калькулятор ---------- */}
      <section className="mx-auto max-w-[1280px] px-6 pb-24">
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.7, ease }}
          className="gradient-border grid gap-10 rounded-[24px] p-8 md:grid-cols-2 md:p-12"
        >
          <div>
            <h2 className="font-display text-2xl font-bold md:text-3xl">
              Сколько можно <span className="text-gradient">заработать</span>
            </h2>
            <div className="mt-8">
              <div className="flex items-baseline justify-between">
                <label className="text-sm font-medium text-[#9AA6BC]">Продаж в месяц</label>
                <span className="font-display text-3xl font-bold text-gradient">{sales}</span>
              </div>
              <input
                type="range"
                min={1}
                max={100}
                value={sales}
                onChange={(e) => setSales(Number(e.target.value))}
                className="mt-4 w-full accent-[#7C5CFF]"
                style={{
                  background: `linear-gradient(90deg, #7C5CFF ${sales}%, rgba(255,255,255,0.1) ${sales}%)`,
                  height: 6,
                  borderRadius: 999,
                  appearance: 'none',
                }}
              />
            </div>
            <div className="mt-8">
              <div className="text-sm font-medium text-[#9AA6BC]">Продукт</div>
              <div className="mt-3 flex flex-wrap gap-2">
                {PRODUCTS.map((p) => (
                  <button
                    key={p.name}
                    onClick={() => setProduct(p)}
                    className={cn(
                      'relative rounded-full px-4 py-2 text-[13px] font-medium transition-colors',
                      product.name === p.name ? 'text-white' : 'glass-light text-[#9AA6BC] hover:text-[#F2F5FA]'
                    )}
                  >
                    {product.name === p.name && (
                      <motion.span
                        layoutId="calc-chip"
                        className="absolute inset-0 rounded-full bg-brand-gradient"
                        transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                      />
                    )}
                    <span className="relative z-10">
                      {p.name} · {fmt(p.price)} ₽
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="flex flex-col items-start justify-center rounded-2xl glass p-8">
            <div className="text-sm text-[#9AA6BC]">Ваша комиссия</div>
            <AnimatePresence mode="popLayout">
              <motion.div
                key={monthly}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -14 }}
                transition={{ duration: 0.25, ease }}
                className="font-display text-4xl font-bold text-gradient md:text-6xl"
              >
                {fmt(monthly)} ₽/мес
              </motion.div>
            </AnimatePresence>
            <div className="mt-3 text-[#9AA6BC]">≈ {fmt(perSale)} ₽ с продажи</div>
            <div className="mt-6 text-[13px] text-[#5C6B84]">
              Расчёт по ставке 20%. Подписка Нейроклуба приносит комиссию каждый месяц, пока
              клиент подписан.
            </div>
          </div>
        </motion.div>
      </section>

      {/* ---------- 3 шага ---------- */}
      <section className="mx-auto max-w-[1280px] px-6 pb-24">
        <h2 className="font-display text-3xl font-bold md:text-4xl">
          Как это <span className="text-gradient">работает</span>
        </h2>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {STEPS.map((s, i) => (
            <motion.div
              key={s.num}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6, delay: i * 0.12, ease }}
              className="glass relative rounded-[20px] p-7"
            >
              <div className="flex items-center justify-between">
                <span className="font-display text-5xl font-bold text-gradient">{s.num}</span>
                <s.icon className="h-6 w-6 text-[#22D3EE]" />
              </div>
              <motion.span
                initial={{ scaleX: 0 }}
                whileInView={{ scaleX: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.3 + i * 0.12, ease }}
                className="mt-4 block h-px w-16 origin-left bg-brand-gradient"
              />
              <h3 className="mt-4 font-display text-xl font-bold">{s.title}</h3>
              <p className="mt-2 text-[15px] text-[#9AA6BC]">{s.text}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ---------- Таблица комиссий ---------- */}
      <section className="bg-[#0D1117]/60 py-24">
        <div className="mx-auto max-w-[1280px] px-6">
          <h2 className="font-display text-3xl font-bold md:text-4xl">
            Комиссии по <span className="text-gradient">продуктам</span>
          </h2>
          <div className="glass mt-10 overflow-hidden rounded-[20px]">
            <div className="grid grid-cols-[1.4fr_1fr_1.4fr] gap-4 border-b border-white/[0.08] px-6 py-4 text-[13px] font-semibold uppercase tracking-wider text-[#5C6B84]">
              <span>Продукт</span>
              <span>Цена</span>
              <span>Ваша комиссия</span>
            </div>
            {COMMISSION_ROWS.map((r, i) => (
              <motion.div
                key={r.product}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-30px' }}
                transition={{ duration: 0.45, delay: i * 0.06, ease }}
                className={cn(
                  'grid grid-cols-[1.4fr_1fr_1.4fr] items-center gap-4 px-6 py-4 text-[15px]',
                  i !== COMMISSION_ROWS.length - 1 && 'border-b border-white/[0.05]',
                  r.highlight &&
                    'm-3 rounded-xl border border-transparent bg-[linear-gradient(#121824,#121824)_padding-box,linear-gradient(135deg,rgba(124,92,255,0.7),rgba(34,211,238,0.7))_border-box] shadow-[0_0_24px_rgba(124,92,255,0.15)]'
                )}
              >
                <span className="font-medium">{r.product}</span>
                <span className="text-[#9AA6BC]">{r.price}</span>
                <span className={cn(r.highlight ? 'font-semibold text-gradient' : 'text-[#22D3EE]')}>
                  {r.commission}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- Материалы ---------- */}
      <section className="mx-auto max-w-[1280px] px-6 py-24">
        <h2 className="font-display text-3xl font-bold md:text-4xl">
          Материалы для <span className="text-gradient">партнёров</span>
        </h2>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {MATERIALS.map((m, i) => (
            <motion.div
              key={m.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6, delay: i * 0.12, ease }}
              className="group glass rounded-[20px] p-7"
            >
              <m.icon className="h-7 w-7 text-[#9AA6BC] transition-colors group-hover:text-[#22D3EE]" />
              <h3 className="mt-4 font-display text-xl font-bold">{m.title}</h3>
              <p className="mt-2 text-[15px] text-[#9AA6BC]">{m.text}</p>
            </motion.div>
          ))}
        </div>
        <div className="mt-8">
          <a href="#partner-dashboard" className="btn-ghost">
            Всё в партнёрском кабинете <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </section>

      {/* ---------- Дашборд ---------- */}
      <section id="partner-dashboard" className="bg-[#0D1117]/60 py-24">
        <div className="mx-auto max-w-[1280px] px-6">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <h2 className="font-display text-3xl font-bold md:text-4xl">
              Дашборд <span className="text-gradient">партнёра</span>
            </h2>
            {!isAuthenticated && (
              <span className="chip glass-light text-[#9AA6BC]">Демо-данные · войдите, чтобы увидеть свои</span>
            )}
          </div>

          {/* Реф-ссылка */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.6, ease }}
            className="gradient-border mt-10 flex flex-col gap-4 rounded-[20px] p-6 md:flex-row md:items-center"
          >
            <div className="flex items-center gap-3 text-[#9AA6BC]">
              <Link2 className="h-5 w-5 shrink-0 text-[#22D3EE]" />
              <span className="text-sm font-medium">Ваша реферальная ссылка</span>
            </div>
            <code className="flex-1 truncate rounded-xl bg-[#07090F] px-4 py-3 font-mono2 text-sm text-[#22D3EE]">
              {isAuthenticated ? refUrl : 'https://fedin-ii.ru/?ref=•••••• (доступна после входа)'}
            </code>
            {isAuthenticated ? (
              <button onClick={() => copy(refUrl)} className="btn-primary shrink-0 px-5 py-3 text-sm">
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                {copied ? 'Скопировано' : 'Копировать'}
              </button>
            ) : (
              <Link to={LOGIN_PATH} className="btn-primary shrink-0 px-5 py-3 text-sm">
                Получить ссылку
              </Link>
            )}
          </motion.div>

          {/* Статы */}
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {dashStats.map((s, i) => (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-40px' }}
                transition={{ duration: 0.5, delay: i * 0.08, ease }}
                className="glass rounded-[20px] p-6"
              >
                <div className="text-[13px] text-[#5C6B84]">{s.label}</div>
                <div className="mt-1 font-display text-2xl font-bold md:text-3xl">{s.value}</div>
              </motion.div>
            ))}
          </div>

          <div className="mt-8 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
            {/* График */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6, ease }}
              className="glass rounded-[20px] p-6"
            >
              <div className="mb-4 flex items-center justify-between">
                <h3 className="font-display text-lg font-bold">Продажи за 30 дней</h3>
                <span className="chip glass-light text-[#34D399]">+18% к прошлому месяцу</span>
              </div>
              <AreaChart points={MOCK_CHART} />
            </motion.div>

            {/* Последние продажи */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6, delay: 0.1, ease }}
              className="glass rounded-[20px] p-6"
            >
              <h3 className="font-display text-lg font-bold">Последние продажи</h3>
              <div className="mt-4 space-y-3">
                {(statsQuery.data?.referrals?.length
                  ? statsQuery.data.referrals.slice(0, 5).map((r: any, i: number) => ({
                      date: r.createdAt ? new Date(r.createdAt).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' }) : `Продажа ${i + 1}`,
                      product: r.product ?? 'Продукт FEDIN AI',
                      commission: `${fmt(Number(r.commission ?? 0))} ₽`,
                      status: r.status === 'paid' ? 'выплачено' : 'начислено',
                    }))
                  : MOCK_SALES
                ).map((s: { date: string; product: string; commission: string; status: string }, i: number) => (
                  <div
                    key={i}
                    className="flex items-center justify-between gap-3 rounded-xl glass-light px-4 py-3 text-[13px]"
                  >
                    <div className="min-w-0">
                      <div className="truncate font-medium">{s.product}</div>
                      <div className="text-[#5C6B84]">{s.date}</div>
                    </div>
                    <div className="shrink-0 text-right">
                      <div className="font-semibold text-[#22D3EE]">{s.commission}</div>
                      <div className={s.status === 'выплачено' ? 'text-[#34D399]' : 'text-[#FBBF24]'}>
                        {s.status}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ---------- FAQ + CTA ---------- */}
      <section className="mx-auto max-w-[1280px] px-6 py-24">
        <div className="grid gap-12 lg:grid-cols-2">
          <div>
            <h2 className="font-display text-3xl font-bold md:text-4xl">
              Частые <span className="text-gradient">вопросы</span>
            </h2>
            <div className="mt-8 space-y-3">
              {FAQ.map((f) => (
                <FaqItem key={f.q} q={f.q} a={f.a} />
              ))}
            </div>
          </div>
          <div className="lg:pl-8">
            <motion.div
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.7, ease }}
              className="gradient-border relative overflow-hidden rounded-[24px] p-8 md:p-10 lg:sticky lg:top-24"
            >
              <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 glow-cyan animate-drift" />
              <h2 className="relative font-display text-2xl font-bold md:text-3xl">
                Начните зарабатывать с <span className="text-gradient">FEDIN AI</span>
              </h2>
              <p className="relative mt-4 text-[#9AA6BC]">
                Регистрация бесплатна, ссылка активна сразу. Первая выплата — уже на следующей
                неделе.
              </p>
              <div className="relative mt-7">
                {isAuthenticated ? (
                  <button onClick={() => copy(refUrl)} className="btn-primary w-full py-4 text-lg">
                    {copied ? <Check className="h-5 w-5" /> : <Copy className="h-5 w-5" />}
                    {copied ? 'Ссылка скопирована!' : 'Копировать мою ссылку'}
                  </button>
                ) : (
                  <Link to={LOGIN_PATH} className="btn-primary w-full py-4 text-lg">
                    Стать партнёром
                  </Link>
                )}
              </div>
              <p className="relative mt-4 text-center text-[13px] text-[#5C6B84]">
                20% с каждой продажи · выплаты еженедельно · cookie 30 дней
              </p>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  )
}
