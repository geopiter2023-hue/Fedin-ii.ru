import { useEffect, useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowRight,
  Check,
  Eye,
  Mail,
  RefreshCcw,
  Search,
  ShieldCheck,
  ShoppingBag,
  ShoppingCart,
  Star,
  Timer,
  Trash2,
  X,
  Zap,
} from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { useAuth } from '@/hooks/useAuth'
import { LOGIN_PATH } from '@/const'
import { cn } from '@/lib/utils'

type Product = {
  id: number
  slug: string
  title: string
  description: string | null
  category: 'prompt-pack' | 'guide' | 'n8n' | 'preset' | 'subscription'
  price: number
  oldPrice: number | null
  cover: string | null
  isHit: boolean
}

const CATEGORIES = [
  { key: 'all', label: 'Все' },
  { key: 'prompt-pack', label: 'Промпт-паки' },
  { key: 'guide', label: 'Гайды' },
  { key: 'n8n', label: 'Автоматизация (n8n)' },
  { key: 'preset', label: 'Пресеты' },
  { key: 'subscription', label: 'Подписки' },
] as const

const CATEGORY_LABEL: Record<Product['category'], string> = {
  'prompt-pack': 'Промпт-пак',
  guide: 'Гайд',
  n8n: 'n8n-связка',
  preset: 'Пресеты',
  subscription: 'Подписка',
}

const COVER_BY_SLUG: Record<string, string> = {
  'prompt-pack-marketolog': '/pack-prompts.png',
  'prompt-pack-hr': '/pack-prompts.png',
  'prompt-pack-rieltor': '/pack-prompts.png',
  '100-promptov-wb-ozon': '/pack-wb.png',
  'guide-oplata-ai-iz-rossii': '/pack-guide.png',
  'n8n-svyazki-avtomatizaciya': '/pack-n8n.png',
  'presety-midjourney-nano-banana': '/pack-presets.png',
  'podpiska-neiroclub': '/ai-twin.png',
}

const COVER_BY_CATEGORY: Record<Product['category'], string> = {
  'prompt-pack': '/pack-prompts.png',
  guide: '/pack-guide.png',
  n8n: '/pack-n8n.png',
  preset: '/pack-presets.png',
  subscription: '/ai-twin.png',
}

const WHAT_INSIDE: Record<Product['category'], string[]> = {
  'prompt-pack': [
    'PDF + Notion-версия с навигацией по темам',
    'Структура: роль → контекст → формат ответа',
    'Готовые переменные под вашу нишу',
    'Бонус: чек-лист качества ответа',
  ],
  guide: [
    'Пошаговые инструкции со скриншотами',
    'Проверенные способы оплаты из России',
    'Сравнение тарифов и сервисов',
    'Обновления при изменении условий',
  ],
  n8n: [
    'Файлы .json — импорт в n8n за минуту',
    'Видео-инструкция по настройке',
    'Комментарии к каждому узлу сценария',
    'Помощь с запуском в комьюнити',
  ],
  preset: [
    'Библиотека стилей с примерами рендеров',
    'Параметры и негативные промпты',
    'Гайд по комбинированию стилей',
    'Новые пресеты — бесплатно',
  ],
  subscription: [
    'Все новые промпт-паки бесплатно',
    'Ежемесячные обновления курсов',
    'Закрытое комьюнити и разборы',
    'Доступ к ИИ-куратору',
  ],
}

type SortKey = 'popular' | 'cheap' | 'expensive'

export function coverFor(p: Pick<Product, 'slug' | 'category'>) {
  return COVER_BY_SLUG[p.slug] ?? COVER_BY_CATEGORY[p.category]
}

export function formatPrice(kopecks: number) {
  return `${(kopecks / 100).toLocaleString('ru-RU')} ₽`
}

const CART_KEY = 'fedin-shop-cart'

function loadCart(): number[] {
  try {
    const raw = localStorage.getItem(CART_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    return Array.isArray(parsed) ? parsed.filter((x) => typeof x === 'number') : []
  } catch {
    return []
  }
}

function useCountdown() {
  const [left, setLeft] = useState(23 * 3600 + 41 * 60 + 7)
  useEffect(() => {
    const t = setInterval(() => setLeft((s) => (s > 0 ? s - 1 : 24 * 3600)), 1000)
    return () => clearInterval(t)
  }, [])
  const h = String(Math.floor(left / 3600)).padStart(2, '0')
  const m = String(Math.floor((left % 3600) / 60)).padStart(2, '0')
  const s = String(left % 60).padStart(2, '0')
  return `${h}:${m}:${s}`
}

function SkeletonCard() {
  return (
    <div className="animate-pulse rounded-[20px] glass-light p-3">
      <div className="aspect-[4/5] rounded-2xl bg-white/5" />
      <div className="mt-4 h-3 w-20 rounded bg-white/5" />
      <div className="mt-2 h-4 w-3/4 rounded bg-white/5" />
      <div className="mt-3 h-9 w-full rounded-[14px] bg-white/5" />
    </div>
  )
}

export default function Shop() {
  const navigate = useNavigate()
  const { isAuthenticated } = useAuth()
  const { data, isLoading } = trpc.products.list.useQuery()
  const checkout = trpc.shop.checkout.useMutation()

  const [category, setCategory] = useState<(typeof CATEGORIES)[number]['key']>('all')
  const [query, setQuery] = useState('')
  const [sort, setSort] = useState<SortKey>('popular')
  const [quickView, setQuickView] = useState<Product | null>(null)
  const [cartOpen, setCartOpen] = useState(false)
  const [cart, setCart] = useState<number[]>(() => loadCart())
  const [cartBounce, setCartBounce] = useState(0)
  const [orderDone, setOrderDone] = useState(false)
  const [buying, setBuying] = useState(false)
  const timer = useCountdown()

  useEffect(() => {
    localStorage.setItem(CART_KEY, JSON.stringify(cart))
  }, [cart])

  const products = (data ?? []) as Product[]
  const hit = useMemo(
    () => products.find((p) => p.slug === '100-promptov-wb-ozon') ?? products.find((p) => p.isHit),
    [products]
  )

  const filtered = useMemo(() => {
    let list = products.filter((p) => p.category !== 'subscription')
    if (category !== 'all') list = list.filter((p) => p.category === category)
    if (query.trim()) {
      const q = query.trim().toLowerCase()
      list = list.filter(
        (p) =>
          p.title.toLowerCase().includes(q) || (p.description ?? '').toLowerCase().includes(q)
      )
    }
    if (sort === 'cheap') list = [...list].sort((a, b) => a.price - b.price)
    if (sort === 'expensive') list = [...list].sort((a, b) => b.price - a.price)
    if (sort === 'popular') list = [...list].sort((a, b) => Number(b.isHit) - Number(a.isHit))
    return list
  }, [products, category, query, sort])

  const cartProducts = useMemo(
    () => cart.map((id) => products.find((p) => p.id === id)).filter(Boolean) as Product[],
    [cart, products]
  )
  const total = cartProducts.reduce((s, p) => s + p.price, 0)

  const addToCart = (p: Product) => {
    setCart((c) => (c.includes(p.id) ? c : [...c, p.id]))
    setCartBounce((n) => n + 1)
  }
  const removeFromCart = (id: number) => setCart((c) => c.filter((x) => x !== id))

  const buyNow = async (items: Product[]) => {
    if (!isAuthenticated) {
      navigate(LOGIN_PATH)
      return
    }
    setBuying(true)
    try {
      for (const item of items) {
        await checkout.mutateAsync({ itemType: 'product', itemId: item.id })
      }
      setCart((c) => c.filter((id) => !items.some((i) => i.id === id)))
      setOrderDone(true)
    } catch {
      // ошибка останется видна через isError ниже
    } finally {
      setBuying(false)
    }
  }

  return (
    <div className="relative overflow-hidden pb-24">
      {/* фоновые свечения */}
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[700px] w-[700px] -translate-x-1/2 glow-violet animate-drift" />
      <div className="pointer-events-none absolute right-[-200px] top-[600px] h-[600px] w-[600px] glow-cyan" />

      {/* Шапка */}
      <section className="relative mx-auto max-w-[1280px] px-6 pt-24 pb-10">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <motion.h1
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="font-display text-4xl font-extrabold md:text-6xl"
            >
              Магазин <span className="text-gradient">инструментов</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.5 }}
              className="mt-4 max-w-xl text-lg text-[#9AA6BC]"
            >
              Готовые промпты, шаблоны и автоматизации. Купил — применил за 10 минут.
            </motion.p>
          </div>
          <motion.button
            key={cartBounce}
            initial={{ scale: cartBounce ? 1.25 : 1 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 400, damping: 12 }}
            onClick={() => setCartOpen(true)}
            className="relative flex items-center gap-2 rounded-[14px] glass px-5 py-3 font-semibold text-[#F2F5FA] transition-colors hover:border-[#7C5CFF]"
          >
            <ShoppingCart className="h-5 w-5" />
            Корзина
            {cart.length > 0 && (
              <span className="absolute -right-2 -top-2 flex h-6 min-w-6 items-center justify-center rounded-full bg-brand-gradient px-1.5 text-[12px] font-bold text-white">
                {cart.length}
              </span>
            )}
          </motion.button>
        </div>
      </section>

      {/* Хитовая полоса */}
      {!isLoading && hit && (
        <motion.section
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.55 }}
          className="relative mx-auto max-w-[1280px] px-6"
        >
          <div className="gradient-border grid gap-8 rounded-[24px] p-6 md:grid-cols-[260px_1fr] md:p-8">
            <img
              src={coverFor(hit)}
              alt={hit.title}
              className="aspect-[4/5] w-full rounded-2xl object-cover"
            />
            <div className="flex flex-col justify-center">
              <div className="flex flex-wrap items-center gap-3">
                <span className="chip bg-brand-gradient font-bold text-white">Продукт недели</span>
                <span className="chip bg-[#F87171]/15 font-mono2 text-[#F87171]">
                  <Timer className="h-3.5 w-3.5" /> До конца акции: {timer}
                </span>
              </div>
              <h2 className="mt-4 font-display text-2xl font-bold md:text-3xl">{hit.title}</h2>
              <ul className="mt-4 space-y-2 text-[#9AA6BC]">
                {['SEO-описания за 2 минуты', 'Инфографика-промпты', 'Обновления бесплатно'].map(
                  (b) => (
                    <li key={b} className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-[#34D399]" /> {b}
                    </li>
                  )
                )}
              </ul>
              <div className="mt-6 flex flex-wrap items-center gap-4">
                <button
                  onClick={() => buyNow([hit])}
                  disabled={buying}
                  className="btn-primary disabled:opacity-60"
                >
                  {buying ? 'Оформляем…' : `Купить за ${formatPrice(hit.price)}`}
                </button>
                {hit.oldPrice && (
                  <span className="text-lg text-[#5C6B84] line-through">
                    {formatPrice(hit.oldPrice)}
                  </span>
                )}
                <button onClick={() => addToCart(hit)} className="btn-ghost py-3">
                  В корзину
                </button>
              </div>
            </div>
          </div>
        </motion.section>
      )}

      {/* Липкая панель фильтров */}
      <div className="sticky top-[72px] z-40 mt-12 border-y border-white/[0.06] bg-[#07090F]/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1280px] flex-wrap items-center gap-3 px-6 py-3">
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.filter((c) => c.key !== 'subscription').map((c) => (
              <button
                key={c.key}
                onClick={() => setCategory(c.key)}
                className={cn(
                  'relative rounded-full px-4 py-1.5 text-[13px] font-medium transition-colors',
                  category === c.key
                    ? 'text-white'
                    : 'glass-light text-[#9AA6BC] hover:text-[#F2F5FA]'
                )}
              >
                {category === c.key && (
                  <motion.span
                    layoutId="shop-chip"
                    className="absolute inset-0 rounded-full bg-brand-gradient"
                    transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                  />
                )}
                <span className="relative z-10">{c.label}</span>
              </button>
            ))}
          </div>
          <div className="ml-auto flex flex-wrap items-center gap-3">
            <label className="flex items-center gap-2 rounded-[12px] glass-light px-3 py-2">
              <Search className="h-4 w-4 text-[#5C6B84]" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Искать инструмент…"
                className="w-40 bg-transparent text-sm text-[#F2F5FA] outline-none placeholder:text-[#5C6B84]"
              />
            </label>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as SortKey)}
              className="rounded-[12px] border border-white/[0.08] bg-[#0D1117] px-3 py-2 text-sm text-[#9AA6BC] outline-none"
            >
              <option value="popular">Популярные</option>
              <option value="cheap">Дешевле</option>
              <option value="expensive">Дороже</option>
            </select>
          </div>
        </div>
      </div>

      {/* Сетка продуктов */}
      <section className="mx-auto mt-10 max-w-[1280px] px-6">
        {isLoading ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="rounded-[24px] glass-light py-20 text-center">
            <ShoppingBag className="mx-auto h-10 w-10 text-[#5C6B84]" />
            <p className="mt-4 text-lg text-[#9AA6BC]">Ничего не нашли. Попробуйте другой запрос.</p>
            <button
              onClick={() => {
                setQuery('')
                setCategory('all')
              }}
              className="btn-ghost mt-6 py-2.5 text-sm"
            >
              Сбросить фильтры
            </button>
          </div>
        ) : (
          <motion.div layout className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            <AnimatePresence mode="popLayout">
              {filtered.map((p, i) => (
                <motion.article
                  key={p.id}
                  layout
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.96 }}
                  transition={{ duration: 0.35, delay: Math.min(i * 0.06, 0.4) }}
                  whileHover={{ y: -5 }}
                  className="group relative flex flex-col rounded-[20px] glass-light p-3 transition-colors hover:border-[#7C5CFF]/50"
                >
                  <Link to={`/shop/${p.slug}`} className="relative block overflow-hidden rounded-2xl">
                    <img
                      src={coverFor(p)}
                      alt={p.title}
                      loading="lazy"
                      className="aspect-[4/5] w-full object-cover transition-transform duration-300 group-hover:scale-[1.04]"
                    />
                    {p.isHit && (
                      <span className="absolute left-3 top-3 chip bg-[#F87171]/90 py-1 text-[12px] font-bold text-white">
                        Хит
                      </span>
                    )}
                    <button
                      onClick={(e) => {
                        e.preventDefault()
                        setQuickView(p)
                      }}
                      aria-label="Быстрый просмотр"
                      className="absolute bottom-3 right-3 flex h-10 w-10 items-center justify-center rounded-full glass opacity-0 transition-opacity duration-200 group-hover:opacity-100"
                    >
                      <Eye className="h-4.5 w-4.5" />
                    </button>
                  </Link>
                  <span className="mt-3 text-[12px] font-medium uppercase tracking-wider text-[#22D3EE]">
                    {CATEGORY_LABEL[p.category]}
                  </span>
                  <Link to={`/shop/${p.slug}`}>
                    <h3 className="mt-1 font-display text-[15px] font-bold leading-snug hover:text-[#22D3EE]">
                      {p.title}
                    </h3>
                  </Link>
                  <p className="mt-1 line-clamp-1 text-sm text-[#5C6B84]">{p.description}</p>
                  <div className="mt-2 flex items-center gap-1 text-[13px] text-[#FBBF24]">
                    <Star className="h-3.5 w-3.5 fill-current" /> 4.9
                    <span className="text-[#5C6B84]">· 120+ покупок</span>
                  </div>
                  <div className="mt-3 flex items-baseline gap-2">
                    <span className="font-display text-lg font-bold">{formatPrice(p.price)}</span>
                    {p.oldPrice && (
                      <span className="text-sm text-[#5C6B84] line-through">
                        {formatPrice(p.oldPrice)}
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => addToCart(p)}
                    disabled={cart.includes(p.id)}
                    className={cn(
                      'btn-primary mt-3 w-full py-2.5 text-sm',
                      cart.includes(p.id) && 'opacity-70'
                    )}
                  >
                    {cart.includes(p.id) ? (
                      <>
                        <Check className="h-4 w-4" /> В корзине
                      </>
                    ) : (
                      <>
                        <ShoppingCart className="h-4 w-4" /> В корзину
                      </>
                    )}
                  </button>
                </motion.article>
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </section>

      {/* Кросс-сейл Нейроклуба */}
      <motion.section
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-60px' }}
        transition={{ duration: 0.5 }}
        className="mx-auto mt-16 max-w-[1280px] px-6"
      >
        <div className="gradient-border relative overflow-hidden rounded-[24px] p-8 md:p-10">
          <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 glow-violet animate-drift" />
          <div className="flex flex-wrap items-center justify-between gap-6">
            <div className="max-w-xl">
              <span className="chip bg-ai-gradient font-bold text-white">
                <Zap className="h-3.5 w-3.5" /> Нейроклуб
              </span>
              <h2 className="mt-4 font-display text-2xl font-bold md:text-3xl">
                Все новые промпт-паки — <span className="text-gradient">бесплатно</span> в
                Нейроклубе за 990 ₽/мес
              </h2>
              <ul className="mt-4 space-y-2 text-[#9AA6BC]">
                {[
                  'Ежемесячные обновления курсов',
                  'Новые промпт-паки каждый месяц',
                  'Закрытое комьюнити и разборы',
                ].map((b) => (
                  <li key={b} className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-[#34D399]" /> {b}
                  </li>
                ))}
              </ul>
            </div>
            <Link to="/club" className="btn-ghost">
              Подробнее <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </motion.section>

      {/* Гарантии */}
      <section className="mx-auto mt-16 max-w-[1280px] px-6">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            { icon: Mail, title: 'Мгновенная доставка', text: 'Файлы приходят на email и в кабинет сразу после оплаты' },
            { icon: ShieldCheck, title: 'Возврат 14 дней', text: 'Если инструмент не подошёл — вернём деньги без вопросов' },
            { icon: RefreshCcw, title: 'Бесплатные обновления', text: 'Все новые версии купленных продуктов — навсегда бесплатно' },
          ].map((g, i) => (
            <motion.div
              key={g.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.45 }}
              className="flex items-start gap-4 rounded-[20px] glass-light p-6"
            >
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-gradient text-white">
                <g.icon className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-display text-[15px] font-bold">{g.title}</h3>
                <p className="mt-1 text-sm text-[#9AA6BC]">{g.text}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Quick-view модалка */}
      <AnimatePresence>
        {quickView && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[70] flex items-center justify-center bg-[rgba(4,6,10,0.7)] p-4 backdrop-blur-sm"
            onClick={() => setQuickView(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ duration: 0.25 }}
              onClick={(e) => e.stopPropagation()}
              className="relative grid max-h-[90vh] w-full max-w-[900px] gap-8 overflow-y-auto rounded-[24px] glass p-6 md:grid-cols-2 md:p-8"
            >
              <button
                onClick={() => setQuickView(null)}
                aria-label="Закрыть"
                className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full glass-light"
              >
                <X className="h-5 w-5" />
              </button>
              <div>
                <img
                  src={coverFor(quickView)}
                  alt={quickView.title}
                  className="aspect-[4/5] w-full rounded-2xl object-cover"
                />
              </div>
              <div className="flex flex-col">
                <span className="text-[12px] font-medium uppercase tracking-wider text-[#22D3EE]">
                  {CATEGORY_LABEL[quickView.category]}
                </span>
                <h3 className="mt-2 font-display text-2xl font-bold">{quickView.title}</h3>
                <div className="mt-2 flex items-center gap-1 text-sm text-[#FBBF24]">
                  <Star className="h-4 w-4 fill-current" /> 4.9
                  <span className="text-[#5C6B84]">· 120+ покупок</span>
                </div>
                <p className="mt-3 text-[#9AA6BC]">{quickView.description}</p>
                <h4 className="mt-5 font-display text-sm font-bold uppercase tracking-wider text-[#F2F5FA]">
                  Что внутри
                </h4>
                <ul className="mt-2 space-y-2 text-sm text-[#9AA6BC]">
                  {WHAT_INSIDE[quickView.category].map((w) => (
                    <li key={w} className="flex items-start gap-2">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-[#34D399]" /> {w}
                    </li>
                  ))}
                </ul>
                <p className="mt-4 text-sm text-[#5C6B84]">
                  Формат: PDF / JSON / Notion · Мгновенная доставка на email и в кабинет
                </p>
                <div className="mt-5 flex items-baseline gap-3">
                  <span className="font-display text-3xl font-bold">
                    {formatPrice(quickView.price)}
                  </span>
                  {quickView.oldPrice && (
                    <span className="text-lg text-[#5C6B84] line-through">
                      {formatPrice(quickView.oldPrice)}
                    </span>
                  )}
                </div>
                <div className="mt-5 flex flex-wrap gap-3">
                  <button
                    onClick={() => buyNow([quickView])}
                    disabled={buying}
                    className="btn-primary disabled:opacity-60"
                  >
                    {buying ? 'Оформляем…' : 'Купить сейчас'}
                  </button>
                  <button onClick={() => addToCart(quickView)} className="btn-ghost">
                    В корзину
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Корзина (drawer) */}
      <AnimatePresence>
        {cartOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="fixed inset-0 z-[80] bg-[rgba(4,6,10,0.7)] backdrop-blur-sm"
              onClick={() => setCartOpen(false)}
            />
            <motion.aside
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', stiffness: 320, damping: 34 }}
              className="fixed right-0 top-0 z-[90] flex h-full w-full max-w-[420px] flex-col border-l border-white/[0.08] bg-[#0D1117]"
            >
              <div className="flex items-center justify-between border-b border-white/[0.08] p-5">
                <h3 className="font-display text-lg font-bold">Корзина</h3>
                <button
                  onClick={() => setCartOpen(false)}
                  aria-label="Закрыть корзину"
                  className="flex h-9 w-9 items-center justify-center rounded-xl glass-light"
                >
                  <X className="h-4.5 w-4.5" />
                </button>
              </div>

              {orderDone ? (
                <div className="flex flex-1 flex-col items-center justify-center p-8 text-center">
                  <motion.div
                    initial={{ scale: 0.6, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="flex h-16 w-16 items-center justify-center rounded-full bg-[#34D399]/15 text-[#34D399]"
                  >
                    <Check className="h-8 w-8" />
                  </motion.div>
                  <h4 className="mt-5 font-display text-xl font-bold">Покупка оформлена</h4>
                  <p className="mt-2 text-sm text-[#9AA6BC]">
                    Файлы уже ждут вас в личном кабинете и продублированы на email.
                  </p>
                  <Link to="/dashboard" className="btn-primary mt-6" onClick={() => setCartOpen(false)}>
                    Перейти в кабинет
                  </Link>
                  <button
                    onClick={() => setOrderDone(false)}
                    className="mt-3 text-sm text-[#9AA6BC] hover:text-[#F2F5FA]"
                  >
                    Продолжить покупки
                  </button>
                </div>
              ) : cartProducts.length === 0 ? (
                <div className="flex flex-1 flex-col items-center justify-center p-8 text-center">
                  <ShoppingBag className="h-12 w-12 text-[#5C6B84]" />
                  <p className="mt-4 text-[#9AA6BC]">
                    Пока пусто.{' '}
                    <button
                      onClick={() => {
                        setCategory('prompt-pack')
                        setCartOpen(false)
                      }}
                      className="text-[#22D3EE] hover:underline"
                    >
                      Загляните в промпт-паки →
                    </button>
                  </p>
                </div>
              ) : (
                <>
                  <div className="flex-1 space-y-3 overflow-y-auto p-5">
                    <AnimatePresence initial={false}>
                      {cartProducts.map((p) => (
                        <motion.div
                          key={p.id}
                          layout
                          exit={{ opacity: 0, height: 0, marginBottom: 0 }}
                          className="flex items-center gap-3 overflow-hidden rounded-2xl glass-light p-3"
                        >
                          <img
                            src={coverFor(p)}
                            alt={p.title}
                            className="h-16 w-14 rounded-xl object-cover"
                          />
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-sm font-semibold">{p.title}</p>
                            <p className="text-sm text-[#22D3EE]">{formatPrice(p.price)}</p>
                          </div>
                          <button
                            onClick={() => removeFromCart(p.id)}
                            aria-label="Удалить"
                            className="flex h-9 w-9 items-center justify-center rounded-xl text-[#5C6B84] transition-colors hover:bg-white/5 hover:text-[#F87171]"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>
                  <div className="border-t border-white/[0.08] p-5">
                    <input
                      placeholder="Промокод"
                      className="w-full rounded-[12px] border border-white/[0.08] bg-[#07090F] px-4 py-3 text-sm outline-none placeholder:text-[#5C6B84] focus:border-[#7C5CFF]"
                    />
                    <div className="mt-4 flex items-center justify-between">
                      <span className="text-[#9AA6BC]">Итого</span>
                      <motion.span
                        key={total}
                        initial={{ opacity: 0, y: -6 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="font-display text-xl font-bold"
                      >
                        {formatPrice(total)}
                      </motion.span>
                    </div>
                    <button
                      onClick={() => buyNow(cartProducts)}
                      disabled={buying}
                      className="btn-primary mt-4 w-full disabled:opacity-60"
                    >
                      {buying ? 'Оформляем…' : `Оформить — ${formatPrice(total)}`}
                    </button>
                    {checkout.isError && (
                      <p className="mt-2 text-center text-sm text-[#F87171]">
                        Не удалось оформить заказ. Попробуйте ещё раз.
                      </p>
                    )}
                    <p className="mt-3 text-center text-[13px] text-[#5C6B84]">
                      Оплата картой/СБП · Мгновенная доставка
                    </p>
                  </div>
                </>
              )}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
