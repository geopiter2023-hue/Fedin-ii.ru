import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowRight, CalendarDays, Search, ShieldCheck, ShieldX, User } from 'lucide-react'
import { trpc } from '@/providers/trpc'

const EASE = [0.16, 1, 0.3, 1] as [number, number, number, number]

export default function Verify() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const [code, setCode] = useState('')

  const query = trpc.certificates.verify.useQuery(
    { verifyCode: id ?? '' },
    { enabled: !!id, retry: false }
  )

  return (
    <div className="relative flex min-h-[70vh] items-center justify-center px-6 py-16">
      {/* свечения */}
      <div className="pointer-events-none absolute left-1/2 top-1/3 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2 glow-violet blur-3xl" />
      <div className="pointer-events-none absolute bottom-0 right-0 h-[400px] w-[400px] glow-cyan blur-3xl" />

      {query.isLoading ? (
        <div className="w-full max-w-[560px] rounded-[24px] glass p-10">
          <div className="mx-auto h-14 w-14 animate-pulse rounded-full bg-white/5" />
          <div className="mx-auto mt-6 h-7 w-64 animate-pulse rounded-lg bg-white/5" />
          <div className="mt-8 aspect-[16/10] animate-pulse rounded-2xl bg-white/5" />
          <div className="mt-8 space-y-3">
            <div className="h-4 w-full animate-pulse rounded bg-white/5" />
            <div className="h-4 w-2/3 animate-pulse rounded bg-white/5" />
          </div>
        </div>
      ) : query.data ? (
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: EASE }}
          className="w-full max-w-[560px] rounded-[24px] glass p-8 text-center md:p-10"
        >
          {/* бейдж подлинности */}
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.15, type: 'spring', stiffness: 220, damping: 14 }}
            className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#34D399]/15 shadow-[0_0_32px_rgba(52,211,153,0.3)]"
          >
            <ShieldCheck className="h-8 w-8 text-[#34D399]" />
          </motion.div>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="chip mx-auto mt-5 w-fit bg-[#34D399]/15 text-[#34D399]"
          >
            <ShieldCheck className="h-4 w-4" /> Сертификат подлинный
          </motion.div>

          <div className="mt-7 overflow-hidden rounded-2xl border border-white/10">
            <img src="/certificate-template.png" alt="Сертификат FEDIN AI" className="aspect-[16/10] w-full object-cover" />
          </div>

          <div className="mt-7 space-y-4 text-left">
            <div className="flex items-center gap-3 rounded-2xl bg-white/[0.03] p-4">
              <User className="h-5 w-5 shrink-0 text-[#7C5CFF]" />
              <div>
                <div className="text-[12px] text-[#5C6B84]">Владелец</div>
                <div className="font-semibold">{query.data.userName}</div>
              </div>
            </div>
            <div className="flex items-center gap-3 rounded-2xl bg-white/[0.03] p-4">
              <ShieldCheck className="h-5 w-5 shrink-0 text-[#22D3EE]" />
              <div>
                <div className="text-[12px] text-[#5C6B84]">Курс</div>
                <div className="font-semibold">{query.data.courseTitle}</div>
              </div>
            </div>
            <div className="flex items-center gap-3 rounded-2xl bg-white/[0.03] p-4">
              <CalendarDays className="h-5 w-5 shrink-0 text-[#FBBF24]" />
              <div>
                <div className="text-[12px] text-[#5C6B84]">Дата выдачи · Номер</div>
                <div className="font-semibold">
                  {new Date(query.data.issuedAt).toLocaleDateString('ru-RU', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                  })}{' '}
                  · № {query.data.verifyCode}
                </div>
              </div>
            </div>
          </div>

          <Link to="/courses" className="btn-ghost mt-8 w-full">
            Смотреть курсы FEDIN AI <ArrowRight className="h-4 w-4" />
          </Link>
        </motion.div>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: EASE }}
          className="w-full max-w-[560px] rounded-[24px] glass p-8 text-center md:p-10"
        >
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#F87171]/15 shadow-[0_0_32px_rgba(248,113,113,0.25)]">
            <ShieldX className="h-8 w-8 text-[#F87171]" />
          </div>
          <h1 className="mt-6 font-display text-2xl font-bold">Сертификат не найден</h1>
          <p className="mt-3 text-sm text-[#9AA6BC]">
            Проверьте номер: он указан внизу сертификата и в ссылке вида fedin-ii.ru/verify/НОМЕР.
          </p>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              const v = code.trim()
              if (v) navigate(`/verify/${encodeURIComponent(v)}`)
            }}
            className="mt-7 flex gap-2"
          >
            <input
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Введите номер сертификата"
              className="h-12 flex-1 rounded-xl border border-white/[0.08] bg-[#0D1117] px-4 text-sm placeholder:text-[#5C6B84] focus:border-[#7C5CFF] focus:outline-none"
            />
            <button type="submit" className="btn-primary !px-5 !py-0 h-12" aria-label="Проверить">
              <Search className="h-4 w-4" />
            </button>
          </form>
          <Link to="/courses" className="mt-6 inline-flex items-center gap-1.5 text-sm font-medium text-[#22D3EE]">
            Смотреть курсы FEDIN AI <ArrowRight className="h-4 w-4" />
          </Link>
        </motion.div>
      )}
    </div>
  )
}
