import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowRight,
  Check,
  ChevronDown,
  Minus,
  RefreshCcw,
  Sparkles,
  Users,
  Video,
  Zap,
} from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { useAuth } from '@/hooks/useAuth'
import { LOGIN_PATH } from '@/const'
import { coverFor, formatPrice } from '@/pages/Shop'

const BENEFITS = [
  {
    icon: RefreshCcw,
    title: 'Ежемесячные обновления курсов',
    text: 'Новые уроки и свежие версии всех купленных курсов — без доплат.',
  },
  {
    icon: Sparkles,
    title: 'Новые промпт-паки бесплатно',
    text: 'Каждый месяц новый пак под профессии. В магазине они стоят 490–990 ₽.',
  },
  {
    icon: Users,
    title: 'Закрытое комьюнити',
    text: 'Telegram-чат с экспертом и участниками: разборы, нетворкинг, ответы на вопросы.',
  },
  {
    icon: Video,
    title: 'Закрытые разборы',
    text: 'Живые эфиры раз в месяц: разбираем ваши проекты, промпты и автоматизации.',
  },
]

const COMPARISON = [
  { feature: 'Новые промпт-паки каждый месяц', once: false, club: true },
  { feature: 'Обновления курсов', once: 'Только купленных', club: true },
  { feature: 'Закрытое комьюнити и разборы', once: false, club: true },
  { feature: 'Доступ к ИИ-куратору', once: false, club: true },
  { feature: 'Файлы остаются навсегда', once: true, club: true },
  { feature: 'Цена', once: 'от 299 ₽ за продукт', club: '990 ₽/мес, отмена в 1 клик' },
]

const FAQ = [
  {
    q: 'Что входит в подписку Нейроклуба?',
    a: 'Ежемесячные обновления всех курсов, новые промпт-паки бесплатно, закрытое комьюнити с экспертом, живые разборы и доступ к ИИ-куратору.',
  },
  {
    q: 'Могу ли я отменить подписку в любой момент?',
    a: 'Да, отмена в один клик в личном кабинете. Доступ сохраняется до конца оплаченного периода, никаких скрытых списаний.',
  },
  {
    q: 'Чем подписка выгоднее разовой покупки?',
    a: 'Один промпт-пак стоит 490–990 ₽. За ту же цену в Нейроклубе вы получаете все новые паки месяца, обновления курсов и комьюнити.',
  },
  {
    q: 'Как оплатить из России?',
    a: 'Картой любого российского банка или через СБП. Списание — 990 ₽ раз в месяц, без VPN и зарубежных карт.',
  },
  {
    q: 'Я новичок, мне подойдёт?',
    a: 'Да. Клуб рассчитан и на новичков: начните с базовых промпт-паков, задавайте вопросы в чате и приходите на разборы.',
  },
]

export default function Club() {
  const navigate = useNavigate()
  const { isAuthenticated } = useAuth()
  const { data: products, isLoading } = trpc.products.list.useQuery({ category: 'subscription' })
  const checkout = trpc.shop.checkout.useMutation()
  const [openFaq, setOpenFaq] = useState<number | null>(0)
  const [done, setDone] = useState(false)
  const [buying, setBuying] = useState(false)

  const subscription = products?.[0]

  const subscribe = async () => {
    if (!isAuthenticated) {
      navigate(LOGIN_PATH)
      return
    }
    if (!subscription) return
    setBuying(true)
    try {
      await checkout.mutateAsync({ itemType: 'product', itemId: subscription.id })
      setDone(true)
    } catch {
      // ошибка видна ниже
    } finally {
      setBuying(false)
    }
  }

  return (
    <div className="relative overflow-hidden pb-24">
      <div className="pointer-events-none absolute -top-40 left-1/3 h-[700px] w-[700px] glow-violet animate-drift" />
      <div className="pointer-events-none absolute right-[-160px] top-[700px] h-[500px] w-[500px] glow-cyan" />

      {/* Hero */}
      <section className="relative mx-auto max-w-[1280px] px-6 pt-24 text-center">
        <motion.span
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="chip bg-ai-gradient font-bold text-white"
        >
          <Zap className="h-3.5 w-3.5" /> Подписка FEDIN AI
        </motion.span>
        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="mx-auto mt-6 max-w-3xl font-display text-4xl font-extrabold md:text-6xl"
        >
          <span className="text-gradient">Нейроклуб</span> — вся платформа за 990 ₽/мес
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.5 }}
          className="mx-auto mt-5 max-w-2xl text-lg text-[#9AA6BC]"
        >
          Обновления курсов, новые промпт-паки каждый месяц и закрытое комьюнити. Дешевле одного
          промпт-пака.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35, duration: 0.5 }}
          className="gradient-border mx-auto mt-10 flex max-w-md flex-col items-center rounded-[24px] p-8"
        >
          {isLoading ? (
            <div className="h-32 w-full animate-pulse rounded-2xl bg-white/5" />
          ) : done ? (
            <div className="text-center">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-[#34D399]/15 text-[#34D399]">
                <Check className="h-7 w-7" />
              </div>
              <p className="mt-4 font-display text-xl font-bold">Вы в Нейроклубе!</p>
              <p className="mt-2 text-sm text-[#9AA6BC]">
                Подписка активна, материалы уже в кабинете.
              </p>
            </div>
          ) : (
            <>
              {subscription && (
                <img
                  src={coverFor(subscription)}
                  alt="Нейроклуб"
                  className="h-24 w-24 rounded-2xl object-cover"
                />
              )}
              <div className="mt-4 flex items-baseline gap-2">
                <span className="font-display text-5xl font-extrabold">
                  {subscription ? formatPrice(subscription.price) : '990 ₽'}
                </span>
                <span className="text-[#9AA6BC]">/мес</span>
              </div>
              <button
                onClick={subscribe}
                disabled={buying || isLoading}
                className="btn-primary mt-6 w-full disabled:opacity-60"
              >
                {buying ? 'Оформляем…' : 'Вступить в Нейроклуб'} <ArrowRight className="h-4 w-4" />
              </button>
              {checkout.isError && (
                <p className="mt-3 text-sm text-[#F87171]">
                  Не удалось оформить подписку. Попробуйте ещё раз.
                </p>
              )}
              <p className="mt-3 text-[13px] text-[#5C6B84]">
                Карта или СБП · Отмена в любой момент
              </p>
            </>
          )}
        </motion.div>
      </section>

      {/* Преимущества */}
      <section className="mx-auto mt-20 max-w-[1280px] px-6">
        <h2 className="text-center font-display text-3xl font-bold md:text-4xl">
          Что даёт <span className="text-gradient">подписка</span>
        </h2>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {BENEFITS.map((b, i) => (
            <motion.div
              key={b.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.45 }}
              className="rounded-[20px] glass-light p-6 transition-colors hover:border-[#7C5CFF]/50"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-gradient text-white">
                <b.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-display text-[16px] font-bold leading-snug">{b.title}</h3>
              <p className="mt-2 text-sm text-[#9AA6BC]">{b.text}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Сравнение */}
      <section className="mx-auto mt-20 max-w-[900px] px-6">
        <h2 className="text-center font-display text-3xl font-bold md:text-4xl">
          Подписка vs <span className="text-gradient">разовая покупка</span>
        </h2>
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mt-10 overflow-hidden rounded-[24px] glass"
        >
          <div className="grid grid-cols-[1.4fr_1fr_1fr] border-b border-white/[0.08] bg-white/[0.03] px-6 py-4 text-sm font-semibold">
            <span className="text-[#5C6B84]">Возможность</span>
            <span className="text-center text-[#9AA6BC]">Разовая покупка</span>
            <span className="text-center text-gradient font-bold">Нейроклуб</span>
          </div>
          {COMPARISON.map((row) => (
            <div
              key={row.feature}
              className="grid grid-cols-[1.4fr_1fr_1fr] items-center border-b border-white/[0.05] px-6 py-4 text-sm last:border-0"
            >
              <span className="text-[#F2F5FA]">{row.feature}</span>
              <span className="flex justify-center text-center text-[#9AA6BC]">
                {row.once === true ? (
                  <Check className="h-4.5 w-4.5 text-[#34D399]" />
                ) : row.once === false ? (
                  <Minus className="h-4.5 w-4.5 text-[#5C6B84]" />
                ) : (
                  row.once
                )}
              </span>
              <span className="flex justify-center text-center font-medium text-[#22D3EE]">
                {row.club === true ? <Check className="h-4.5 w-4.5" /> : row.club}
              </span>
            </div>
          ))}
        </motion.div>
      </section>

      {/* FAQ */}
      <section className="mx-auto mt-20 max-w-[800px] px-6">
        <h2 className="text-center font-display text-3xl font-bold md:text-4xl">
          Частые <span className="text-gradient">вопросы</span>
        </h2>
        <div className="mt-10 space-y-3">
          {FAQ.map((f, i) => (
            <div key={f.q} className="rounded-[20px] glass-light">
              <button
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
                className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left"
              >
                <span className="font-display text-[15px] font-bold">{f.q}</span>
                <ChevronDown
                  className={`h-5 w-5 shrink-0 text-[#9AA6BC] transition-transform duration-300 ${
                    openFaq === i ? 'rotate-180' : ''
                  }`}
                />
              </button>
              <AnimatePresence initial={false}>
                {openFaq === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <p className="px-6 pb-5 text-sm text-[#9AA6BC]">{f.a}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto mt-20 max-w-[1280px] px-6">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="gradient-border relative overflow-hidden rounded-[24px] p-10 text-center md:p-14"
        >
          <div className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 glow-cyan animate-drift" />
          <h2 className="mx-auto max-w-2xl font-display text-3xl font-bold md:text-4xl">
            Присоединяйтесь к <span className="text-gradient">Нейроклубу</span> сегодня
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-[#9AA6BC]">
            990 ₽/мес. Все новые промпт-паки, обновления курсов и комьюнити — в одной подписке.
          </p>
          <button
            onClick={subscribe}
            disabled={buying || done}
            className="btn-primary mt-8 disabled:opacity-60"
          >
            {done ? 'Подписка активна' : buying ? 'Оформляем…' : 'Подписаться за 990 ₽/мес'}
          </button>
        </motion.div>
      </section>
    </div>
  )
}
