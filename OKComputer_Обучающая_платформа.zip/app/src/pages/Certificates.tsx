import { useState } from 'react'
import { Link } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import {
  Award,
  Check,
  Copy,
  Download,
  ExternalLink,
  GraduationCap,
  Link2,
  ShieldCheck,
  X,
} from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { useAuth } from '@/hooks/useAuth'

const EASE = [0.16, 1, 0.3, 1] as [number, number, number, number]

type Cert = {
  id: number
  verifyCode: string
  issuedAt: Date | string
  course?: { title: string; hours?: number | null } | null
}

function formatDate(d: Date | string) {
  return new Date(d).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' })
}

/* ── Карточка сертификата ───────────────────────────────── */
function CertCard({
  cert,
  index,
  userName,
  onOpen,
}: {
  cert: Cert
  index: number
  userName: string
  onOpen: () => void
}) {
  const [copied, setCopied] = useState(false)
  const verifyUrl = `${window.location.origin}/verify/${cert.verifyCode}`

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(verifyUrl)
    } catch {
      /* noop */
    }
    setCopied(true)
    setTimeout(() => setCopied(false), 1800)
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 32 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 + index * 0.12, duration: 0.5, ease: EASE }}
      whileHover={{ y: -6 }}
      className="group overflow-hidden rounded-[20px] glass"
    >
      <button onClick={onOpen} className="relative block w-full" aria-label="Открыть сертификат">
        <img
          src="/certificate-template.png"
          alt={`Сертификат — ${cert.course?.title ?? 'курс'}`}
          className="aspect-[16/10] w-full object-cover transition-all duration-300 group-hover:shadow-[0_0_40px_rgba(124,92,255,0.35)]"
        />
        <span className="absolute inset-0 flex items-center justify-center bg-[#07090F]/0 opacity-0 transition-all group-hover:bg-[#07090F]/40 group-hover:opacity-100">
          <span className="chip bg-white/10 text-white backdrop-blur">Открыть</span>
        </span>
      </button>
      <div className="p-6">
        <h3 className="font-display text-lg font-bold leading-snug">{cert.course?.title ?? 'Курс FEDIN AI'}</h3>
        <p className="mt-2 text-[13px] text-[#5C6B84]">
          Выдан {formatDate(cert.issuedAt)} · № {cert.verifyCode}
        </p>
        <p className="mt-1 text-[13px] text-[#5C6B84]">Владелец: {userName}</p>
        <div className="mt-5 flex flex-wrap gap-2.5">
          <a href="/certificate-template.png" download={`fedin-ai-certificate-${cert.verifyCode}.png`} className="btn-primary !px-4 !py-2.5 text-[13px]">
            <Download className="h-4 w-4" /> Скачать PDF
          </a>
          <button onClick={copyLink} className="btn-ghost !px-4 !py-2.5 text-[13px]">
            {copied ? <Check className="h-4 w-4 text-[#34D399]" /> : <Link2 className="h-4 w-4" />}
            {copied ? 'Скопировано' : 'Поделиться'}
          </button>
          <Link to={`/verify/${cert.verifyCode}`} className="btn-ghost !px-4 !py-2.5 text-[13px]">
            <ExternalLink className="h-4 w-4" /> Проверка
          </Link>
        </div>
      </div>
    </motion.div>
  )
}

export default function Certificates() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth({ redirectOnUnauthenticated: true })
  const certs = trpc.me.certificates.useQuery(undefined, { enabled: isAuthenticated })
  const dash = trpc.me.dashboard.useQuery(undefined, { enabled: isAuthenticated })
  const [lightbox, setLightbox] = useState<Cert | null>(null)

  if (authLoading || (isAuthenticated && certs.isLoading)) {
    return (
      <div className="mx-auto max-w-[1280px] px-6 py-12">
        <div className="h-10 w-80 animate-pulse rounded-xl bg-white/5" />
        <div className="mt-4 h-5 w-[520px] max-w-full animate-pulse rounded-lg bg-white/5" />
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          <div className="h-96 animate-pulse rounded-[20px] bg-white/5" />
          <div className="h-96 animate-pulse rounded-[20px] bg-white/5" />
        </div>
      </div>
    )
  }
  if (!isAuthenticated) return null

  const userName = user?.name ?? 'Ученик'
  const list = (certs.data ?? []) as Cert[]
  const inProgress = (dash.data?.courses ?? []).filter((c) => c.progressPercent > 0 && c.progressPercent < 100)

  return (
    <div className="relative mx-auto max-w-[1280px] px-6 py-12">
      <div className="pointer-events-none absolute -top-24 right-0 h-[500px] w-[500px] glow-violet blur-3xl" />

      {/* Шапка */}
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE }}
        className="flex flex-wrap items-end justify-between gap-6"
      >
        <div className="max-w-2xl">
          <h1 className="font-display text-3xl font-bold md:text-5xl">
            Мои <span className="text-gradient">сертификаты</span>
          </h1>
          <p className="mt-4 text-lg text-[#9AA6BC]">
            Подтвердите навыки: каждый сертификат имеет уникальный номер и публичную страницу проверки.
            Добавляйте в резюме и LinkedIn/HH.
          </p>
        </div>
        <div className="flex gap-3">
          <motion.span
            initial={{ scale: 0.7, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.15, type: 'spring', stiffness: 220, damping: 14 }}
            className="chip glass text-[#F2F5FA]"
          >
            <Award className="h-4 w-4 text-[#7C5CFF]" /> {list.length} сертификат(а)
          </motion.span>
          <motion.span
            initial={{ scale: 0.7, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.25, type: 'spring', stiffness: 220, damping: 14 }}
            className="chip glass text-[#F2F5FA]"
          >
            <GraduationCap className="h-4 w-4 text-[#22D3EE]" /> {inProgress.length} в процессе
          </motion.span>
        </div>
      </motion.div>

      {/* Галерея */}
      {list.length === 0 && inProgress.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5, ease: EASE }}
          className="mt-12 flex flex-col items-center rounded-[20px] glass p-14 text-center"
        >
          <Award className="h-14 w-14 text-[#7C5CFF]" />
          <h2 className="mt-5 font-display text-2xl font-bold">Пока нет сертификатов</h2>
          <p className="mt-3 max-w-md text-[#9AA6BC]">
            Завершите любой курс на 100% — и именной сертификат с публичной проверкой появится здесь.
          </p>
          <Link to="/courses" className="btn-primary mt-8">
            Выбрать курс
          </Link>
        </motion.div>
      ) : (
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {list.map((cert, i) => (
            <CertCard key={cert.id} cert={cert} index={i} userName={userName} onOpen={() => setLightbox(cert)} />
          ))}
          {inProgress.map((c, i) => (
            <motion.div
              key={c.enrollmentId}
              initial={{ opacity: 0, y: 32 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + (list.length + i) * 0.12, duration: 0.5, ease: EASE }}
              className="relative overflow-hidden rounded-[20px] glass"
            >
              <div className="relative">
                <img
                  src="/certificate-template.png"
                  alt=""
                  className="aspect-[16/10] w-full object-cover opacity-70 blur-[1px] grayscale-[60%]"
                />
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-[#07090F]/40">
                  <div className="relative h-20 w-20">
                    <svg className="h-full w-full -rotate-90">
                      <circle cx="40" cy="40" r="34" stroke="rgba(255,255,255,0.12)" strokeWidth="6" fill="none" />
                      <motion.circle
                        cx="40"
                        cy="40"
                        r="34"
                        stroke="url(#cert-ring)"
                        strokeWidth="6"
                        strokeLinecap="round"
                        fill="none"
                        strokeDasharray={2 * Math.PI * 34}
                        initial={{ strokeDashoffset: 2 * Math.PI * 34 }}
                        animate={{ strokeDashoffset: 2 * Math.PI * 34 * (1 - c.progressPercent / 100) }}
                        transition={{ duration: 1, ease: EASE }}
                      />
                      <defs>
                        <linearGradient id="cert-ring" x1="0" y1="0" x2="1" y2="1">
                          <stop offset="0%" stopColor="#7C5CFF" />
                          <stop offset="100%" stopColor="#22D3EE" />
                        </linearGradient>
                      </defs>
                    </svg>
                    <span className="absolute inset-0 flex items-center justify-center font-display text-sm font-bold">
                      {c.progressPercent}%
                    </span>
                  </div>
                  <span className="text-sm font-medium text-white/90">Завершите курс, чтобы получить</span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="font-display text-lg font-bold leading-snug text-[#9AA6BC]">{c.course.title}</h3>
                <p className="mt-2 text-[13px] text-[#5C6B84]">
                  Пройдено {c.completedLessons} из {c.course.lessonsCount} уроков
                </p>
                <Link to="/dashboard" className="btn-ghost mt-5 !px-4 !py-2.5 text-[13px]">
                  Продолжить обучение
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Как это работает */}
      <h2 className="mt-20 font-display text-2xl font-bold md:text-3xl">Как это работает</h2>
      <div className="mt-8 grid gap-5 md:grid-cols-3">
        {[
          { icon: GraduationCap, title: 'Завершите курс на 100%', text: 'Пройдите все уроки и отметьте их выполненными.' },
          { icon: Award, title: 'Сертификат появится в кабинете', text: 'Именной, с уникальным номером и датой выдачи.' },
          { icon: ShieldCheck, title: 'Делитесь ссылкой', text: 'Работодатель проверит подлинность по номеру за секунду.' },
        ].map((s, i) => (
          <motion.div
            key={s.title}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1, duration: 0.5, ease: EASE }}
            className="rounded-[20px] glass p-7"
          >
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-gradient">
              <s.icon className="h-5 w-5 text-white" />
            </div>
            <h3 className="mt-5 font-semibold">{s.title}</h3>
            <p className="mt-2 text-sm text-[#9AA6BC]">{s.text}</p>
          </motion.div>
        ))}
      </div>

      {/* Лайтбокс */}
      <AnimatePresence>
        {lightbox && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[80] flex items-center justify-center bg-[rgba(4,6,10,0.8)] p-6 backdrop-blur-md"
            onClick={() => setLightbox(null)}
          >
            <motion.div
              initial={{ scale: 0.92, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.92, opacity: 0 }}
              transition={{ duration: 0.25, ease: EASE }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-[1100px]"
            >
              <div className="relative overflow-hidden rounded-[20px] border border-white/10 shadow-[0_8px_40px_rgba(0,0,0,0.45)]">
                <img src="/certificate-template.png" alt="Сертификат" className="w-full object-cover" />
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#07090F]/55 p-8 text-center">
                  <img src="/logo.svg" alt="FEDIN AI" className="h-8 w-auto" />
                  <div className="mt-4 text-[12px] uppercase tracking-[0.3em] text-[#22D3EE]">Сертификат об окончании</div>
                  <div className="mt-3 font-display text-2xl font-bold md:text-4xl">{userName}</div>
                  <div className="mt-2 max-w-lg text-sm text-[#9AA6BC] md:text-base">
                    успешно завершил(а) курс «{lightbox.course?.title ?? 'Курс FEDIN AI'}»
                  </div>
                  <div className="mt-5 flex items-center gap-4 text-[12px] text-[#5C6B84]">
                    <span>{formatDate(lightbox.issuedAt)}</span>
                    <span className="h-1 w-1 rounded-full bg-[#5C6B84]" />
                    <span>№ {lightbox.verifyCode}</span>
                  </div>
                </div>
              </div>
              <div className="mt-5 flex justify-center gap-3">
                <a href="/certificate-template.png" download={`fedin-ai-certificate-${lightbox.verifyCode}.png`} className="btn-primary !px-5 !py-2.5 text-sm">
                  <Download className="h-4 w-4" /> Скачать
                </a>
                <button onClick={() => setLightbox(null)} className="btn-ghost !px-5 !py-2.5 text-sm">
                  <X className="h-4 w-4" /> Закрыть
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Копия-ссылка подсказка */}
      <p className="mt-14 flex items-center gap-2 text-[13px] text-[#5C6B84]">
        <Copy className="h-4 w-4" /> Публичная ссылка на проверку имеет вид fedin-ii.ru/verify/НОМЕР — её можно вставить в резюме.
      </p>
    </div>
  )
}
