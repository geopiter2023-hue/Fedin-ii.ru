import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowRight,
  BadgePercent,
  Briefcase,
  CheckCircle2,
  ChevronDown,
  Clock,
  Flame,
  Layers,
  PlayCircle,
  Rocket,
  SearchX,
  Sparkles,
  Store,
  Video,
  X,
} from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { cn } from '@/lib/utils'

const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1]

function formatRub(kopecks: number): string {
  return `${new Intl.NumberFormat('ru-RU').format(Math.round(kopecks / 100))} ₽`
}

const CATEGORIES = [
  { id: 'all', label: 'Все', icon: Sparkles },
  { id: 'work', label: 'Для работы', icon: Briefcase },
  { id: 'content', label: 'Контент', icon: Video },
  { id: 'marketing', label: 'Маркетинг', icon: Rocket },
  { id: 'dev', label: 'Разработка', icon: Layers },
  { id: 'marketplace', label: 'Маркетплейсы', icon: Store },
] as const

// Совпадение категории курса по slug/category из БД
function courseCategory(slug: string, category: string | null): string {
  const c = (category ?? '').toLowerCase()
  if (slug.includes('work')) return 'work'
  if (slug.includes('content')) return 'content'
  if (slug.includes('marketing')) return 'marketing'
  if (slug.includes('vibe') || slug.includes('cod')) return 'dev'
  if (slug.includes('marketplace')) return 'marketplace'
  if (c.includes('работ')) return 'work'
  if (c.includes('контент')) return 'content'
  if (c.includes('маркет')) return slug.includes('marketplace') ? 'marketplace' : 'marketing'
  if (c.includes('разработ') || c.includes('код')) return 'dev'
  return 'work'
}

type SortMode = 'popular' | 'cheap' | 'expensive'

const SORTS: { id: SortMode; label: string }[] = [
  { id: 'popular', label: 'По популярности' },
  { id: 'cheap', label: 'Сначала дешевле' },
  { id: 'expensive', label: 'Сначала дороже' },
]

/* ─── Постер с фолбэком ─── */
function Poster({ poster, title, className }: { poster: string | null; title: string; className?: string }) {
  const [failed, setFailed] = useState(false)
  if (!poster || failed) {
    return (
      <div className={cn('flex items-center justify-center bg-gradient-to-br from-[#7C5CFF]/40 via-[#121824] to-[#22D3EE]/30', className)}>
        <Sparkles className="h-12 w-12 text-white/40" />
      </div>
    )
  }
  return (
    <img
      src={poster.startsWith('/') ? poster : `/${poster}`}
      alt={title}
      loading="lazy"
      onError={() => setFailed(true)}
      className={cn('object-cover', className)}
    />
  )
}

/* ─── Скелетон карточки ─── */
function CardSkeleton() {
  return (
    <div className="glass overflow-hidden rounded-[20px]">
      <div className="aspect-video animate-pulse bg-white/5" />
      <div className="space-y-3 p-6">
        <div className="h-5 w-3/4 animate-pulse rounded bg-white/5" />
        <div className="h-4 w-full animate-pulse rounded bg-white/5" />
        <div className="h-4 w-2/3 animate-pulse rounded bg-white/5" />
        <div className="h-10 w-full animate-pulse rounded-[14px] bg-white/5" />
      </div>
    </div>
  )
}

/* ─── Квиз «Что выбрать?» ─── */
const QUIZ = [
  {
    q: 'Что вам ближе всего?',
    a: [
      { t: 'Экономить время на рабочих задачах', s: 'neuro-work' },
      { t: 'Делать контент: видео, Reels, визуал', s: 'neuro-content' },
      { t: 'Свой бизнес, маркетинг или продажи', s: 'neuro-marketing' },
    ],
  },
  {
    q: 'Ваш опыт с нейросетями?',
    a: [
      { t: 'Почти ноль — начинаю с базы', s: 'neuro-work' },
      { t: 'Пробовал(а) ChatGPT, хочу систему', s: 'neuro-content' },
      { t: 'Хочу автоматизации и агентов', s: 'neuro-marketing' },
    ],
  },
  {
    q: 'Какая цель через 3 месяца?',
    a: [
      { t: 'Освободить 5–10 часов в неделю', s: 'neuro-work' },
      { t: 'Выпускать контент в 3 раза быстрее', s: 'neuro-content' },
      { t: 'Запустить продукт или карточки, которые продают', s: 'vibe-coding' },
    ],
  },
]

function QuizModal({ onClose, courses }: { onClose: () => void; courses: { slug: string; title: string }[] }) {
  const [step, setStep] = useState(0)
  const [scores, setScores] = useState<Record<string, number>>({})
  const done = step >= QUIZ.length
  const winner = useMemo(() => {
    const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1])
    const slug = sorted[0]?.[0] ?? 'neuro-work'
    return courses.find((c) => c.slug === slug) ?? courses[0]
  }, [scores, courses])

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[70] flex items-center justify-center bg-[#04060A]/70 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        transition={{ duration: 0.25, ease: EASE }}
        onClick={(e) => e.stopPropagation()}
        className="glass relative w-full max-w-lg rounded-[24px] p-8"
      >
        <button onClick={onClose} aria-label="Закрыть" className="absolute right-5 top-5 text-[#9AA6BC] hover:text-white">
          <X className="h-5 w-5" />
        </button>
        {!done ? (
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ x: 32, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -32, opacity: 0 }}
              transition={{ duration: 0.25, ease: EASE }}
            >
              <p className="text-[13px] font-medium text-[#5C6B84]">
                Вопрос {step + 1} из {QUIZ.length}
              </p>
              <h3 className="mt-2 font-display text-xl font-bold">{QUIZ[step].q}</h3>
              <div className="mt-6 space-y-3">
                {QUIZ[step].a.map((opt) => (
                  <button
                    key={opt.t}
                    onClick={() => {
                      setScores((s) => ({ ...s, [opt.s]: (s[opt.s] ?? 0) + 1 }))
                      setStep((v) => v + 1)
                    }}
                    className="w-full rounded-[14px] border border-white/[0.08] bg-white/[0.03] px-5 py-4 text-left text-[15px] text-[#F2F5FA] transition-all hover:border-[#7C5CFF] hover:bg-white/[0.06]"
                  >
                    {opt.t}
                  </button>
                ))}
              </div>
              <div className="mt-6 h-1.5 overflow-hidden rounded-full bg-white/5">
                <div
                  className="h-full bg-brand-gradient transition-all duration-300"
                  style={{ width: `${(step / QUIZ.length) * 100}%` }}
                />
              </div>
            </motion.div>
          </AnimatePresence>
        ) : (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-brand-gradient">
              <CheckCircle2 className="h-7 w-7 text-white" />
            </div>
            <h3 className="mt-5 font-display text-xl font-bold">Ваша рекомендация</h3>
            <p className="mt-2 text-[15px] text-[#9AA6BC]">{winner?.title ?? 'Нейросети для работы'}</p>
            <Link to={`/courses/${winner?.slug ?? 'neuro-work'}`} className="btn-primary mt-6 w-full">
              Смотреть курс <ArrowRight className="h-4 w-4" />
            </Link>
            <button onClick={onClose} className="mt-3 w-full text-[13px] text-[#5C6B84] hover:text-[#9AA6BC]">
              Показать все курсы
            </button>
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  )
}

/* ─── Страница ─── */
export default function Courses() {
  const { data, isLoading, isError } = trpc.courses.list.useQuery()
  const [category, setCategory] = useState<string>('all')
  const [sort, setSort] = useState<SortMode>('popular')
  const [onlyDiscount, setOnlyDiscount] = useState(false)
  const [quizOpen, setQuizOpen] = useState(false)
  const [email, setEmail] = useState('')
  const [emailSent, setEmailSent] = useState(false)

  const courses = useMemo(() => data ?? [], [data])

  const filtered = useMemo(() => {
    let list = [...courses]
    if (category !== 'all') list = list.filter((c) => courseCategory(c.slug, c.category) === category)
    if (onlyDiscount) list = list.filter((c) => c.oldPrice && c.oldPrice > c.price)
    if (sort === 'cheap') list.sort((a, b) => a.price - b.price)
    if (sort === 'expensive') list.sort((a, b) => b.price - a.price)
    return list
  }, [courses, category, sort, onlyDiscount])

  return (
    <div className="relative">
      {/* фоновые свечения */}
      <div className="pointer-events-none absolute -top-20 left-[-10%] h-[600px] w-[600px] glow-violet" />
      <div className="pointer-events-none absolute right-[-10%] top-40 h-[500px] w-[500px] glow-cyan" />

      {/* 1. Шапка */}
      <section className="relative mx-auto max-w-[1280px] px-6 pb-12 pt-16 md:pt-20">
        <h1 className="font-display text-[36px] font-extrabold leading-[1.05] md:text-[56px]">
          Каталог <span className="text-gradient">курсов</span>
        </h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6, ease: EASE }}
          className="mt-5 max-w-2xl text-[17px] text-[#9AA6BC] md:text-[20px]"
        >
          От первого промпта до собственного ИИ-продукта. Российский стек, практика, сертификат.
        </motion.p>
      </section>

      {/* 2. Фильтры (липкие) */}
      <div className="sticky top-[72px] z-40 border-y border-white/[0.06] bg-[#07090F]/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1280px] flex-wrap items-center gap-3 px-6 py-3">
          <div className="flex flex-1 gap-2 overflow-x-auto py-1 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {CATEGORIES.map((cat) => {
              const active = category === cat.id
              return (
                <button
                  key={cat.id}
                  onClick={() => setCategory(cat.id)}
                  className={cn(
                    'relative flex shrink-0 items-center gap-2 rounded-full px-4 py-2 text-[13px] font-medium transition-colors',
                    active ? 'text-white' : 'text-[#9AA6BC] hover:text-white'
                  )}
                >
                  {active && (
                    <motion.span
                      layoutId="chip-active"
                      className="absolute inset-0 rounded-full bg-brand-gradient"
                      transition={{ type: 'spring', duration: 0.5 }}
                    />
                  )}
                  <cat.icon className="relative z-10 h-3.5 w-3.5" />
                  <span className="relative z-10">{cat.label}</span>
                </button>
              )
            })}
          </div>
          <div className="flex items-center gap-3">
            <div className="relative">
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value as SortMode)}
                className="appearance-none rounded-[10px] border border-white/[0.08] bg-[#0D1117] py-2 pl-3 pr-8 text-[13px] text-[#F2F5FA] focus:border-[#7C5CFF] focus:outline-none"
              >
                {SORTS.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.label}
                  </option>
                ))}
              </select>
              <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[#5C6B84]" />
            </div>
            <button
              onClick={() => setOnlyDiscount((v) => !v)}
              className={cn(
                'flex items-center gap-1.5 rounded-[10px] border px-3 py-2 text-[13px] font-medium transition-all',
                onlyDiscount
                  ? 'border-[#F87171]/50 bg-[#F87171]/10 text-[#F87171]'
                  : 'border-white/[0.08] text-[#9AA6BC] hover:text-white'
              )}
            >
              <BadgePercent className="h-3.5 w-3.5" />
              Только со скидкой
            </button>
          </div>
        </div>
      </div>

      {/* 3. Сетка курсов */}
      <section className="relative mx-auto max-w-[1280px] px-6 py-14">
        {isLoading ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <CardSkeleton key={i} />
            ))}
          </div>
        ) : isError ? (
          <div className="glass mx-auto max-w-md rounded-[24px] p-10 text-center">
            <SearchX className="mx-auto h-10 w-10 text-[#5C6B84]" />
            <h3 className="mt-4 font-display text-lg font-bold">Не удалось загрузить курсы</h3>
            <p className="mt-2 text-sm text-[#9AA6BC]">Проверьте соединение и обновите страницу — мы уже разбираемся.</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="glass mx-auto max-w-md rounded-[24px] p-10 text-center">
            <SearchX className="mx-auto h-10 w-10 text-[#5C6B84]" />
            <h3 className="mt-4 font-display text-lg font-bold">Ничего не найдено</h3>
            <p className="mt-2 text-sm text-[#9AA6BC]">Попробуйте другую категорию или сбросьте фильтр скидок.</p>
            <button
              onClick={() => {
                setCategory('all')
                setOnlyDiscount(false)
              }}
              className="btn-ghost mt-6 px-5 py-2.5 text-sm"
            >
              Сбросить фильтры
            </button>
          </div>
        ) : (
          <motion.div layout className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <AnimatePresence mode="popLayout">
              {filtered.map((course, i) => (
                <motion.article
                  layout
                  key={course.id}
                  initial={{ opacity: 0, y: 28 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.96 }}
                  viewport={{ once: true, margin: '-15% 0px' }}
                  transition={{ delay: (i % 3) * 0.08, duration: 0.5, ease: EASE }}
                  whileHover={{ y: -6 }}
                  className="glass group flex flex-col overflow-hidden rounded-[20px] transition-shadow duration-300 hover:shadow-[0_0_32px_rgba(124,92,255,0.25)]"
                >
                  <div className="relative aspect-video overflow-hidden">
                    <Poster
                      poster={course.poster}
                      title={course.title}
                      className="h-full w-full transition-transform duration-500 group-hover:scale-105"
                    />
                    {course.badge && (
                      <span className="absolute left-4 top-4 rounded-full bg-brand-gradient px-3 py-1 text-[12px] font-semibold text-white shadow-[0_0_20px_rgba(124,92,255,0.5)]">
                        {course.badge}
                      </span>
                    )}
                    {course.oldPrice && course.oldPrice > course.price && (
                      <span className="absolute right-4 top-4 rounded-full bg-[#F87171] px-2.5 py-1 text-[12px] font-bold text-white">
                        −{Math.round((1 - course.price / course.oldPrice) * 100)}%
                      </span>
                    )}
                  </div>
                  <div className="flex flex-1 flex-col p-6">
                    <h3 className="font-display text-[17px] font-bold leading-snug">{course.title}</h3>
                    {course.subtitle && (
                      <p className="mt-2 line-clamp-2 text-[14px] text-[#9AA6BC]">{course.subtitle}</p>
                    )}
                    <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 text-[13px] text-[#5C6B84]">
                      <span className="flex items-center gap-1.5">
                        <Layers className="h-3.5 w-3.5" /> {course.modulesCount} модулей
                      </span>
                      <span className="flex items-center gap-1.5">
                        <PlayCircle className="h-3.5 w-3.5" /> {course.lessonsCount} уроков
                      </span>
                      {course.hours > 0 && (
                        <span className="flex items-center gap-1.5">
                          <Clock className="h-3.5 w-3.5" /> {course.hours} ч
                        </span>
                      )}
                    </div>
                    <div className="mt-5 flex items-baseline gap-2">
                      <span className="font-display text-xl font-bold">{formatRub(course.price)}</span>
                      {course.oldPrice && course.oldPrice > course.price && (
                        <span className="text-[14px] text-[#5C6B84] line-through">{formatRub(course.oldPrice)}</span>
                      )}
                    </div>
                    <p className="mt-1 text-[12px] text-[#5C6B84]">
                      или от {formatRub(Math.ceil(course.price / 12))}/мес в рассрочку
                    </p>
                    <div className="mt-5 flex gap-3">
                      <Link to={`/courses/${course.slug}`} className="btn-primary flex-1 px-4 py-2.5 text-[14px]">
                        Подробнее
                      </Link>
                      <Link
                        to={`/courses/${course.slug}#program`}
                        className="btn-ghost flex-1 px-4 py-2.5 text-[14px]"
                      >
                        Программа
                      </Link>
                    </div>
                  </div>
                </motion.article>
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </section>

      {/* 4. Баннер бесплатного интенсива */}
      <section className="relative mx-auto max-w-[1280px] px-6 pb-20">
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: EASE }}
          className="gradient-border relative overflow-hidden rounded-[24px] p-8 md:p-12"
        >
          <div className="pointer-events-none absolute -right-24 -top-24 h-[400px] w-[400px] glow-cyan animate-drift" />
          <div className="relative grid items-center gap-8 lg:grid-cols-2">
            <div>
              <span className="chip bg-[#34D399]/15 text-[#34D399]">Бесплатно</span>
              <h3 className="mt-4 font-display text-2xl font-bold md:text-3xl">
                Не готовы купить курс? Начните с <span className="text-gradient">интенсива за 3 дня</span>
              </h3>
              <p className="mt-3 text-[15px] text-[#9AA6BC]">3 урока, первый результат за вечер, 0 ₽.</p>
            </div>
            {emailSent ? (
              <div className="glass-light flex items-center gap-4 rounded-[20px] p-6">
                <CheckCircle2 className="h-8 w-8 shrink-0 text-[#34D399]" />
                <div>
                  <p className="font-semibold">Место забронировано!</p>
                  <p className="text-sm text-[#9AA6BC]">Ссылка на интенсив уже летит на {email}.</p>
                </div>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  if (email.trim()) setEmailSent(true)
                }}
                className="flex flex-col gap-3 sm:flex-row"
              >
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Ваш email"
                  className="flex-1 rounded-[12px] border border-white/[0.08] bg-[#0D1117] px-4 py-3.5 text-[15px] text-[#F2F5FA] placeholder-[#5C6B84] focus:border-[#7C5CFF] focus:outline-none focus:shadow-[0_0_24px_rgba(124,92,255,0.25)]"
                />
                <button type="submit" className="btn-primary whitespace-nowrap">
                  Забрать — 0 ₽
                </button>
              </form>
            )}
          </div>
        </motion.div>
      </section>

      {/* 5. Что выбрать? */}
      <section className="relative mx-auto max-w-[1280px] px-6 pb-20">
        <h2 className="font-display text-3xl font-bold md:text-[40px]">
          Не знаете, <span className="text-gradient">с чего начать?</span>
        </h2>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {[
            {
              icon: Briefcase,
              title: 'Хочу экономить время на работе',
              text: 'Документы, письма, таблицы и презентации — на автопилоте с ИИ.',
              slug: 'neuro-work',
              label: 'Нейросети для работы',
            },
            {
              icon: Video,
              title: 'Делаю контент / веду блог',
              text: 'Reels, видео и визуал в 3 раза быстрее — от идеи до публикации.',
              slug: 'neuro-content',
              label: 'Нейросети для контента',
            },
            {
              icon: Store,
              title: 'Свой бизнес или маркетплейс',
              text: 'Автоворонки, ИИ-агенты и карточки, которые продают.',
              slug: 'neuro-marketing',
              label: 'Маркетинг и ИИ-агенты',
            },
          ].map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5, ease: EASE }}
              className="glass rounded-[20px] p-7"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-[14px] bg-brand-gradient/20 text-[#7C5CFF]">
                <s.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-5 font-display text-[17px] font-bold leading-snug">{s.title}</h3>
              <p className="mt-2 text-[14px] text-[#9AA6BC]">{s.text}</p>
              <Link
                to={`/courses/${s.slug}`}
                className="mt-5 inline-flex items-center gap-1.5 text-[14px] font-medium text-[#22D3EE] transition-all hover:gap-2.5"
              >
                {s.label} <ArrowRight className="h-4 w-4" />
              </Link>
            </motion.div>
          ))}
        </div>
        <div className="mt-10 text-center">
          <button onClick={() => setQuizOpen(true)} className="btn-ghost">
            Пройти квиз за 60 секунд <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      </section>

      {/* 6. Полоса доверия */}
      <section className="border-t border-white/[0.06] bg-[#0D1117]/50">
        <div className="mx-auto grid max-w-[1280px] grid-cols-2 gap-8 px-6 py-14 lg:grid-cols-4">
          {[
            { value: '5 200+', label: 'учеников' },
            { value: '4,9 ★', label: 'средняя оценка' },
            { value: 'от 1 242 ₽/мес', label: 'рассрочка' },
            { value: '100%', label: 'сертификат по окончании' },
          ].map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.5, ease: EASE }}
              className="text-center"
            >
              <div className="font-display text-2xl font-bold md:text-3xl">
                <span className="text-gradient">{s.value}</span>
              </div>
              <div className="mt-2 flex items-center justify-center gap-1.5 text-[13px] text-[#5C6B84]">
                {i === 2 && <Flame className="h-3.5 w-3.5 text-[#FBBF24]" />}
                {s.label}
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <AnimatePresence>
        {quizOpen && <QuizModal onClose={() => setQuizOpen(false)} courses={courses} />}
      </AnimatePresence>
    </div>
  )
}
