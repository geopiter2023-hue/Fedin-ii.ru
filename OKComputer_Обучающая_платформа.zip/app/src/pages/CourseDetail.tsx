import { useMemo, useRef, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { AnimatePresence, motion, useMotionValue, useSpring, useTransform } from 'framer-motion'
import {
  Award,
  Bot,
  BrainCircuit,
  Check,
  ChevronDown,
  ChevronRight,
  Clock,
  FileText,
  GraduationCap,
  Infinity as InfinityIcon,
  Layers,
  Loader2,
  Lock,
  MessageSquareText,
  Play,
  PlayCircle,
  Presentation,
  SearchX,
  ShieldCheck,
  Sparkles,
  Star,
  Table2,
  Wallet,
} from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { useAuth } from '@/hooks/useAuth'
import { LOGIN_PATH } from '@/const'
import { cn } from '@/lib/utils'

const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1]

function formatRub(kopecks: number): string {
  return `${new Intl.NumberFormat('ru-RU').format(Math.round(kopecks / 100))} ₽`
}

type Tariff = 'basic' | 'pro'

/* ─── Постер с фолбэком ─── */
function Poster({ poster, title, className }: { poster: string | null; title: string; className?: string }) {
  const [failed, setFailed] = useState(false)
  if (!poster || failed) {
    return (
      <div className={cn('flex items-center justify-center bg-gradient-to-br from-[#7C5CFF]/40 via-[#121824] to-[#22D3EE]/30', className)}>
        <Sparkles className="h-12 w-12 text-white/40" />
      </div>
    )
  }
  return (
    <img
      src={poster.startsWith('/') ? poster : `/${poster}`}
      alt={title}
      loading="lazy"
      onError={() => setFailed(true)}
      className={cn('object-cover', className)}
    />
  )
}

/* ─── FAQ ─── */
const FAQ = [
  { q: 'Нужен ли опыт работы с нейросетями?', a: 'Нет. Курс построен от нуля: первый модуль — мягкий вход, дальше сложность растёт постепенно. Даже если вы ни разу не писали промпт, справитесь.' },
  { q: 'Сколько времени в неделю нужно?', a: '3–4 часа: 2 урока + практическое задание. Все уроки по 10–15 минут, можно смотреть в любое время.' },
  { q: 'Как оплатить из России?', a: 'Картой любого российского банка, через СБП или в рассрочку на 12 месяцев — одобрение за 2 минуты, без переплаты в период акции.' },
  { q: 'Когда откроется доступ?', a: 'Сразу после оплаты — все модули доступны навсегда, включая будущие обновления курса.' },
  { q: 'А если не подойдёт? Есть возврат?', a: 'Да, 14 дней на полный возврат без вопросов — просто напишите в поддержку.' },
]

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="glass overflow-hidden rounded-[16px]">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left"
      >
        <span className="text-[15px] font-semibold">{q}</span>
        <ChevronDown className={cn('h-4 w-4 shrink-0 text-[#9AA6BC] transition-transform duration-300', open && 'rotate-180')} />
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: EASE }}
          >
            <p className="px-6 pb-5 text-[14px] text-[#9AA6BC]">{a}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

/* ─── Страница ─── */
export default function CourseDetail() {
  const { id: slug = '' } = useParams()
  const navigate = useNavigate()
  const { isAuthenticated, isLoading: authLoading } = useAuth()

  const courseQuery = trpc.courses.bySlug.useQuery({ slug }, { retry: false })
  const course = courseQuery.data
  const reviewsQuery = trpc.courses.reviews.useQuery(
    { courseId: course?.id ?? 0 },
    { enabled: !!course }
  )

  const [tariff, setTariff] = useState<Tariff>('basic')
  const [openModules, setOpenModules] = useState<number[]>([0])
  const [visibleReviews, setVisibleReviews] = useState(3)

  const checkout = trpc.shop.checkout.useMutation({
    onSuccess: () => navigate('/dashboard'),
  })

  // parallax tilt превью
  const tiltRef = useRef<HTMLDivElement>(null)
  const mx = useMotionValue(0.5)
  const my = useMotionValue(0.5)
  const rx = useSpring(useTransform(my, [0, 1], [6, -6]), { stiffness: 150, damping: 20 })
  const ry = useSpring(useTransform(mx, [0, 1], [-6, 6]), { stiffness: 150, damping: 20 })

  const price = tariff === 'pro' && course?.proPrice ? course.proPrice : course?.price ?? 0
  const monthly = Math.ceil(price / 12)
  const discount = course?.oldPrice && course.oldPrice > course.price
    ? Math.round((1 - course.price / course.oldPrice) * 100)
    : 0

  const reviews = useMemo(() => reviewsQuery.data ?? [], [reviewsQuery.data])
  const ratingDist = useMemo(() => {
    const total = reviews.length || 1
    return [5, 4, 3, 2, 1].map((star) => ({
      star,
      pct: Math.round((reviews.filter((r) => r.rating === star).length / total) * 100),
    }))
  }, [reviews])
  const avgRating = reviews.length
    ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1).replace('.', ',')
    : '4,9'

  const otherCoursesQuery = trpc.courses.list.useQuery()
  const others = useMemo(
    () => (otherCoursesQuery.data ?? []).filter((c) => c.slug !== slug).slice(0, 3),
    [otherCoursesQuery.data, slug]
  )

  const buy = () => {
    if (!course) return
    if (!isAuthenticated) {
      navigate(LOGIN_PATH)
      return
    }
    checkout.mutate({ itemType: 'course', itemId: course.id, tariff })
  }

  /* ── Loading / error states ── */
  if (courseQuery.isLoading) {
    return (
      <div className="mx-auto max-w-[1280px] px-6 py-16">
        <div className="h-5 w-64 animate-pulse rounded bg-white/5" />
        <div className="mt-8 grid gap-10 lg:grid-cols-[1.5fr_1fr]">
          <div className="space-y-4">
            <div className="h-10 w-3/4 animate-pulse rounded bg-white/5" />
            <div className="h-6 w-full animate-pulse rounded bg-white/5" />
            <div className="h-6 w-2/3 animate-pulse rounded bg-white/5" />
            <div className="mt-6 h-12 w-56 animate-pulse rounded-[14px] bg-white/5" />
          </div>
          <div className="aspect-video animate-pulse rounded-[20px] bg-white/5" />
        </div>
      </div>
    )
  }

  if (courseQuery.isError || !course) {
    return (
      <div className="mx-auto flex min-h-[60vh] max-w-[1280px] items-center justify-center px-6">
        <div className="glass max-w-md rounded-[24px] p-10 text-center">
          <SearchX className="mx-auto h-10 w-10 text-[#5C6B84]" />
          <h1 className="mt-4 font-display text-xl font-bold">Курс не найден</h1>
          <p className="mt-2 text-sm text-[#9AA6BC]">Возможно, ссылка устарела. Посмотрите актуальный каталог.</p>
          <Link to="/courses" className="btn-primary mt-6 w-full">В каталог курсов</Link>
        </div>
      </div>
    )
  }

  const buyBlock = (
    <>
      {course.oldPrice && course.oldPrice > price && tariff === 'basic' && (
        <div className="flex items-center justify-between">
          <span className="text-[15px] text-[#5C6B84] line-through">{formatRub(course.oldPrice)}</span>
          <span className="rounded-full bg-[#F87171]/15 px-3 py-1 text-[12px] font-bold text-[#F87171]">
            −{discount}% до конца недели
          </span>
        </div>
      )}
      <div className="mt-2 font-display text-3xl font-bold">
        <AnimatePresence mode="wait">
          <motion.span
            key={price}
            initial={{ rotateX: 90, opacity: 0 }}
            animate={{ rotateX: 0, opacity: 1 }}
            exit={{ rotateX: -90, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="inline-block"
          >
            {formatRub(price)}
          </motion.span>
        </AnimatePresence>
      </div>

      {course.proPrice && (
        <div className="mt-5 space-y-2.5">
          {(
            [
              { id: 'basic' as Tariff, label: 'Самостоятельный', p: course.price },
              { id: 'pro' as Tariff, label: 'PRO с куратором', p: course.proPrice },
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              onClick={() => setTariff(t.id)}
              className={cn(
                'flex w-full items-center justify-between rounded-[14px] border px-4 py-3.5 text-left transition-all',
                tariff === t.id
                  ? 'border-transparent bg-gradient-to-r from-[#7C5CFF]/20 to-[#22D3EE]/10 shadow-[inset_0_0_0_1px_rgba(124,92,255,0.6)]'
                  : 'border-white/[0.08] bg-white/[0.02] hover:border-white/20'
              )}
            >
              <span className="flex items-center gap-3">
                <span
                  className={cn(
                    'flex h-4.5 w-4.5 items-center justify-center rounded-full border',
                    tariff === t.id ? 'border-[#7C5CFF] bg-[#7C5CFF]' : 'border-white/30'
                  )}
                >
                  {tariff === t.id && <Check className="h-3 w-3 text-white" />}
                </span>
                <span className="text-[14px] font-medium">{t.label}</span>
              </span>
              <span className="text-[14px] font-semibold">{formatRub(t.p)}</span>
            </button>
          ))}
        </div>
      )}

      <button
        onClick={buy}
        disabled={checkout.isPending || authLoading}
        className="btn-primary mt-5 w-full disabled:opacity-60"
      >
        {checkout.isPending ? <Loader2 className="h-5 w-5 animate-spin" /> : null}
        {checkout.isPending ? 'Оформляем…' : 'Купить'}
      </button>
      {checkout.isError && (
        <p className="mt-3 text-center text-[13px] text-[#F87171]">Не удалось оформить заказ. Попробуйте ещё раз.</p>
      )}
      <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-[12px] text-[#5C6B84]">
        <Wallet className="h-3.5 w-3.5" />
        Рассрочка от {formatRub(monthly)}/мес · Возврат 14 дней
      </p>
    </>
  )

  return (
    <div className="relative">
      <div className="pointer-events-none absolute -top-20 left-[-10%] h-[600px] w-[600px] glow-violet" />
      <div className="pointer-events-none absolute right-[-5%] top-[40%] h-[500px] w-[500px] glow-cyan" />

      {/* 1. Hero */}
      <section className="relative mx-auto max-w-[1280px] px-6 pb-16 pt-10">
        <nav className="flex items-center gap-2 text-[13px] text-[#5C6B84]">
          <Link to="/" className="hover:text-[#9AA6BC]">Главная</Link>
          <ChevronRight className="h-3 w-3" />
          <Link to="/courses" className="hover:text-[#9AA6BC]">Курсы</Link>
          <ChevronRight className="h-3 w-3" />
          <span className="text-[#9AA6BC]">{course.title}</span>
        </nav>

        <div className="mt-8 grid items-start gap-12 lg:grid-cols-[1.5fr_1fr]">
          <div>
            <div className="flex flex-wrap gap-2">
              {course.badge && (
                <span className="chip bg-brand-gradient font-semibold text-white">{course.badge}</span>
              )}
              <span className="chip glass-light text-[#9AA6BC]">Обновлено: январь 2025</span>
            </div>
            <h1 className="mt-5 font-display text-[30px] font-extrabold leading-[1.08] md:text-[44px]">
              {course.title}
            </h1>
            {course.subtitle && (
              <p className="mt-5 max-w-xl text-[16px] text-[#9AA6BC] md:text-[18px]">{course.subtitle}</p>
            )}

            <div className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 text-[14px] text-[#9AA6BC]">
              {[
                { icon: Layers, t: `${course.modulesCount} модулей` },
                { icon: PlayCircle, t: `${course.lessonsCount} уроков` },
                { icon: Clock, t: `${course.hours} часов` },
                { icon: InfinityIcon, t: 'Доступ навсегда' },
                { icon: Award, t: 'Сертификат' },
              ].map((m, i) => (
                <motion.span
                  key={m.t}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.15 + i * 0.06, duration: 0.4, ease: EASE }}
                  className="flex items-center gap-1.5"
                >
                  <m.icon className="h-4 w-4 text-[#22D3EE]" /> {m.t}
                </motion.span>
              ))}
            </div>

            <div className="mt-4 flex items-center gap-2 text-[14px]">
              <span className="flex text-[#FBBF24]">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-current" />
                ))}
              </span>
              <span className="font-semibold text-[#F2F5FA]">{avgRating}</span>
              <span className="text-[#5C6B84]">({reviews.length || 812} оценок)</span>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button onClick={buy} className="btn-primary">
                Купить за {formatRub(price)}
              </button>
              <a href="#program" className="btn-ghost">
                Бесплатный урок <Play className="h-4 w-4" />
              </a>
            </div>
            <p className="mt-3 text-[13px] text-[#5C6B84]">
              или от {formatRub(monthly)}/мес — рассрочка 12 мес, карта/СБП
            </p>
          </div>

          {/* превью с tilt */}
          <div
            ref={tiltRef}
            onMouseMove={(e) => {
              const r = tiltRef.current?.getBoundingClientRect()
              if (!r) return
              mx.set((e.clientX - r.left) / r.width)
              my.set((e.clientY - r.top) / r.height)
            }}
            onMouseLeave={() => {
              mx.set(0.5)
              my.set(0.5)
            }}
            style={{ perspective: 800 }}
          >
            <motion.div
              style={{ rotateX: rx, rotateY: ry }}
              className="glass relative overflow-hidden rounded-[20px] shadow-[0_8px_40px_rgba(0,0,0,0.45)]"
            >
              <Poster poster={course.poster} title={course.title} className="aspect-video w-full" />
              <button
                aria-label="Смотреть промо"
                className="absolute inset-0 flex items-center justify-center bg-black/20 transition-colors hover:bg-black/30"
              >
                <span className="flex h-16 w-16 items-center justify-center rounded-full bg-brand-gradient shadow-[0_0_32px_rgba(124,92,255,0.6)]">
                  <Play className="h-7 w-7 fill-white text-white" />
                </span>
              </button>
            </motion.div>
            <div className="mt-4 flex flex-wrap gap-2">
              {['GigaChat', 'YandexGPT', 'DeepSeek', 'ChatGPT'].map((tool, i) => (
                <motion.span
                  key={tool}
                  initial={{ scale: 0.6, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.3 + i * 0.05, type: 'spring', stiffness: 260, damping: 16 }}
                  className="chip glass-light font-mono2 text-[12px] text-[#9AA6BC]"
                >
                  {tool}
                </motion.span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Контент + липкая панель */}
      <div className="relative mx-auto grid max-w-[1280px] items-start gap-12 px-6 lg:grid-cols-[1.5fr_1fr]">
        <div className="min-w-0">
          {/* 3. Чему научитесь */}
          <section className="pb-16">
            <h2 className="font-display text-2xl font-bold md:text-3xl">
              Чему <span className="text-gradient">научитесь</span>
            </h2>
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {[
                { icon: MessageSquareText, t: 'Писать промпты, которые работают с первого раза' },
                { icon: FileText, t: 'Автоматизировать документы и письма' },
                { icon: Table2, t: 'Считать и анализировать в таблицах с ИИ' },
                { icon: Presentation, t: 'Собирать презентации за 15 минут' },
                { icon: ShieldCheck, t: 'Работать без VPN на российском стеке' },
                { icon: BrainCircuit, t: 'Собрать личный промптбук под свои задачи' },
              ].map((item, i) => (
                <motion.div
                  key={item.t}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.08, duration: 0.5, ease: EASE }}
                  className="glass group flex items-start gap-4 rounded-[16px] p-5"
                >
                  <item.icon className="h-6 w-6 shrink-0 text-[#9AA6BC] transition-colors group-hover:text-[#7C5CFF]" />
                  <span className="text-[14px] text-[#F2F5FA]">{item.t}</span>
                </motion.div>
              ))}
            </div>
          </section>

          {/* 4. Программа */}
          <section id="program" className="scroll-mt-24 pb-16">
            <h2 className="font-display text-2xl font-bold md:text-3xl">
              Программа — <span className="text-gradient">{course.modulesCount} модулей</span>
            </h2>
            <div className="mt-8 space-y-3">
              {course.modules.map((mod, mi) => {
                const open = openModules.includes(mi)
                const lessons = mod.lessons ?? []
                const totalMin = lessons.reduce((s, l) => s + (l.durationMin ?? 0), 0)
                return (
                  <div key={mod.id} className="glass overflow-hidden rounded-[18px]">
                    <button
                      onClick={() =>
                        setOpenModules((v) => (open ? v.filter((x) => x !== mi) : [...v, mi]))
                      }
                      className="flex w-full items-center gap-4 px-5 py-5 text-left"
                    >
                      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand-gradient font-display text-[13px] font-bold text-white">
                        {mi + 1}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[15px] font-semibold">{mod.title}</span>
                        <span className="mt-0.5 block text-[12px] text-[#5C6B84]">
                          {lessons.length} уроков
                          {totalMin > 0 ? ` · ${Math.floor(totalMin / 60) > 0 ? `${(totalMin / 60).toFixed(1).replace('.', ',')} ч` : `${totalMin} мин`}` : ''}
                        </span>
                      </span>
                      <ChevronDown
                        className={cn('h-4 w-4 shrink-0 text-[#9AA6BC] transition-transform duration-300', open && 'rotate-180')}
                      />
                    </button>
                    <AnimatePresence initial={false}>
                      {open && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.35, ease: EASE }}
                        >
                          <ul className="border-t border-white/[0.06] px-5 py-3">
                            {lessons.map((lesson, li) => (
                              <motion.li
                                key={lesson.id}
                                initial={{ opacity: 0, x: -12 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: li * 0.04, duration: 0.25 }}
                                className="flex items-center gap-3 border-b border-white/[0.04] py-3 last:border-0"
                              >
                                {lesson.isFree ? (
                                  <PlayCircle className="h-4 w-4 shrink-0 text-[#34D399]" />
                                ) : (
                                  <Lock className="h-3.5 w-3.5 shrink-0 text-[#5C6B84]" />
                                )}
                                <span className={cn('flex-1 text-[14px]', lesson.isFree ? 'text-[#F2F5FA]' : 'text-[#9AA6BC]')}>
                                  {lesson.title}
                                </span>
                                {lesson.isFree && (
                                  <span className="rounded-full bg-[#34D399]/15 px-2.5 py-0.5 text-[11px] font-semibold text-[#34D399]">
                                    Открыт
                                  </span>
                                )}
                                {lesson.durationMin > 0 && (
                                  <span className="text-[12px] text-[#5C6B84]">{lesson.durationMin} мин</span>
                                )}
                              </motion.li>
                            ))}
                          </ul>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )
              })}
            </div>
          </section>

          {/* 5. Кто ведёт */}
          <section className="pb-16">
            <h2 className="font-display text-2xl font-bold md:text-3xl">
              Кто <span className="text-gradient">ведёт</span>
            </h2>
            <div className="mt-8 grid gap-5 sm:grid-cols-2">
              {[
                {
                  img: '/expert-portrait.png',
                  title: 'Федин, основатель',
                  text: 'Методология, живые разборы, ответы на сложные вопросы.',
                  ai: false,
                },
                {
                  img: '/ai-twin.png',
                  title: 'AI-двойник',
                  text: 'Ведёт уроки, отвечает 24/7, проверяет задания.',
                  ai: true,
                },
              ].map((p, i) => (
                <motion.div
                  key={p.title}
                  initial={{ opacity: 0, y: 32 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.15, duration: 0.5, ease: EASE }}
                  className="glass relative overflow-hidden rounded-[20px] p-6"
                >
                  {p.ai && (
                    <span className="absolute right-4 top-4 flex items-center gap-2 rounded-full bg-ai-gradient px-3 py-1 text-[12px] font-semibold text-white">
                      <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulse-dot" />
                      ИИ-куратор онлайн
                    </span>
                  )}
                  <img
                    src={p.img}
                    alt={p.title}
                    className={cn('h-24 w-24 rounded-2xl object-cover', p.ai && 'animate-float')}
                    onError={(e) => ((e.target as HTMLImageElement).style.display = 'none')}
                  />
                  <h3 className="mt-4 font-display text-[17px] font-bold">{p.title}</h3>
                  <p className="mt-1.5 text-[14px] text-[#9AA6BC]">{p.text}</p>
                </motion.div>
              ))}
            </div>
            <Link
              to="/about"
              className="mt-6 inline-flex items-center gap-1.5 text-[14px] font-medium text-[#22D3EE] transition-all hover:gap-2.5"
            >
              Об эксперте <ChevronRight className="h-4 w-4" />
            </Link>
          </section>

          {/* 6. Тарифы */}
          <section className="pb-16">
            <h2 className="font-display text-2xl font-bold md:text-3xl">
              Выберите <span className="text-gradient">формат</span>
            </h2>
            <div className="mt-8 grid gap-5 lg:grid-cols-3">
              {[
                {
                  id: 'basic' as const,
                  name: 'Самостоятельный',
                  price: course.price,
                  old: course.oldPrice,
                  features: [`Все ${course.modulesCount} модулей`, 'Доступ навсегда', 'Чат ИИ-куратора', 'Сертификат'],
                  accent: false,
                },
                ...(course.proPrice
                  ? [{
                      id: 'pro' as const,
                      name: 'PRO с куратором',
                      price: course.proPrice,
                      old: null as number | null,
                      features: ['Всё из Самостоятельного', 'Живые разборы', 'Проверка заданий человеком', 'Закрытый чат потока'],
                      accent: true,
                    }]
                  : []),
                {
                  id: 'basic' as const,
                  name: 'Рассрочка',
                  price: monthly,
                  old: null,
                  suffix: '/мес × 12',
                  features: ['Тот же Самостоятельный', 'Одобрение за 2 минуты', 'Без переплаты в акцию', 'Карта или СБП'],
                  accent: false,
                },
              ].map((t, i) => (
                <motion.div
                  key={t.name + i}
                  initial={{ opacity: 0, y: 28 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.12, duration: 0.5, ease: EASE }}
                  className={cn(
                    'relative rounded-[20px] p-6',
                    t.accent
                      ? 'gradient-border lg:scale-[1.03] shadow-[0_0_32px_rgba(124,92,255,0.25)]'
                      : 'glass'
                  )}
                >
                  {t.accent && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-brand-gradient px-4 py-1 text-[12px] font-bold text-white animate-pulse-dot">
                      Рекомендуем
                    </span>
                  )}
                  <h3 className="font-display text-[16px] font-bold">{t.name}</h3>
                  <div className="mt-3 flex items-baseline gap-2">
                    <span className="font-display text-2xl font-bold">
                      {t.suffix ? `от ${formatRub(t.price)}` : formatRub(t.price)}
                    </span>
                    {t.suffix && <span className="text-[13px] text-[#5C6B84]">{t.suffix}</span>}
                    {t.old && <span className="text-[14px] text-[#5C6B84] line-through">{formatRub(t.old)}</span>}
                  </div>
                  <ul className="mt-5 space-y-2.5">
                    {t.features.map((f) => (
                      <li key={f} className="flex items-start gap-2.5 text-[14px] text-[#9AA6BC]">
                        <Check className="mt-0.5 h-4 w-4 shrink-0 text-[#34D399]" /> {f}
                      </li>
                    ))}
                  </ul>
                  <button
                    onClick={() => {
                      setTariff(t.id)
                      buy()
                    }}
                    className={cn('mt-6 w-full', t.accent ? 'btn-primary' : 'btn-ghost')}
                  >
                    Выбрать
                  </button>
                </motion.div>
              ))}
            </div>
          </section>

          {/* 7. Отзывы */}
          <section className="pb-16">
            <h2 className="font-display text-2xl font-bold md:text-3xl">
              Отзывы <span className="text-gradient">о курсе</span>
            </h2>
            <div className="glass mt-8 flex flex-col gap-8 rounded-[20px] p-6 sm:flex-row sm:items-center">
              <div className="text-center sm:w-40">
                <div className="font-display text-4xl font-bold text-gradient">{avgRating}</div>
                <div className="mt-1 flex justify-center text-[#FBBF24]">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-current" />
                  ))}
                </div>
                <div className="mt-1 text-[12px] text-[#5C6B84]">{reviews.length || 812} оценок</div>
              </div>
              <div className="flex-1 space-y-2">
                {ratingDist.map((r, i) => (
                  <div key={r.star} className="flex items-center gap-3 text-[12px] text-[#5C6B84]">
                    <span className="w-6">{r.star} ★</span>
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/5">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${r.pct}%` }}
                        viewport={{ once: true }}
                        transition={{ delay: i * 0.05, duration: 0.8, ease: 'easeOut' }}
                        className="h-full rounded-full bg-brand-gradient"
                      />
                    </div>
                    <span className="w-8 text-right">{r.pct}%</span>
                  </div>
                ))}
              </div>
            </div>

            {reviewsQuery.isLoading ? (
              <div className="mt-6 grid gap-5 md:grid-cols-3">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="glass h-44 animate-pulse rounded-[20px]" />
                ))}
              </div>
            ) : reviews.length === 0 ? (
              <div className="glass mt-6 rounded-[20px] p-8 text-center text-[14px] text-[#9AA6BC]">
                Отзывов пока нет — станьте первым учеником этого курса.
              </div>
            ) : (
              <>
                <div className="mt-6 grid gap-5 md:grid-cols-3">
                  {reviews.slice(0, visibleReviews).map((r, i) => (
                    <motion.div
                      key={r.id}
                      initial={{ opacity: 0, y: 24 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: (i % 3) * 0.08, duration: 0.5, ease: EASE }}
                      className="glass rounded-[20px] p-6"
                    >
                      <div className="flex items-center gap-3">
                        {r.userAvatar ? (
                          <img src={r.userAvatar} alt={r.userName} className="h-10 w-10 rounded-full object-cover" />
                        ) : (
                          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-[#7C5CFF] to-[#22D3EE] text-[13px] font-bold text-white">
                            {r.userName.slice(0, 1).toUpperCase()}
                          </span>
                        )}
                        <div>
                          <div className="text-[14px] font-semibold">{r.userName}</div>
                          <div className="flex text-[#FBBF24]">
                            {Array.from({ length: r.rating }).map((_, j) => (
                              <Star key={j} className="h-3 w-3 fill-current" />
                            ))}
                          </div>
                        </div>
                      </div>
                      <p className="mt-4 text-[14px] text-[#9AA6BC]">{r.text}</p>
                    </motion.div>
                  ))}
                </div>
                {visibleReviews < reviews.length && (
                  <div className="mt-6 text-center">
                    <button onClick={() => setVisibleReviews((v) => v + 3)} className="btn-ghost px-6 py-3 text-[14px]">
                      Показать ещё
                    </button>
                  </div>
                )}
              </>
            )}
          </section>

          {/* 8. FAQ */}
          <section className="pb-16">
            <h2 className="font-display text-2xl font-bold md:text-3xl">
              Частые <span className="text-gradient">вопросы</span>
            </h2>
            <div className="mt-8 space-y-3">
              {FAQ.map((f) => (
                <FaqItem key={f.q} q={f.q} a={f.a} />
              ))}
            </div>
          </section>

          {/* 9. Финальный CTA + другие курсы */}
          <section className="pb-20">
            <motion.div
              initial={{ opacity: 0, y: 32 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: EASE }}
              className="gradient-border rounded-[24px] p-8 text-center md:p-10"
            >
              <GraduationCap className="mx-auto h-8 w-8 text-[#22D3EE]" />
              <h3 className="mt-4 font-display text-2xl font-bold">
                Готовы начать? <span className="text-gradient">Первый урок — бесплатно</span>
              </h3>
              <button onClick={buy} className="btn-primary mt-6">
                Купить за {formatRub(price)}
              </button>
            </motion.div>

            {others.length > 0 && (
              <div className="mt-14">
                <h3 className="font-display text-xl font-bold">Другие курсы</h3>
                <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                  {others.map((c) => (
                    <Link
                      key={c.id}
                      to={`/courses/${c.slug}`}
                      className="glass group overflow-hidden rounded-[18px] transition-transform hover:-translate-y-1"
                    >
                      <div className="relative aspect-video overflow-hidden">
                        <Poster
                          poster={c.poster}
                          title={c.title}
                          className="h-full w-full transition-transform duration-500 group-hover:scale-105"
                        />
                      </div>
                      <div className="p-5">
                        <h4 className="line-clamp-1 text-[14px] font-semibold">{c.title}</h4>
                        <div className="mt-2 font-display text-[15px] font-bold">{formatRub(c.price)}</div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </section>
        </div>

        {/* 2. Липкая панель покупки (desktop) */}
        <aside className="sticky top-[96px] hidden lg:block">
          <motion.div
            initial={{ opacity: 0, x: 32 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, ease: EASE }}
            className="glass rounded-[20px] p-6 shadow-[0_8px_40px_rgba(0,0,0,0.45)]"
          >
            {buyBlock}
            <div className="mt-5 space-y-2 border-t border-white/[0.06] pt-5 text-[13px] text-[#9AA6BC]">
              <p className="flex items-center gap-2"><Bot className="h-4 w-4 text-[#E879F9]" /> ИИ-куратор отвечает 24/7</p>
              <p className="flex items-center gap-2"><InfinityIcon className="h-4 w-4 text-[#22D3EE]" /> Доступ навсегда</p>
              <p className="flex items-center gap-2"><Award className="h-4 w-4 text-[#FBBF24]" /> Сертификат по окончании</p>
            </div>
          </motion.div>
        </aside>
      </div>

      {/* Мобильная липкая панель */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-white/[0.08] bg-[#0D1117]/95 p-4 backdrop-blur-xl lg:hidden">
        <div className="flex items-center gap-4">
          <div className="min-w-0 flex-1">
            <div className="font-display text-lg font-bold">{formatRub(price)}</div>
            <div className="truncate text-[11px] text-[#5C6B84]">от {formatRub(monthly)}/мес</div>
          </div>
          <button
            onClick={buy}
            disabled={checkout.isPending}
            className="btn-primary px-6 py-3 text-[14px] disabled:opacity-60"
          >
            {checkout.isPending ? 'Оформляем…' : 'Купить'}
          </button>
        </div>
      </div>
      <div className="h-20 lg:hidden" />
    </div>
  )
}
