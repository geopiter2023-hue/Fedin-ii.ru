import { memo, useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useGSAP } from '@gsap/react'
import {
  ArrowRight,
  Bot,
  CheckCircle2,
  MessageSquareText,
  Mic,
  Play,
  Sparkles,
} from 'lucide-react'

gsap.registerPlugin(ScrollTrigger, useGSAP)

const ease = [0.16, 1, 0.3, 1] as [number, number, number, number]

/* ---------------- Частицы-синапсы между портретами ---------------- */
const SynapseCanvas = memo(function SynapseCanvas() {
  const ref = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = ref.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let raf = 0
    let w = 0
    let h = 0
    const dpr = Math.min(window.devicePixelRatio || 1, 2)

    const resize = () => {
      const rect = canvas.getBoundingClientRect()
      w = rect.width
      h = rect.height
      canvas.width = w * dpr
      canvas.height = h * dpr
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    resize()
    window.addEventListener('resize', resize)

    const N = 26
    const pts = Array.from({ length: N }, () => ({
      x: Math.random(),
      y: Math.random(),
      vx: (Math.random() - 0.5) * 0.0012,
      vy: (Math.random() - 0.5) * 0.0012,
    }))

    const tick = () => {
      ctx.clearRect(0, 0, w, h)
      for (const p of pts) {
        p.x += p.vx
        p.y += p.vy
        if (p.x < 0 || p.x > 1) p.vx *= -1
        if (p.y < 0 || p.y > 1) p.vy *= -1
      }
      for (let i = 0; i < N; i++) {
        for (let j = i + 1; j < N; j++) {
          const dx = (pts[i].x - pts[j].x) * w
          const dy = (pts[i].y - pts[j].y) * h
          const d = Math.hypot(dx, dy)
          if (d < 110) {
            ctx.strokeStyle = `rgba(124,92,255,${(1 - d / 110) * 0.35})`
            ctx.lineWidth = 1
            ctx.beginPath()
            ctx.moveTo(pts[i].x * w, pts[i].y * h)
            ctx.lineTo(pts[j].x * w, pts[j].y * h)
            ctx.stroke()
          }
        }
      }
      for (const p of pts) {
        ctx.fillStyle = 'rgba(34,211,238,0.8)'
        ctx.beginPath()
        ctx.arc(p.x * w, p.y * h, 1.6, 0, Math.PI * 2)
        ctx.fill()
      }
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', resize)
    }
  }, [])

  return (
    <canvas
      ref={ref}
      style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', zIndex: 1 }}
      aria-hidden
    />
  )
})

/* ---------------- Цифры с count-up ---------------- */
function CountUp({ to, suffix }: { to: number; suffix: string }) {
  const ref = useRef<HTMLSpanElement>(null)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const io = new IntersectionObserver(
      ([entry]) => {
        if (!entry.isIntersecting) return
        io.disconnect()
        const start = performance.now()
        const dur = 1400
        const step = (t: number) => {
          const p = Math.min((t - start) / dur, 1)
          const eased = 1 - Math.pow(1 - p, 3)
          el.textContent = Math.round(to * eased).toLocaleString('ru-RU')
          if (p < 1) requestAnimationFrame(step)
        }
        requestAnimationFrame(step)
      },
      { threshold: 0.5 }
    )
    io.observe(el)
    return () => io.disconnect()
  }, [to])
  return (
    <span className="font-display text-4xl font-bold text-gradient md:text-5xl">
      <span ref={ref}>0</span>
      {suffix}
    </span>
  )
}

const STATS = [
  { to: 5200, suffix: '+', label: 'учеников обучено' },
  { to: 6, suffix: '', label: 'лет практики с нейросетями' },
  { to: 120, suffix: '+', label: 'живых разборов проведено' },
  { to: 24, suffix: '/7', label: 'отвечает AI-двойник' },
]

/* ---------------- Pinned таймлайн (GSAP) ---------------- */
const TIMELINE = [
  {
    year: '2019',
    title: 'Первые эксперименты',
    text: 'GPT и генерация изображений. Понял: это изменит работу всех — и начал разбираться глубже всех вокруг.',
  },
  {
    year: '2021',
    title: 'Внедрения в бизнес',
    text: 'Первые внедрения ИИ в бизнес-процессы компаний и частные консультации. Десятки автоматизаций рутины.',
  },
  {
    year: '2023',
    title: 'Первый курс',
    text: 'Запуск собственного курса по нейросетям: 300 учеников на первом потоке и сотни благодарных отзывов.',
  },
  {
    year: '2024',
    title: 'Платформа FEDIN AI',
    text: 'Собственная платформа, магазин инструментов и Нейроклуб — всё обучение в одном месте, по-русски.',
  },
  {
    year: '2025',
    title: 'AI-двойник',
    text: 'Цифровой двойник ведёт уроки и отвечает ученикам 24/7, обученный на всей моей методологии.',
  },
]

function PinnedTimeline() {
  const root = useRef<HTMLDivElement>(null)

  useGSAP(
    () => {
      const items = gsap.utils.toArray<HTMLElement>('.about-tl-item')
      const line = root.current!.querySelector<HTMLElement>('.about-tl-fill')!
      const pulse = root.current!.querySelector<HTMLElement>('.about-tl-pulse')!

      gsap.set(items, { opacity: 0.35, scale: 0.97 })
      gsap.set(items[0], { opacity: 1, scale: 1 })

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: root.current,
          start: 'top top',
          end: '+=250%',
          pin: true,
          scrub: 0.6,
        },
      })

      tl.to(line, { scaleY: 1, ease: 'none', duration: TIMELINE.length }, 0)
      tl.to(pulse, { top: '100%', ease: 'none', duration: TIMELINE.length }, 0)
      items.forEach((item, i) => {
        if (i === 0) return
        tl.to(
          items[i - 1],
          { opacity: 0.35, scale: 0.97, duration: 0.4 },
          i
        )
        tl.to(item, { opacity: 1, scale: 1, duration: 0.4 }, i)
      })
    },
    { scope: root }
  )

  return (
    <section ref={root} className="relative flex min-h-[100dvh] items-center overflow-hidden bg-[#0D1117]">
      <div className="pointer-events-none absolute left-[-200px] top-1/3 h-[500px] w-[500px] glow-violet" />
      <div className="mx-auto grid w-full max-w-[1280px] gap-12 px-6 py-20 lg:grid-cols-[1fr_1.4fr]">
        <div>
          <span className="chip glass-light text-[#22D3EE]">История</span>
          <h2 className="mt-5 font-display text-4xl font-bold md:text-5xl">
            Мой <span className="text-gradient">путь</span>
          </h2>
          <p className="mt-4 max-w-sm text-[#9AA6BC]">
            Шесть лет — от первых экспериментов до платформы с AI-двойником. Листайте, чтобы
            пройти этот путь вместе со мной.
          </p>
        </div>
        <div className="relative pl-10">
          <div className="absolute left-0 top-0 h-full w-px bg-white/[0.08]" />
          <div
            className="about-tl-fill absolute left-0 top-0 h-full w-px origin-top bg-brand-gradient"
            style={{ transform: 'scaleY(0)' }}
          />
          <div
            className="about-tl-pulse absolute -left-[5px] top-0 h-[11px] w-[11px] rounded-full bg-[#22D3EE] shadow-[0_0_16px_rgba(34,211,238,0.9)]"
          />
          <div className="space-y-10">
            {TIMELINE.map((t) => (
              <div key={t.year} className="about-tl-item">
                <div className="font-display text-3xl font-bold text-gradient">{t.year}</div>
                <div className="mt-1 font-display text-xl font-bold">{t.title}</div>
                <p className="mt-2 max-w-md text-[15px] text-[#9AA6BC]">{t.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

/* ---------------- Данные секций ---------------- */
const TWIN_CARDS = [
  {
    icon: Play,
    title: 'Ведёт уроки',
    text: 'Видеоуроки с цифровым аватаром: та же манера, те же примеры, та же методология — доступно в любое время.',
  },
  {
    icon: MessageSquareText,
    title: 'Отвечает в чате 24/7',
    text: 'Ночью, в выходные, на планёрке — двойник разбирает ваш вопрос и предлагает решение за секунды.',
  },
  {
    icon: CheckCircle2,
    title: 'Проверяет задания',
    text: 'Практические работы получают развёрнутый разбор с комментариями и советами, как улучшить результат.',
  },
]

const CHAT_MOCK = [
  { from: 'user', text: 'Как написать промпт для карточки товара на WB?' },
  { from: 'ai', text: 'Опиши товар, ЦА и выгоду. Формула: роль + задача + контекст + формат. Лови шаблон…' },
  { from: 'user', text: 'А если товар сезонный?' },
  { from: 'ai', text: 'Добавь в промпт сезонный триггер и срочность. В уроке 4 есть готовый пример.' },
]

const PRINCIPLES = [
  {
    num: '01',
    title: 'Практика, а не компиляция бесплатного',
    text: 'Каждый урок заканчивается делом, а не теорией. Вы уходите с готовым результатом: промптом, автоматизацией, контентом.',
  },
  {
    num: '02',
    title: 'Российский стек: без VPN и зарубежных карт',
    text: 'GigaChat, Kandinsky, Shedevrum и легальные способы доступа к мировым сервисам. Всё оплачивается картой РФ или СБП.',
  },
  {
    num: '03',
    title: 'Нейросети должны окупаться: время или деньги',
    text: 'Если инструмент не экономит вам часы и не приносит рубли — он не нужен. Учим только тому, что окупается.',
  },
]

const MEDIA = [
  { title: 'Подкаст «Цифровой этикет»', place: 'Радио Медиаметрикс', year: '2025', icon: Mic },
  { title: 'Конференция AI Journey', place: 'Сбер, Москва', year: '2024', icon: Play },
  { title: 'Интервью «ИИ для малого бизнеса»', place: 'РБК Тренды', year: '2024', icon: Mic },
  { title: 'Форум «Технологии доверия»', place: 'Сколково', year: '2024', icon: Play },
  { title: 'Подкаст «Запуск завтра»', place: 'YouTube', year: '2023', icon: Mic },
  { title: 'Митап «Нейросети в e-com»', place: 'Ozon', year: '2023', icon: Play },
]

export default function About() {
  return (
    <div className="relative overflow-x-clip">
      {/* ---------- Hero ---------- */}
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute -left-40 top-0 h-[600px] w-[600px] glow-violet" />
        <div className="pointer-events-none absolute -right-40 bottom-0 h-[500px] w-[500px] glow-cyan" />
        <div className="mx-auto grid max-w-[1280px] items-center gap-14 px-6 pb-24 pt-16 lg:grid-cols-2 md:pt-24">
          <div>
            <motion.span
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease }}
              className="chip glass-light text-[#E879F9]"
            >
              <Sparkles className="h-3.5 w-3.5" /> Основатель FEDIN AI
            </motion.span>
            <motion.h1
              initial={{ opacity: 0, y: 28 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1, ease }}
              className="mt-6 font-display text-4xl font-extrabold leading-tight md:text-6xl"
            >
              Привет, я <span className="text-gradient">Федин</span>. А это — мой AI-двойник.
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.25, ease }}
              className="mt-6 max-w-lg text-lg text-[#9AA6BC]"
            >
              Практикую нейросети с 2019 года. Научил 5 200+ человек применять ИИ в работе — без
              VPN, без воды, с результатом с первого урока.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.4, ease }}
              className="mt-9 flex flex-wrap gap-4"
            >
              <Link to="/intensive" className="btn-primary">
                Начать бесплатный интенсив
              </Link>
              <Link to="/courses" className="btn-ghost">
                Мои курсы <ArrowRight className="h-4 w-4" />
              </Link>
            </motion.div>
          </div>

          <div className="relative">
            <SynapseCanvas />
            <div className="relative z-10 grid grid-cols-2 gap-5">
              <motion.div
                initial={{ opacity: 0, x: -60 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.9, delay: 0.2, ease }}
                className="gradient-border overflow-hidden rounded-[20px]"
              >
                <img
                  src="/expert-portrait.png"
                  alt="Федин — основатель FEDIN AI"
                  className="aspect-[4/5] w-full object-cover"
                />
                <div className="glass px-4 py-3 text-center text-[13px] font-medium text-[#9AA6BC]">
                  Человек
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, x: 60 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.9, delay: 0.35, ease }}
                className="gradient-border mt-8 overflow-hidden rounded-[20px]"
              >
                <div className="relative">
                  <img
                    src="/ai-twin.png"
                    alt="AI-двойник Федина"
                    className="aspect-square w-full animate-float object-cover"
                  />
                  <div className="pointer-events-none absolute inset-0 animate-pulse-dot bg-[radial-gradient(circle_at_center,rgba(124,92,255,0.18),transparent_70%)]" />
                </div>
                <div className="glass flex items-center justify-center gap-2 px-4 py-3 text-[13px] font-medium text-[#E879F9]">
                  <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-[#E879F9]" />
                  AI-двойник онлайн
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* ---------- Цифры ---------- */}
      <section className="border-y border-white/[0.06] bg-[#0D1117]/60">
        <div className="mx-auto grid max-w-[1280px] gap-10 px-6 py-16 sm:grid-cols-2 lg:grid-cols-4">
          {STATS.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6, delay: i * 0.15, ease }}
              className="relative pb-5"
            >
              <CountUp to={s.to} suffix={s.suffix} />
              <p className="mt-2 text-sm text-[#9AA6BC]">{s.label}</p>
              <motion.span
                initial={{ scaleX: 0 }}
                whileInView={{ scaleX: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.3 + i * 0.15, ease }}
                className="absolute bottom-0 left-0 h-px w-full origin-left bg-brand-gradient"
              />
            </motion.div>
          ))}
        </div>
      </section>

      {/* ---------- Таймлайн ---------- */}
      <PinnedTimeline />

      {/* ---------- Как работает AI-двойник ---------- */}
      <section className="relative mx-auto max-w-[1280px] px-6 py-24">
        <motion.h2
          initial={{ opacity: 0, y: 28 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.7, ease }}
          className="font-display text-3xl font-bold md:text-5xl"
        >
          AI-двойник: <span className="text-gradient">эксперт, который не спит</span>
        </motion.h2>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {TWIN_CARDS.map((c, i) => (
            <motion.div
              key={c.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6, delay: i * 0.12, ease }}
              className="glass rounded-[20px] p-7"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-ai-gradient shadow-[0_0_24px_rgba(232,121,249,0.35)]">
                <c.icon className="h-5 w-5 text-white" />
              </div>
              <h3 className="mt-5 font-display text-xl font-bold">{c.title}</h3>
              <p className="mt-2 text-[15px] text-[#9AA6BC]">{c.text}</p>
              {i === 1 && (
                <div className="mt-5 space-y-2.5">
                  {CHAT_MOCK.map((m, j) => (
                    <motion.div
                      key={j}
                      initial={{ opacity: 0, y: 10 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.4 + j * 0.4, duration: 0.4 }}
                      className={
                        m.from === 'ai'
                          ? 'mr-4 rounded-xl rounded-tl-sm bg-ai-gradient/15 border border-[#E879F9]/20 px-3.5 py-2.5 text-[13px] text-[#F2F5FA]'
                          : 'ml-4 rounded-xl rounded-tr-sm glass-light px-3.5 py-2.5 text-[13px] text-[#9AA6BC]'
                      }
                    >
                      {m.text}
                    </motion.div>
                  ))}
                </div>
              )}
            </motion.div>
          ))}
        </div>
        <p className="mt-8 flex items-start gap-2 text-[13px] text-[#5C6B84]">
          <Bot className="mt-0.5 h-4 w-4 shrink-0" />
          Двойник обучен на материалах и методологии Федина; сложные вопросы передаёт
          человеку-куратору.
        </p>
      </section>

      {/* ---------- Принципы ---------- */}
      <section className="bg-[#0D1117]/60 py-24">
        <div className="mx-auto max-w-[1280px] px-6">
          <motion.h2
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7, ease }}
            className="font-display text-3xl font-bold md:text-5xl"
          >
            Во что я <span className="text-gradient">верю</span>
          </motion.h2>
          <div className="mt-12 space-y-2">
            {PRINCIPLES.map((p, i) => (
              <motion.div
                key={p.num}
                initial={{ opacity: 0, y: 40, clipPath: 'inset(100% 0 0 0)' }}
                whileInView={{ opacity: 1, y: 0, clipPath: 'inset(0% 0 0 0)' }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ duration: 0.7, delay: i * 0.1, ease }}
                className="flex flex-col gap-3 border-b border-white/[0.06] py-8 md:flex-row md:items-baseline md:gap-10"
              >
                <span className="font-display text-4xl font-bold text-gradient md:text-5xl">
                  {p.num}
                </span>
                <div>
                  <h3 className="font-display text-2xl font-bold md:text-[32px]">{p.title}</h3>
                  <p className="mt-2 max-w-2xl text-[#9AA6BC]">{p.text}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------- Медиа ---------- */}
      <section className="py-24">
        <div className="mx-auto max-w-[1280px] px-6">
          <motion.h2
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7, ease }}
            className="font-display text-3xl font-bold md:text-5xl"
          >
            Медиа и <span className="text-gradient">выступления</span>
          </motion.h2>
        </div>
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="mt-10 flex cursor-grab gap-5 overflow-x-auto px-6 pb-4 [scrollbar-width:none] lg:px-[max(24px,calc((100vw-1280px)/2+24px))]"
        >
          {MEDIA.map((m) => (
            <motion.div
              key={m.title}
              whileHover={{ y: -6 }}
              className="glass w-[260px] shrink-0 rounded-[20px] p-6 transition-shadow hover:shadow-[0_0_32px_rgba(124,92,255,0.3)]"
            >
              <div className="flex h-36 items-center justify-center rounded-xl bg-gradient-to-br from-[#7C5CFF]/25 to-[#22D3EE]/15">
                <m.icon className="h-9 w-9 text-[#22D3EE]" />
              </div>
              <h3 className="mt-4 font-display text-[15px] font-bold leading-snug">{m.title}</h3>
              <p className="mt-1.5 text-[13px] text-[#9AA6BC]">
                {m.place} · {m.year}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* ---------- Цитата ---------- */}
      <section className="relative overflow-hidden py-28">
        <div className="pointer-events-none absolute left-1/2 top-1/2 h-[600px] w-[800px] -translate-x-1/2 -translate-y-1/2 glow-violet animate-drift" />
        <div className="relative mx-auto max-w-4xl px-6 text-center">
          <motion.span
            initial={{ opacity: 0, scale: 0.6 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease }}
            className="font-display text-7xl text-gradient"
          >
            «
          </motion.span>
          <motion.blockquote
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.8, ease }}
            className="font-display text-2xl font-bold leading-snug md:text-[32px]"
          >
            Нейросети не заменят вас. Заменит человек, который ими пользуется.
          </motion.blockquote>
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-6 text-[#9AA6BC]"
          >
            — Федин, основатель FEDIN AI
          </motion.p>
        </div>
      </section>

      {/* ---------- Финальный CTA ---------- */}
      <section className="mx-auto max-w-[1280px] px-6 pb-28">
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.7, ease }}
          className="gradient-border relative overflow-hidden rounded-[24px] p-10 text-center md:p-16"
        >
          <div className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 glow-violet animate-drift" />
          <div className="pointer-events-none absolute -bottom-24 -right-24 h-72 w-72 glow-cyan" />
          <h2 className="relative font-display text-3xl font-bold md:text-4xl">
            Познакомьтесь с моим двойником — <span className="text-gradient">бесплатно</span>
          </h2>
          <p className="relative mx-auto mt-4 max-w-xl text-[#9AA6BC]">
            Интенсив «Нейросети за 3 дня» ведёт AI-двойник. 0 ₽, старт сразу после регистрации.
          </p>
          <div className="relative mt-8">
            <Link to="/intensive" className="btn-primary px-10 py-4 text-lg">
              Начать интенсив — 0 ₽
            </Link>
          </div>
        </motion.div>
      </section>
    </div>
  )
}
