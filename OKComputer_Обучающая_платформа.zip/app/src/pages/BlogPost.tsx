import { useEffect, useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { motion, useScroll, useSpring } from 'framer-motion'
import { ArrowLeft, ArrowRight, Check, Clock, Copy, Eye, Send, Users } from 'lucide-react'
import { ARTICLES } from './Blog'
import { cn } from '@/lib/utils'

type Section = {
  id: string
  heading: string
  paragraphs: string[]
  quote?: string
  prompt?: string
}

type Post = {
  sections: Section[]
}

const ease = [0.16, 1, 0.3, 1] as [number, number, number, number]

const BODY: Record<string, Post> = {
  'payment-2025': {
    sections: [
      {
        id: 'problem',
        heading: 'Почему оплата стала проблемой',
        paragraphs: [
          'С 2022 года российские карты Visa и Mastercard не работают за рубежом, а OpenAI и Midjourney не принимают Мир. При этом подписки на нейросети стали рабочим инструментом: отказаться от них — значит проиграть конкурентам в скорости.',
          'Хорошая новость: за три года рынок приспособился. Появились легальные способы оплатить зарубежные сервисы из России — с комиссией от 3 до 15%. В этой статье разберём три рабочих варианта и честно скажем, когда проще перейти на российские аналоги.',
          'Сразу дисклеймер: мы не рекламируем конкретных посредников. Проверяйте отзывы и начинайте с минимальной суммы — рынок меняется быстро.',
        ],
      },
      {
        id: 'ways',
        heading: 'Три рабочих способа оплаты',
        paragraphs: [
          'Способ первый — виртуальные зарубежные карты. Сервисы-посредники выпускают карту с балансом в долларах: вы пополняете её переводом в рублях (часто через СБП) и платите как обычной картой. Комиссия 5–10%, карта выпускается за 10 минут.',
          'Способ второй — оплата через посредника «под ключ». Вы даёте логин от аккаунта (лучше создать отдельный), посредник оплачивает подписку со своей карты. Комиссия выше — 10–15%, зато не нужно разбираться с картами и балансами.',
          'Способ третий — российские альтернативы. GigaChat закрывает 80% задач ChatGPT, Kandinsky и Shedevrum заменяют Midjourney для типовых задач, а оплачиваются они картой РФ или вовсе бесплатны. Для большинства рабочих задач этого достаточно.',
        ],
        quote:
          'Правило простое: если задача разовая — используйте российские сервисы. Если нужен конкретный инструмент каждый день — оформляйте виртуальную карту.',
        prompt:
          'Сравни GigaChat и ChatGPT для задачи: [опиши вашу задачу]. Составь таблицу: качество ответа, скорость, ограничения, цена. Дай рекомендацию, что выбрать.',
      },
      {
        id: 'steps',
        heading: 'Пошагово: оплачиваем ChatGPT Plus',
        paragraphs: [
          'Шаг 1. Выберите сервис виртуальных карт с отзывами и поддержкой на русском. Зарегистрируйтесь, пройдите минимальную верификацию.',
          'Шаг 2. Пополните баланс с запасом: подписка $20 + комиссия сервиса + возможная комиссия за конвертацию. Обычно достаточно эквивалента 2 500 ₽.',
          'Шаг 3. Привяжите карту в настройках биллинга OpenAI. Если платёж не проходит — попробуйте другой BIN карты или включите VPN страны-эмитента карты на время оплаты. Дальше сервис работает из России без ограничений.',
          'Тот же алгоритм работает для Midjourney, Claude, Notion AI и большинства других подписок. Храните реквизиты карты в менеджере паролей и следите за датой списания.',
        ],
      },
    ],
  },
  'gigachat-prompts': {
    sections: [
      {
        id: 'why-gigachat',
        heading: 'Почему GigaChat — рабочая лошадка',
        paragraphs: [
          'GigaChat от Сбера — полноценная русскоязычная нейросеть: понимает контекст, умеет в документы, таблицы и генерацию изображений через Kandinsky. Главное — доступна бесплатно, без VPN и зарубежных карт.',
          'Секрет продуктивности не в модели, а в промптах. Ниже — десять готовых промптов, которые наши ученики используют каждый день. Каждый экономит от 5 до 30 минут, в сумме — больше часа.',
        ],
      },
      {
        id: 'prompts-list',
        heading: '10 промптов на каждый день',
        paragraphs: [
          '1. Письма. «Напиши вежливое деловое письмо клиенту: мы задерживаем поставку на 3 дня, предлагаем скидку 5%. Тон — уверенный, без канцелярита, до 120 слов».',
          '2. Встречи. «Вот расшифровка планёрки: [текст]. Выдели: решения, ответственных, дедлайны, открытые вопросы. Формат — таблица».',
          '3. Анализ документов. «Прочитай договор ниже и перечисли риски для исполнителя: штрафы, сроки, односторонние условия. Объясни простым языком».',
          '4. Отчёты. «Собери из этих данных отчёт для руководства на одну страницу: вывод, цифры, причина, план действий».',
          '5–10. Остальные промпты — для постов в соцсети, описаний вакансий, планов обучения, ответов на отзывы, мозгового штурма и перевода с «корпоративного» на человеческий. Все они построены по одной формуле.',
        ],
        prompt:
          'Ты — [роль]. Задача: [что сделать]. Контекст: [вводные]. Формат ответа: [структура, объём, тон]. Ограничения: [чего избегать].',
        quote:
          'Формула сильного промпта: роль + задача + контекст + формат. Четыре элемента — и нейросеть попадает в ожидания с первого раза.',
      },
      {
        id: 'practice',
        heading: 'Как внедрить за неделю',
        paragraphs: [
          'Не пытайтесь запомнить все десять. Выберите три задачи, которые отнимают у вас больше всего времени, и сохраните промпты под них в заметках или в шаблонах.',
          'Через неделю посчитайте сэкономленное время — обычно выходит 4–6 часов. Эти часы и есть ваша окупаемость: дальше можно добавлять промпты под более сложные задачи.',
          'На нашем бесплатном интенсиве мы разбираем эту систему на живых примерах и собираем персональную библиотеку промптов под вашу профессию.',
        ],
      },
    ],
  },
  'reels-neuro': {
    sections: [
      {
        id: 'pipeline',
        heading: 'Пайплайн: 4 этапа за вечер',
        paragraphs: [
          'Классическое производство одного Reels — день работы: сценарий, съёмка, озвучка, монтаж. С нейросетями весь цикл сжимается до 2–3 вечерних часов, а качество остаётся на уровне для соцсетей.',
          'Пайплайн такой: сценарий генерирует чат-бот, голос — синтез речи, визуал — видеогенератор или стоки с ИИ-обработкой, монтаж — автоматический редактор. Разберём каждый этап.',
        ],
      },
      {
        id: 'script',
        heading: 'Этап 1–2: сценарий и озвучка',
        paragraphs: [
          'Сценарий. Дайте нейросети тему, целевую аудиторию и хронометраж. Просите структуру: хук первых 2 секунд, польза, призыв к действию. Обычно хватает 2–3 итераций, чтобы получить рабочий текст на 30–45 секунд.',
          'Озвучка. Российские синтезаторы (например, от Яндекса или Сбера) читают текст естественно, с интонациями. Выбирайте голос под характер канала и не гонитесь за «идеальным» — слегка живое звучание работает лучше.',
        ],
        prompt:
          'Напиши сценарий Reels на 35 секунд на тему [тема]. Аудитория: [кто]. Структура: хук (до 8 слов) — 3 пункта пользы — призыв подписаться. Дай 3 варианта хука.',
      },
      {
        id: 'visual',
        heading: 'Этап 3–4: видеоряд и монтаж',
        paragraphs: [
          'Видеоряд. Генерируйте фоновые футажи в видеогенераторах или берите стоки и стилизуйте их нейросетями под единый стиль канала. Вертикальный формат 9:16, сцены по 2–3 секунды — ритм решает всё.',
          'Монтаж. Редакторы с ИИ (CapCut и аналоги) сами нарезают видео под аудиодорожку, накладывают автосубтитры и подбирают переходы. Ваша задача — проверить смысловые акценты и поправить подписи.',
          'Финал. Загрузите ролик, добавьте обложку с крупным текстом и 3–5 релевантных хэштегов. Первый Reels пайплайном — за вечер, десятый — за 40 минут.',
        ],
        quote:
          'Нейросети не делают контент интересным — они убирают рутину. Идея и польза по-прежнему на вас.',
      },
    ],
  },
  'wb-cards-ctr': {
    sections: [
      {
        id: 'why-ctr',
        heading: 'Почему главное фото решает всё',
        paragraphs: [
          'На Wildberries и Ozon покупатель видит сначала обложку карточки в выдаче — и за секунду решает, кликать или нет. CTR карточки напрямую влияет на позиции: маркетплейс поднимает товары, на которые кликают.',
          'Нейросети позволяют за копейки делать то, за что студии брали десятки тысяч: студийные фоны, инфографику, сезонные варианты. Разберём рабочую схему, которая у наших учеников даёт +20–30% к CTR.',
        ],
      },
      {
        id: 'how',
        heading: 'Три приёма с нейросетями',
        paragraphs: [
          'Приём 1. Замена фона. Снимаете товар на телефон при дневном свете, нейросеть вырезает его и подставляет студийный фон: градиент, сцену использования, лайфстайл. Важно: товар должен остаться реальным — маркетплейсы штрафуют за «нарисованный» товар.',
          'Приём 2. Инфографика. Генерируете чистые фоны-шаблоны и размещаете 2–3 ключевые выгоды крупным шрифтом. Текст делайте сами в редакторе — нейросети пока плохо пишут по-русски на картинках.',
          'Приём 3. A/B-тесты. Делаете 3–4 варианта главного фото (разные фоны, ракурсы, инфографика) и тестируете их через встроенные эксперименты WB или ротацию раз в 3 дня. Победителя оставляете.',
        ],
        prompt:
          'Опиши идеальный фон для карточки товара: [товар]. Целевая аудитория: [кто]. Дай 3 варианта промпта для генерации фона: студийный, лайфстайл, сезонный. Укажи свет и композицию.',
        quote:
          'Правило выдачи: обложка должна быть понятна размером со спичечный коробок. Проверяйте миниатюру, а не полный размер.',
      },
      {
        id: 'case',
        heading: 'Кейс: +31% CTR за две недели',
        paragraphs: [
          'Ученик курса продавал термокружки: обложка — фото на белом фоне от поставщика, CTR 2,1%. Сделали три новых фона: рабочий стол, автомобиль, зимняя сцена — и добавили инфографику «держит тепло 6 часов».',
          'Тест показал победителя — зимнюю сцену. CTR вырос до 2,76% (+31%), карточка поднялась в выдаче, продажи выросли на 19% без изменения цены и рекламного бюджета.',
          'Весь цикл занял два вечера и около 300 ₽ на генерации. Такая математика и есть главный аргумент в пользу нейросетей в e-commerce.',
        ],
      },
    ],
  },
  'n8n-start': {
    sections: [
      {
        id: 'what',
        heading: 'Что такое n8n и почему это просто',
        paragraphs: [
          'n8n — конструктор автоматизаций: соединяете узлы линиями, и данные текут между сервисами сами. Telegram-бот, принимающий заказ и отвечающий нейросетью, — это 6 узлов и один вечер.',
          'В отличие от программирования, здесь не нужен код: настройка происходит в визуальном редакторе. А в отличие от Zapier — n8n можно бесплатно развернуть на своём сервере, что важно для работы из России.',
        ],
      },
      {
        id: 'build',
        heading: 'Собираем бота за час',
        paragraphs: [
          'Шаг 1. Установка. Проще всего — облачная версия n8n или Docker на своём VPS за 200 ₽/мес. Регистрируетесь, попадаете в пустой редактор.',
          'Шаг 2. Триггер. Добавляете узел Telegram Trigger и подключаете бота через токен от BotFather. Теперь каждое сообщение боту запускает сценарий.',
          'Шаг 3. Нейросеть. Узел HTTP Request отправляет текст сообщения в API GigaChat или другой модели. Ответ возвращается узлом Telegram Send Message. Всё — бот отвечает.',
          'Шаг 4. Улучшения. Добавьте узел памяти (контекст диалога), фильтр команд и запись диалогов в Google-таблицу. Это ещё 20 минут, а выглядит уже как серьёзный продукт.',
        ],
        prompt:
          'Ты — помощник в Telegram-боте [название бизнеса]. Отвечай коротко, до 3 предложений. Если не знаешь ответ — предлагай связаться с оператором. Тон: дружелюбный, без эмодзи.',
        quote:
          'Первая автоматизация должна быть маленькой и полезной. Бот, отвечающий на частые вопросы, окупает вечер настройки уже за неделю.',
      },
      {
        id: 'next',
        heading: 'Куда расти дальше',
        paragraphs: [
          'Дальше — связки посерьёзнее: заявка с сайта → CRM → уведомление менеджеру; новый пост в Telegram → автопостинг в VK; счёт в «1С» → письмо клиенту.',
          'В нашем магазине есть готовые n8n-связки с инструкциями: импортируете JSON, подставляете свои ключи — и автоматизация работает. А на курсе «Маркетинг и ИИ-агенты» собираем автоворонки под ключ.',
        ],
      },
    ],
  },
  'vibe-coding-mvp': {
    sections: [
      {
        id: 'idea',
        heading: 'Пятница, 18:00: есть только идея',
        paragraphs: [
          'Идея простая: сервис, который собирает отзывы с маркетплейсов и пишет черновики ответов. Раньше на MVP ушли бы недели и разработчик. Я решил проверить вайб-кодинг: описываешь задачу нейросети, она пишет код, ты направляешь.',
          'Инструменты: Cursor с Claude внутри. Бюджет: подписка $20 и выходные. Опыт программирования — общее понимание, как устроен веб, без умения писать код с нуля.',
        ],
      },
      {
        id: 'process',
        heading: 'Как шла работа',
        paragraphs: [
          'Суббота. Начал с ТЗ: написал нейросети подробное описание продукта — экраны, сценарии, ограничения. Это самый важный шаг: чем точнее контекст, тем меньше переделок. По ТЗ агент сгенерировал каркас на React и FastAPI.',
          'Дальше — итерации. «Добавь авторизацию через Telegram», «сделай таблицу отзывов с фильтром по рейтингу». Каждый запрос — 5–15 минут ожидания и проверка результата. Из 40 итераций примерно 7 пришлось откатить: нейросеть иногда ломала работающее.',
          'Воскресенье, 22:00. Рабочий MVP: парсинг отзывов, генерация черновиков ответов, простая аналитика. Деплой на бесплатный хостинг — и ссылка отправлена трём знакомым селлерам.',
        ],
        quote:
          'Вайб-кодинг — это не «нейросеть пишет за вас». Это работа техлида: вы формулируете, проверяете и принимаете решения. Руки — у модели, голова — у вас.',
        prompt:
          'Ты — senior-разработчик. Прежде чем писать код, задай мне 5 уточняющих вопросов о продукте. Затем предложи архитектуру и план из 10 шагов. Код пиши только после моего «ок».',
      },
      {
        id: 'results',
        heading: 'Выводы и ограничения',
        paragraphs: [
          'Что получилось отлично: скорость. За выходные — продукт, на который раньше ушёл бы месяц. Первые пользователи дали обратную связь уже в понедельник.',
          'Где нейросеть буксовала: сложная бизнес-логика и «невидимые» баги. Модель уверенно пишет код, который иногда не работает, — поэтому базовое понимание технологий всё же нужно.',
          'Вердикт: для MVP, внутренних инструментов и лендингов вайб-кодинг — суперсила. Для высоконагруженных систем пока нужны профессиональные разработчики — но и они уже работают в связке с ИИ.',
        ],
      },
    ],
  },
  'deepseek-vs-chatgpt': {
    sections: [
      {
        id: 'intro',
        heading: 'Два фаворита российского пользователя',
        paragraphs: [
          'DeepSeek ворвался в начале 2025 года: качество на уровне топовых моделей, бесплатный веб-доступ и лояльное отношение к пользователям из России. ChatGPT остаётся эталоном — но требует обходных путей с оплатой.',
          'Мы прогнали обе модели через 50 типовых рабочих задач наших учеников: тексты, анализ, код, таблицы, переводы. Вот честные результаты без фанатизма.',
        ],
      },
      {
        id: 'compare',
        heading: 'Сравнение по задачам',
        paragraphs: [
          'Русский язык и тексты. Паритет. Обе модели пишут грамотно; ChatGPT чуть лучше держит сложный тон, DeepSeek иногда суше, но быстрее.',
          'Анализ и рассуждения. DeepSeek-R1 с режимом размышлений неожиданно силён в математике и логике — местами лучше базового GPT. Но GPT-4o стабильнее на длинных многошаговых задачах.',
          'Код. Почти паритет для типовых задач. Для сложной архитектуры лучше справляется ChatGPT (и специализированный Claude).',
          'Практика. DeepSeek: бесплатно, работает из России без VPN, но бывают перегрузки в пиковые часы. ChatGPT: $20/мес плюс танцы с оплатой, зато экосистема — GPTs, память, голос.',
        ],
        quote:
          'Наш вердикт: ежедневная рабочая лошадка — DeepSeek (бесплатно и доступно). Для критичных задач и сложных проектов — подписка ChatGPT как второй инструмент.',
      },
      {
        id: 'recommendations',
        heading: 'Практические рекомендации',
        paragraphs: [
          'Начните с DeepSeek: ноль затрат, мгновенный старт. Прогоните свои типовые задачи и сравните с тем, что выдаёт GigaChat, — у многих российская модель выигрывает в русском контексте.',
          'Если упираетесь в лимиты или качество — тогда оформляйте ChatGPT Plus по нашей инструкции (ссылка в конце статьи). И помните: модель — это 30% результата, остальные 70% — ваши промпты.',
        ],
      },
    ],
  },
  'ai-career-fear': {
    sections: [
      {
        id: 'fear',
        heading: 'Страх, который мешает действовать',
        paragraphs: [
          '«Нейросети отнимут работу» — главный вопрос на каждом моём эфире. Страх понятен: заголовки кричат об увольнениях, а ИИ действительно пишет тексты, рисует и программирует.',
          'Но давайте смотреть трезво. За шесть лет я наблюдаю одну и ту же картину: исчезают не профессии, а задачи. А люди, которые первыми осваивают инструменты, получают преимущество на годы.',
        ],
      },
      {
        id: 'facts',
        heading: 'Что уже изменилось на самом деле',
        paragraphs: [
          'Что ИИ делает лучше человека: черновики текстов, рутинный анализ данных, первичную обработку заявок, типовой код, переводы. Если ваша работа состоит только из этого — риск реальный.',
          'Что ИИ делает хуже: переговоры, ответственность за результат, понимание контекста бизнеса, работу с противоречивыми требованиями, эмпатию. Всё, где нужен человек между строк.',
          'Главный эффект — усиление. Бухгалтер с ИИ закрывает месяц за 2 дня вместо 5. Маркетолог делает 10 креативов вместо 2. Юрист проверяет договор за час вместо дня. Эти люди не теряют работу — они становятся дороже.',
        ],
        quote:
          'Вопрос не «заменит ли ИИ мою профессию», а «какие мои задачи я отдам ИИ первыми — и на что потрачу освободившееся время».',
      },
      {
        id: 'plan',
        heading: 'План перестройки на 2025 год',
        paragraphs: [
          'Шаг 1. Выпишите свои 10 регулярных задач и отметьте, какие из них шаблонные. Именно их автоматизируйте первыми — это даст быструю победу и уверенность.',
          'Шаг 2. Освойте базовый стек: чат-бот для текстов и анализа, генератор изображений, одну автоматизацию. Три недели по часу в день — и вы в топ-10% своего отдела по цифровым навыкам.',
          'Шаг 3. Развивайте то, что не автоматизируется: экспертизу, коммуникацию, управление. Связка «глубокая профессия + нейросети» — самая защищённая позиция на рынке.',
          'С чего начать прямо сегодня: наш бесплатный интенсив «Нейросети за 3 дня». Три вечера — и у вас рабочий стек инструментов под вашу профессию.',
        ],
      },
    ],
  },
}

function PromptBlock({ text }: { text: string }) {
  const [copied, setCopied] = useState(false)
  return (
    <div className="relative my-6 overflow-hidden rounded-2xl border border-white/[0.08] bg-[#0D1117]">
      <div className="flex items-center justify-between border-b border-white/[0.06] px-4 py-2.5">
        <span className="text-[12px] font-semibold uppercase tracking-wider text-[#5C6B84]">
          Промпт — копируйте
        </span>
        <button
          onClick={async () => {
            try {
              await navigator.clipboard.writeText(text)
            } catch {
              /* noop */
            }
            setCopied(true)
            setTimeout(() => setCopied(false), 2000)
          }}
          className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[12px] font-medium text-[#22D3EE] transition-colors hover:bg-white/5"
        >
          {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
          {copied ? 'Скопировано' : 'Копировать'}
        </button>
      </div>
      <pre className="whitespace-pre-wrap px-5 py-4 font-mono2 text-[13.5px] leading-relaxed text-[#F2F5FA]">
        {text}
      </pre>
    </div>
  )
}

export default function BlogPost() {
  const { id } = useParams<{ id: string }>()
  const meta = ARTICLES.find((a) => a.id === id)
  const body = id ? BODY[id] : undefined

  const { scrollYProgress } = useScroll()
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 25 })

  const [active, setActive] = useState<string>('')
  const [copiedLink, setCopiedLink] = useState(false)

  useEffect(() => {
    if (!body) return
    const headings = body.sections
      .map((s) => document.getElementById(s.id))
      .filter((el): el is HTMLElement => !!el)
    const onScroll = () => {
      const pos = window.scrollY + 140
      let current = headings[0]?.id ?? ''
      for (const h of headings) {
        if (h.offsetTop <= pos) current = h.id
      }
      setActive(current)
    }
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [body])

  const more = useMemo(() => ARTICLES.filter((a) => a.id !== id).slice(0, 2), [id])

  if (!meta || !body) {
    return (
      <div className="mx-auto flex min-h-[60vh] max-w-[720px] flex-col items-center justify-center px-6 py-24 text-center">
        <h1 className="font-display text-3xl font-bold">Статья не найдена</h1>
        <p className="mt-3 text-[#9AA6BC]">Возможно, она была перемещена или удалена.</p>
        <Link to="/blog" className="btn-primary mt-8">
          <ArrowLeft className="h-4 w-4" /> Ко всем статьям
        </Link>
      </div>
    )
  }

  return (
    <div className="relative">
      {/* Прогресс чтения */}
      <motion.div
        style={{ scaleX: progress }}
        className="fixed inset-x-0 top-0 z-[70] h-[3px] origin-left bg-brand-gradient"
      />

      <div className="mx-auto max-w-[1280px] px-6 pb-24 pt-12">
        <div className="lg:grid lg:grid-cols-[1fr_240px] lg:gap-14">
          {/* Колонка статьи */}
          <article className="mx-auto w-full max-w-[720px]">
            <Link
              to="/blog"
              className="inline-flex items-center gap-2 text-sm text-[#9AA6BC] transition-colors hover:text-[#F2F5FA]"
            >
              <ArrowLeft className="h-4 w-4" /> База знаний
            </Link>

            <div className="mt-6">
              <span className="chip glass-light text-[#22D3EE]">{meta.category}</span>
            </div>
            <motion.h1
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease }}
              className="mt-5 font-display text-3xl font-extrabold leading-tight md:text-5xl"
            >
              {meta.title}
            </motion.h1>

            <div className="mt-6 flex flex-wrap items-center gap-4 text-[13px] text-[#5C6B84]">
              <span className="flex items-center gap-2">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-gradient text-[11px] font-bold text-white">
                  FA
                </span>
                Команда FEDIN AI
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5" /> {meta.minutes} мин чтения
              </span>
              <span>{meta.date}</span>
              <span className="inline-flex items-center gap-1.5">
                <Eye className="h-3.5 w-3.5" /> {meta.views} просмотров
              </span>
            </div>

            <motion.img
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.15, ease }}
              src={meta.cover}
              alt={meta.title}
              className="mt-8 aspect-video w-full rounded-[20px] object-cover"
            />

            {/* Тело статьи */}
            <div className="mt-10 text-[17px] leading-[1.75] text-[#C9D2E2]">
              {body.sections.map((s, si) => (
                <section key={s.id} className="mt-12 first:mt-0">
                  <motion.h2
                    id={s.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: '-60px' }}
                    transition={{ duration: 0.6, ease }}
                    className="scroll-mt-24 font-display text-2xl font-bold text-[#F2F5FA] md:text-3xl"
                  >
                    <span className="mr-3 inline-block h-5 w-1.5 rounded-full bg-brand-gradient align-middle" />
                    {s.heading}
                  </motion.h2>
                  {s.paragraphs.map((p, i) => (
                    <p key={i} className="mt-5">
                      {p}
                    </p>
                  ))}
                  {s.quote && (
                    <blockquote className="my-7 rounded-r-2xl border-l-4 border-transparent bg-white/[0.04] px-6 py-5 text-[#F2F5FA] [border-image:linear-gradient(180deg,#7C5CFF,#22D3EE)_1]">
                      {s.quote}
                    </blockquote>
                  )}
                  {s.prompt && <PromptBlock text={s.prompt} />}
                  {si === 1 && (
                    <div className="gradient-border my-10 flex flex-col items-start justify-between gap-4 rounded-[20px] p-6 sm:flex-row sm:items-center">
                      <div>
                        <div className="font-display text-lg font-bold">
                          Этому учим на курсе
                        </div>
                        <p className="mt-1 text-sm text-[#9AA6BC]">
                          Практика, разборы и обратная связь — без воды.
                        </p>
                      </div>
                      <Link to="/courses" className="btn-primary shrink-0 px-5 py-3 text-sm">
                        Смотреть курсы <ArrowRight className="h-4 w-4" />
                      </Link>
                    </div>
                  )}
                </section>
              ))}
            </div>

            {/* Поделиться */}
            <div className="mt-14 flex flex-wrap items-center gap-3 border-t border-white/[0.08] pt-8">
              <span className="text-sm text-[#5C6B84]">Поделиться:</span>
              <a
                href={`https://t.me/share/url?url=${encodeURIComponent(`https://fedin-ii.ru/blog/${meta.id}`)}&text=${encodeURIComponent(meta.title)}`}
                target="_blank"
                rel="noreferrer"
                className="flex h-10 w-10 items-center justify-center rounded-xl glass-light text-[#9AA6BC] transition-colors hover:text-[#22D3EE]"
                aria-label="Поделиться в Telegram"
              >
                <Send className="h-4 w-4" />
              </a>
              <a
                href={`https://vk.com/share.php?url=${encodeURIComponent(`https://fedin-ii.ru/blog/${meta.id}`)}`}
                target="_blank"
                rel="noreferrer"
                className="flex h-10 w-10 items-center justify-center rounded-xl glass-light text-[#9AA6BC] transition-colors hover:text-[#22D3EE]"
                aria-label="Поделиться во ВКонтакте"
              >
                <Users className="h-4 w-4" />
              </a>
              <button
                onClick={async () => {
                  try {
                    await navigator.clipboard.writeText(`https://fedin-ii.ru/blog/${meta.id}`)
                  } catch {
                    /* noop */
                  }
                  setCopiedLink(true)
                  setTimeout(() => setCopiedLink(false), 2000)
                }}
                className="flex h-10 items-center gap-2 rounded-xl glass-light px-4 text-[13px] text-[#9AA6BC] transition-colors hover:text-[#22D3EE]"
              >
                {copiedLink ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                {copiedLink ? 'Скопировано' : 'Копировать ссылку'}
              </button>
            </div>

            {/* Читать ещё */}
            <div className="mt-14">
              <h3 className="font-display text-2xl font-bold">Читать ещё</h3>
              <div className="mt-6 grid gap-6 sm:grid-cols-2">
                {more.map((a) => (
                  <Link
                    key={a.id}
                    to={`/blog/${a.id}`}
                    className="group overflow-hidden rounded-[20px] glass transition-shadow hover:shadow-[0_8px_40px_rgba(124,92,255,0.25)]"
                  >
                    <div className="overflow-hidden">
                      <img
                        src={a.cover}
                        alt={a.title}
                        loading="lazy"
                        className="aspect-video w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
                      />
                    </div>
                    <div className="p-5">
                      <span className="chip glass-light text-[#22D3EE]">{a.category}</span>
                      <h4 className="mt-3 font-display text-[15px] font-bold leading-snug">
                        {a.title}
                      </h4>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            {/* CTA */}
            <div className="gradient-border relative mt-14 overflow-hidden rounded-[24px] p-8 text-center md:p-10">
              <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 glow-cyan animate-drift" />
              <h3 className="relative font-display text-2xl font-bold">
                Попробуйте на практике — <span className="text-gradient">бесплатно</span>
              </h3>
              <p className="relative mx-auto mt-3 max-w-md text-[15px] text-[#9AA6BC]">
                Интенсив «Нейросети за 3 дня»: первый результат уже в первый вечер. 0 ₽.
              </p>
              <Link to="/intensive" className="btn-primary relative mt-6">
                Забрать интенсив
              </Link>
            </div>
          </article>

          {/* Оглавление */}
          <aside className="hidden lg:block">
            <div className="sticky top-24">
              <div className="text-[12px] font-semibold uppercase tracking-wider text-[#5C6B84]">
                Содержание
              </div>
              <nav className="mt-4 space-y-1 border-l border-white/[0.08]">
                {body.sections.map((s) => (
                  <a
                    key={s.id}
                    href={`#${s.id}`}
                    onClick={(e) => {
                      e.preventDefault()
                      document.getElementById(s.id)?.scrollIntoView({ behavior: 'smooth' })
                    }}
                    className={cn(
                      '-ml-px block border-l-2 py-2 pl-4 text-[13.5px] transition-all',
                      active === s.id
                        ? 'border-[#7C5CFF] font-medium text-[#F2F5FA]'
                        : 'border-transparent text-[#5C6B84] hover:text-[#9AA6BC]'
                    )}
                  >
                    {s.heading}
                  </a>
                ))}
              </nav>
            </div>
          </aside>
        </div>
      </div>
    </div>
  )
}
