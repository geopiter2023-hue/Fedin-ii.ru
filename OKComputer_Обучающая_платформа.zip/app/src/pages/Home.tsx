import { Suspense, lazy, useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  motion,
  useInView,
  useMotionValue,
  useSpring,
  useTransform,
  animate,
} from 'framer-motion'
import {
  ArrowRight,
  Play,
  Star,
  Flame,
  Zap,
  Award,
  Trophy,
  Target,
  Medal,
  CheckCircle2,
} from 'lucide-react'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import FunnelSection from '@/components/FunnelSection'

const NeuralCanvas = lazy(() => import('@/components/NeuralCanvas'))

const EASE: [number, number, number, number] = [0.16, 1, 0.3, 1]

/* ---------- helpers ---------- */

function CountUp({ to, suffix = '', decimals = 0, duration = 1.2 }: { to: number; suffix?: string; decimals?: number; duration?: number }) {
  const ref = useRef<HTMLSpanElement>(null)
  const inView = useInView(ref, { once: true, margin: '-40px' })
  useEffect(() => {
    if (!inView || !ref.current) return
    const controls = animate(0, to, {
      duration,
      ease: 'easeOut',
      onUpdate: (v) => {
        if (ref.current)
          ref.current.textContent =
            v.toLocaleString('ru-RU', { maximumFractionDigits: decimals, minimumFractionDigits: decimals }) + suffix
      },
    })
    return () => controls.stop()
  }, [inView, to, suffix, decimals, duration])
  return <span ref={ref}>0{suffix}</span>
}

function SplitWords({ text, className, delay = 0 }: { text: string; className?: string; delay?: number }) {
  const words = text.split(' ')
  return (
    <span className={className}>
      {words.map((w, i) => (
        <span key={i} className="inline-block overflow-hidden pb-1 align-bottom">
          <motion.span
            className="inline-block"
            initial={{ y: '110%' }}
            animate={{ y: 0 }}
            transition={{ delay: delay + i * 0.06, duration: 0.9, ease: EASE }}
          >
            {w}
            {i < words.length - 1 ? ' ' : ''}
          </motion.span>
        </span>
      ))}
    </span>
  )
}

const rise = {
  hidden: { opacity: 0, y: 24 },
  show: (d: number = 0) => ({ opacity: 1, y: 0, transition: { delay: d, duration: 0.7, ease: EASE } }),
}

/* ---------- 1. Hero ---------- */

function TiltCard() {
  const x = useMotionValue(0)
  const y = useMotionValue(0)
  const rx = useSpring(useTransform(y, [-0.5, 0.5], [6, -6]), { stiffness: 120, damping: 16 })
  const ry = useSpring(useTransform(x, [-0.5, 0.5], [-6, 6]), { stiffness: 120, damping: 16 })
  return (
    <motion.div
      style={{ rotateX: rx, rotateY: ry, transformPerspective: 900 }}
      onMouseMove={(e) => {
        const r = e.currentTarget.getBoundingClientRect()
        x.set((e.clientX - r.left) / r.width - 0.5)
        y.set((e.clientY - r.top) / r.height - 0.5)
      }}
      onMouseLeave={() => {
        x.set(0)
        y.set(0)
      }}
      className="glass relative overflow-hidden rounded-[20px] shadow-[0_8px_40px_rgba(0,0,0,0.45)]"
    >
      <div className="relative aspect-video">
        <img src="/ai-twin.png" alt="AI-двойник Федина" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#07090F]/80 via-transparent to-transparent" />
        <button
          className="absolute left-1/2 top-1/2 flex h-16 w-16 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-brand-gradient text-white shadow-[0_0_32px_rgba(124,92,255,0.5)] transition-transform hover:scale-110"
          aria-label="Смотреть видео"
        >
          <Play className="ml-1 h-6 w-6 fill-current" />
        </button>
        <div className="absolute bottom-4 left-4 right-4 flex items-center gap-2">
          <span className="chip bg-ai-gradient text-white">
            <span className="h-2 w-2 animate-pulse-dot rounded-full bg-white" />
            ИИ-двойник онлайн
          </span>
        </div>
      </div>
      <p className="px-5 py-4 text-sm text-[#9AA6BC]">
        Знакомьтесь: <span className="text-[#F2F5FA]">AI-двойник Федина</span> ведёт уроки и отвечает в чате 24/7
      </p>
    </motion.div>
  )
}

function Hero() {
  const [isMobile, setIsMobile] = useState(false)
  useEffect(() => {
    const mq = window.matchMedia('(max-width: 768px)')
    setIsMobile(mq.matches)
    const fn = (e: MediaQueryListEvent) => setIsMobile(e.matches)
    mq.addEventListener('change', fn)
    return () => mq.removeEventListener('change', fn)
  }, [])

  return (
    <section className="relative -mt-[72px] flex min-h-[100dvh] items-center overflow-hidden pt-[72px]">
      {isMobile ? (
        <>
          <img src="/hero-neuron.png" alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" />
          <div className="absolute right-0 top-1/4 h-[500px] w-[500px] glow-violet animate-drift" />
          <div className="absolute bottom-0 left-0 h-[400px] w-[400px] glow-cyan" />
        </>
      ) : (
        <Suspense fallback={<div className="absolute inset-0 bg-[#07090F]" />}>
          <NeuralCanvas />
        </Suspense>
      )}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-[#07090F]/40 via-transparent to-[#07090F]" />

      <div className="relative z-10 mx-auto grid w-full max-w-[1280px] items-center gap-14 px-6 py-20 lg:grid-cols-[55fr_45fr]">
        <div>
          <motion.span
            variants={rise}
            initial="hidden"
            animate="show"
            className="chip glass-light text-[#E879F9]"
          >
            <span className="h-2 w-2 animate-pulse-dot rounded-full bg-[#E879F9]" />
            Новый поток — старт каждый понедельник
          </motion.span>

          <h1 className="mt-7 font-display text-[36px] font-extrabold leading-[1.08] md:text-[56px] xl:text-[64px]">
            <SplitWords text="Нейросети —" delay={0.1} />
            <br />
            <span className="text-gradient">
              <SplitWords text="просто, практично, по-русски" delay={0.3} />
            </span>
          </h1>

          <motion.p
            variants={rise}
            initial="hidden"
            animate="show"
            custom={0.5}
            className="mt-6 max-w-xl text-[17px] text-[#9AA6BC] md:text-xl"
          >
            Освойте ChatGPT, GigaChat, Midjourney и 20+ нейросетей без VPN. Практика с первого урока: тексты, таблицы, видео, автоматизация и свой ИИ-продукт.
          </motion.p>

          <motion.div
            variants={rise}
            initial="hidden"
            animate="show"
            custom={0.7}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <Link to="/intensive" className="btn-primary">
              Начать бесплатно — интенсив 3 дня
            </Link>
            <Link to="/courses" className="btn-ghost">
              Смотреть курсы <ArrowRight className="h-4 w-4" />
            </Link>
          </motion.div>

          <motion.p
            variants={rise}
            initial="hidden"
            animate="show"
            custom={0.9}
            className="mt-7 text-[13px] text-[#5C6B84]"
          >
            32% россиян уже используют ИИ в работе — будьте впереди · Оплата картой и СБП · Рассрочка от 1 658 ₽/мес
          </motion.p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 32 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8, ease: EASE }}
        >
          <TiltCard />
          <div className="mt-5 grid grid-cols-3 gap-3">
            {[
              { v: <CountUp to={5200} suffix="+" />, l: 'учеников' },
              { v: <CountUp to={4.9} decimals={1} />, l: '★ средняя оценка' },
              { v: <CountUp to={5} />, l: 'курсов + Нейроклуб' },
            ].map((s, i) => (
              <div key={i} className="glass rounded-2xl px-4 py-3.5 text-center">
                <div className="font-display text-xl font-bold text-gradient">{s.v}</div>
                <div className="mt-1 text-[12px] text-[#5C6B84]">{s.l}</div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}

/* ---------- 2. Tools marquee ---------- */

const TOOLS = ['GigaChat', 'YandexGPT', 'DeepSeek', 'ChatGPT', 'Midjourney', 'Kling', 'Veo', 'HeyGen', 'Suno', 'Nano Banana', 'Cursor', 'Lovable', 'n8n']

function MarqueeRow({ reverse = false }: { reverse?: boolean }) {
  const items = [...TOOLS, ...TOOLS]
  return (
    <div className="flex overflow-hidden">
      <div className={`flex shrink-0 gap-4 pr-4 ${reverse ? 'animate-marquee-rev' : 'animate-marquee'}`}>
        {items.map((t, i) => (
          <span
            key={i}
            className="chip glass-light whitespace-nowrap font-mono2 text-[#5C6B84] transition-colors hover:text-[#22D3EE]"
          >
            {t}
          </span>
        ))}
      </div>
    </div>
  )
}

function ToolsMarquee() {
  return (
    <section className="border-y border-white/[0.06] bg-[#0D1117]/60 py-10">
      <p className="mb-7 text-center text-sm text-[#5C6B84]">
        Работаем на российском стеке — без VPN и зарубежных карт
      </p>
      <div className="marquee-paused space-y-4">
        <MarqueeRow />
        <MarqueeRow reverse />
      </div>
    </section>
  )
}

/* ---------- 3. Problem -> Solution ---------- */

const PAINS = [
  'Собираете промпты по чатам, а системы нет',
  'Зарубежные сервисы не оплатить и не открыть',
  'Учитесь одни — бросаете на 3-й день',
]
const SOLUTIONS = [
  'Пошаговая практика: от промпта до результата',
  'Российский стек: GigaChat, YandexGPT, DeepSeek',
  'Куратор, комьюнити и геймификация — XP за каждый урок',
]

function ProblemSolution() {
  const arrowRef = useRef<SVGPathElement>(null)
  const inView = useInView(arrowRef, { once: true, margin: '-100px' })
  return (
    <section className="mx-auto max-w-[1280px] px-6 py-24 md:py-32">
      <motion.h2
        variants={rise}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, margin: '-80px' }}
        className="text-center font-display text-3xl font-bold md:text-[44px]"
      >
        Бесплатных видео много. <span className="text-gradient">Толку — мало.</span>
      </motion.h2>

      <div className="mt-14 grid items-center gap-6 lg:grid-cols-[1fr_80px_1fr]">
        <div className="space-y-4">
          {PAINS.map((p, i) => (
            <motion.div
              key={p}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-25%' }}
              transition={{ delay: i * 0.1, duration: 0.6, ease: EASE }}
              className="glass rounded-[20px] p-6 text-[#9AA6BC]"
            >
              {p}
            </motion.div>
          ))}
        </div>
        <svg viewBox="0 0 80 60" className="mx-auto hidden rotate-0 lg:block" fill="none">
          <path
            ref={arrowRef}
            d="M5 30 H65 M50 15 L68 30 L50 45"
            stroke="url(#ag)"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray="120"
            strokeDashoffset={inView ? 0 : 120}
            style={{ transition: 'stroke-dashoffset 0.6s ease-out' }}
          />
          <defs>
            <linearGradient id="ag" x1="0" y1="0" x2="80" y2="0">
              <stop stopColor="#7C5CFF" />
              <stop offset="1" stopColor="#22D3EE" />
            </linearGradient>
          </defs>
        </svg>
        <div className="space-y-4">
          {SOLUTIONS.map((s, i) => (
            <motion.div
              key={s}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-25%' }}
              transition={{ delay: 0.15 + i * 0.1, duration: 0.6, ease: EASE }}
              className="gradient-border flex items-start gap-3 rounded-[20px] p-6"
            >
              <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-[#22D3EE]" />
              <span>{s}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

/* ---------- 5. Courses ---------- */

const COURSES = [
  {
    slug: 'neuro-work',
    img: '/course-work.png',
    badge: 'Бестселлер',
    badgeCls: 'bg-brand-gradient text-white',
    title: 'Нейросети для работы и продуктивности',
    meta: '6 модулей · 42 урока · онлайн',
    price: '14 900 ₽',
    old: '24 900 ₽',
    per: 'или от 1 658 ₽/мес в рассрочку',
    wide: true,
  },
  {
    slug: 'neuro-content',
    img: '/course-content.png',
    badge: '',
    title: 'Нейросети для контента: Reels, видео, визуал',
    meta: '5 модулей · 38 уроков · онлайн',
    price: '14 900 ₽',
    old: '19 900 ₽',
    per: 'или от 1 658 ₽/мес в рассрочку',
  },
  {
    slug: 'neuro-marketing',
    img: '/course-marketing.png',
    badge: 'PRO',
    badgeCls: 'bg-ai-gradient text-white',
    title: 'Нейросети для маркетинга, SMM и ИИ-агентов',
    meta: '8–10 недель · 56 уроков · с куратором',
    price: 'от 25 000 ₽',
    old: '',
    per: 'или от 2 780 ₽/мес в рассрочку',
  },
  {
    slug: 'vibe-coding',
    img: '/course-vibe.png',
    badge: 'Новый',
    badgeCls: 'bg-[#22D3EE] text-[#07090F]',
    title: 'Вайб-кодинг: свой продукт без программистов',
    meta: '6 недель · 44 урока · с куратором',
    price: 'от 35 000 ₽',
    old: '',
    per: 'или от 3 890 ₽/мес в рассрочку',
  },
  {
    slug: 'marketplace-cards',
    img: '/course-marketplace.png',
    badge: 'Для селлеров WB/Ozon',
    badgeCls: 'glass-light text-[#E879F9]',
    title: 'ИИ-карточки для маркетплейсов',
    meta: '4 модуля · 26 уроков · онлайн',
    price: '14 900 ₽',
    old: '19 900 ₽',
    per: 'или от 1 658 ₽/мес в рассрочку',
  },
]

function Courses() {
  return (
    <section className="mx-auto max-w-[1280px] px-6 py-24 md:py-32">
      <div className="flex flex-wrap items-end justify-between gap-6">
        <h2 className="font-display text-3xl font-bold md:text-[44px]">
          Курсы, которые <span className="text-gradient">платят за себя</span>
        </h2>
        <Link to="/courses" className="group inline-flex items-center gap-1.5 font-semibold text-[#22D3EE]">
          Все курсы
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
        </Link>
      </div>

      <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {COURSES.map((c, i) => (
          <motion.div
            key={c.slug}
            initial={{ opacity: 0, y: 32 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-20%' }}
            transition={{ delay: i * 0.09, duration: 0.6, ease: EASE }}
            whileHover={{ y: -6 }}
            className={`group glass flex flex-col overflow-hidden rounded-[20px] transition-shadow hover:shadow-[0_0_32px_rgba(124,92,255,0.25)] ${c.wide ? 'md:col-span-2' : ''}`}
          >
            <div className={`relative overflow-hidden ${c.wide ? 'aspect-[2/1]' : 'aspect-video'}`}>
              <img
                src={c.img}
                alt={c.title}
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              {c.badge && (
                <span className={`chip absolute left-4 top-4 ${c.badgeCls ?? 'glass-light text-white'}`}>{c.badge}</span>
              )}
            </div>
            <div className="flex flex-1 flex-col p-6">
              <h3 className="font-display text-lg font-bold leading-snug">{c.title}</h3>
              <p className="mt-2 text-[13px] text-[#5C6B84]">{c.meta}</p>
              <div className="mt-4 flex items-baseline gap-3">
                <span className="font-display text-xl font-bold">{c.price}</span>
                {c.old && <span className="text-sm text-[#5C6B84] line-through">{c.old}</span>}
              </div>
              <p className="mt-1 text-[12px] text-[#5C6B84]">{c.per}</p>
              <Link to={`/courses/${c.slug}`} className="btn-ghost mt-5 w-full py-3 text-sm">
                Подробнее
              </Link>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  )
}

/* ---------- 6. Shop preview ---------- */

const PRODUCTS = [
  { img: '/pack-prompts.png', title: 'Промпт-паки по профессиям', price: '490–990 ₽', old: '' },
  { img: '/pack-wb.png', title: '100 промптов для карточек WB/Ozon', price: '990 ₽', old: '1 990 ₽' },
  { img: '/pack-guide.png', title: 'Гайд «Оплата зарубежных ИИ»', price: '299 ₽', old: '' },
  { img: '/pack-n8n.png', title: 'n8n-связки: готовые автоматизации', price: '2 990–6 890 ₽', old: '' },
  { img: '/pack-presets.png', title: 'Пресеты Midjourney / Nano Banana', price: '1 490 ₽', old: '2 490 ₽' },
]

function ShopPreview() {
  const dragRef = useRef<HTMLDivElement>(null)
  const [width, setWidth] = useState(0)
  useEffect(() => {
    const el = dragRef.current
    if (el) setWidth(el.scrollWidth - el.offsetWidth)
  }, [])
  return (
    <section className="bg-[#0D1117] py-24 md:py-32">
      <div className="mx-auto max-w-[1280px] px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <h2 className="font-display text-3xl font-bold md:text-[44px]">
            Начните с <span className="text-gradient">990 ₽</span>
          </h2>
          <Link to="/shop" className="group inline-flex items-center gap-1.5 font-semibold text-[#22D3EE]">
            В магазин
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>
      </div>
      <div ref={dragRef} className="mt-12 overflow-hidden">
        <motion.div
          drag="x"
          dragConstraints={{ left: -width, right: 0 }}
          className="flex cursor-grab gap-6 px-6 active:cursor-grabbing lg:px-[max(24px,calc((100vw-1280px)/2+24px))]"
        >
          {PRODUCTS.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.5, ease: EASE }}
              whileHover={{ rotate: 1.5, scale: 1.02 }}
              className="glass w-[240px] shrink-0 overflow-hidden rounded-[20px] hover:shadow-[0_0_32px_rgba(124,92,255,0.3)]"
            >
              <div className="aspect-[4/5] overflow-hidden">
                <img src={p.img} alt={p.title} className="h-full w-full object-cover" draggable={false} />
              </div>
              <div className="p-5">
                <h3 className="text-[15px] font-semibold leading-snug">{p.title}</h3>
                <div className="mt-3 flex items-baseline gap-2">
                  <span className="font-display text-lg font-bold">{p.price}</span>
                  {p.old && <span className="text-sm text-[#F87171] line-through">{p.old}</span>}
                </div>
                <Link to="/shop" className="btn-primary mt-4 w-full py-2.5 text-sm">
                  Купить
                </Link>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

/* ---------- 7. Expert & AI twin ---------- */

function Expert() {
  const ref = useRef<HTMLDivElement>(null)
  const y = useMotionValue(0)
  useEffect(() => {
    const onScroll = () => {
      if (!ref.current) return
      const r = ref.current.getBoundingClientRect()
      const p = Math.min(Math.max(1 - r.top / window.innerHeight, 0), 1)
      y.set((p - 0.5) * 60)
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [y])

  return (
    <section ref={ref} className="relative mx-auto max-w-[1280px] overflow-visible px-6 py-24 md:py-32">
      <div className="pointer-events-none absolute -right-40 top-0 h-[600px] w-[600px] glow-cyan" />
      <div className="grid items-center gap-14 lg:grid-cols-2">
        <div className="relative">
          <motion.div style={{ y }} className="gradient-border overflow-hidden rounded-[24px] p-1.5">
            <img src="/expert-portrait.png" alt="Основатель FEDIN AI" className="w-full rounded-[18px] object-cover" />
          </motion.div>
          <div className="glass absolute -bottom-8 -right-2 w-44 animate-float rounded-[20px] p-3 shadow-[0_0_32px_rgba(232,121,249,0.25)] md:-right-8">
            <img src="/ai-twin.png" alt="AI-двойник" className="aspect-square w-full rounded-xl object-cover" />
            <span className="chip mt-3 w-full justify-center bg-ai-gradient text-[12px] text-white">
              <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-white" />
              ИИ-двойник онлайн
            </span>
          </div>
        </div>
        <div>
          {[
            <h2 key="h" className="font-display text-3xl font-bold md:text-[40px] md:leading-[1.12]">
              Учитесь у эксперта. <span className="text-gradient">И его цифрового двойника.</span>
            </h2>,
            <p key="p1" className="mt-6 text-[#9AA6BC]">
              Федин — основатель FEDIN AI, практик с 2019 года. Внедрил нейросети в десятки бизнесов и обучил более 5 000 учеников по всей России.
            </p>,
            <p key="p2" className="mt-4 text-[#9AA6BC]">
              Его AI-двойник ведёт уроки, отвечает в чате 24/7 и разбирает домашние задания — вы никогда не останетесь один на один с материалом.
            </p>,
            <p key="p3" className="mt-4 text-[#9AA6BC]">
              Философия платформы — практика, а не компиляция бесплатного: каждый урок заканчивается готовым результатом для вашей работы.
            </p>,
          ].map((el, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ delay: i * 0.12, duration: 0.6, ease: EASE }}
            >
              {el}
            </motion.div>
          ))}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="mt-8 flex flex-wrap gap-3"
          >
            {['5 200+ учеников', '120+ живых разборов', '24/7 ИИ-куратор'].map((c) => (
              <span key={c} className="chip glass-light text-[#22D3EE]">{c}</span>
            ))}
          </motion.div>
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.6 }}
          >
            <Link to="/about" className="btn-ghost mt-8">
              Подробнее об эксперте <ArrowRight className="h-4 w-4" />
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

/* ---------- 8. Gamification ---------- */

const ACHIEVEMENTS = [
  { icon: Zap, name: 'Первый промпт' },
  { icon: Flame, name: 'Стрик 7 дней' },
  { icon: Target, name: 'Модуль закрыт' },
  { icon: Medal, name: 'Топ недели' },
]

function Gamification() {
  const barRef = useRef<HTMLDivElement>(null)
  const inView = useInView(barRef, { once: true, margin: '-80px' })
  return (
    <section className="bg-[#0D1117] py-24 md:py-32">
      <div className="mx-auto grid max-w-[1280px] items-center gap-14 px-6 lg:grid-cols-2">
        <motion.div
          variants={rise}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: '-80px' }}
        >
          <h2 className="font-display text-3xl font-bold md:text-[40px]">
            Учёба, в которую <span className="text-gradient">играют</span>
          </h2>
          <ul className="mt-8 space-y-4">
            {[
              'XP за каждый урок и практическое задание',
              'Уровни и ранги — от новичка до нейромастера',
              'Стрик дней: не теряйте темп',
              'Достижения и сертификаты за прогресс',
            ].map((b) => (
              <li key={b} className="flex items-start gap-3 text-[#9AA6BC]">
                <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-[#34D399]" />
                {b}
              </li>
            ))}
          </ul>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.7, ease: EASE }}
          className="glass rounded-[24px] p-7"
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[13px] text-[#5C6B84]">Уровень 7</div>
              <div className="font-display text-xl font-bold">Нейропрактик</div>
            </div>
            <span className="chip bg-brand-gradient text-white">
              <Zap className="h-3.5 w-3.5" />
              <CountUp to={3450} /> XP
            </span>
          </div>
          <div ref={barRef} className="mt-5">
            <div className="h-3 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-brand-gradient transition-[width] duration-1000 ease-out"
                style={{ width: inView ? '69%' : '0%' }}
              />
            </div>
            <div className="mt-2 flex justify-between text-[12px] text-[#5C6B84]">
              <span>3 450 / 5 000 XP</span>
              <span>до уровня 8</span>
            </div>
          </div>
          <div className="mt-6 flex items-center gap-3">
            <span className="chip glass-light text-[#FBBF24]">
              <Flame className="h-4 w-4" /> 12 дней стрик
            </span>
            <span className="chip glass-light text-[#34D399]">
              <Award className="h-4 w-4" /> 3 сертификата
            </span>
          </div>
          <div className="mt-7 grid grid-cols-4 gap-3">
            {ACHIEVEMENTS.map((a, i) => (
              <motion.div
                key={a.name}
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 + i * 0.12, type: 'spring', stiffness: 260, damping: 16 }}
                className="flex flex-col items-center gap-2 rounded-2xl glass-light p-3 text-center"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-full bg-brand-gradient">
                  <a.icon className="h-5 w-5 text-white" />
                </div>
                <span className="text-[11px] leading-tight text-[#9AA6BC]">{a.name}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}

/* ---------- 9. Reviews ---------- */

const REVIEWS = [
  { img: '/review-1.jpg', name: 'Анна К.', role: 'Маркетолог', course: 'Нейросети для работы', text: 'За месяц автоматизировала отчёты и рассылки. Экономлю минимум 8 часов в неделю — курс окупился дважды.' },
  { img: '/review-2.jpg', name: 'Дмитрий С.', role: 'Селлер WB', course: 'ИИ-карточки для маркетплейсов', text: 'Карточки делаю за вечер вместо недели с дизайнером. CTR вырос на 34%, заказы пошли вверх.' },
  { img: '/review-3.jpg', name: 'Ольга М.', role: 'HR-директор', course: 'Нейросети для работы', text: 'Скрининг резюме и письма кандидатам — теперь за минуты. ИИ-куратор отвечал даже ночью перед дедлайном.' },
  { img: '/review-4.jpg', name: 'Игорь В.', role: 'Риелтор', course: 'Промпт-пак + интенсив', text: 'Начал с бесплатного интенсива, взял промпт-пак для риелторов. Объявления пишутся сами, я только проверяю.' },
  { img: '/review-5.jpg', name: 'Максим П.', role: 'Предприниматель', course: 'Вайб-кодинг', text: 'Без программистов собрал MVP своего сервиса за 6 недель. Не верил, что такое возможно.' },
  { img: '/review-6.jpg', name: 'Елена Т.', role: 'Преподаватель', course: 'Нейросети для контента', text: 'Готовлю уроки и визуал в 3 раза быстрее. Ученики в восторге от материалов, а я — от свободных вечеров.' },
]

function Stars({ delayBase }: { delayBase: number }) {
  return (
    <div className="flex gap-0.5">
      {[0, 1, 2, 3, 4].map((s) => (
        <motion.span
          key={s}
          initial={{ opacity: 0.15, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: delayBase + s * 0.05 }}
        >
          <Star className="h-4 w-4 fill-[#FBBF24] text-[#FBBF24]" />
        </motion.span>
      ))}
    </div>
  )
}

function Reviews() {
  return (
    <section className="mx-auto max-w-[1280px] px-6 py-24 md:py-32">
      <div className="text-center">
        <h2 className="font-display text-3xl font-bold md:text-[44px]">
          <span className="text-gradient"><CountUp to={5200} suffix="+" /></span> учеников уже применяют нейросети
        </h2>
        <div className="mt-4 inline-flex items-center gap-2 text-[#9AA6BC]">
          <Stars delayBase={0.2} />
          <span className="font-display font-bold text-[#F2F5FA]">4,9</span> из 5 — средняя оценка курсов
        </div>
      </div>
      <div className="mt-12 columns-1 gap-6 md:columns-2 lg:columns-3 [&>*]:mb-6">
        {REVIEWS.map((r, i) => (
          <motion.div
            key={r.name}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-10%' }}
            transition={{ delay: (i % 3) * 0.08, duration: 0.55, ease: EASE }}
            whileHover={{ y: -4 }}
            className="glass break-inside-avoid rounded-[20px] p-6"
          >
            <div className="flex items-center gap-3">
              <img src={r.img} alt={r.name} className="h-11 w-11 rounded-full object-cover" />
              <div>
                <div className="font-semibold">{r.name}</div>
                <div className="text-[12px] text-[#5C6B84]">{r.role}</div>
              </div>
            </div>
            <div className="mt-4">
              <Stars delayBase={0.3 + i * 0.05} />
            </div>
            <p className="mt-3 text-[15px] text-[#9AA6BC]">{r.text}</p>
            <span className="chip mt-4 glass-light text-[12px] text-[#22D3EE]">{r.course}</span>
          </motion.div>
        ))}
      </div>
    </section>
  )
}

/* ---------- 10. Neuroclub ---------- */

function Club() {
  return (
    <section className="mx-auto max-w-[1280px] px-6 pb-24 md:pb-32">
      <motion.div
        initial={{ opacity: 0, y: 32 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-80px' }}
        transition={{ duration: 0.7, ease: EASE }}
        className="gradient-border relative overflow-hidden rounded-[28px] p-8 md:p-14"
      >
        <div className="pointer-events-none absolute -left-24 -top-24 h-[420px] w-[420px] glow-violet animate-drift" />
        <div className="pointer-events-none absolute -bottom-24 -right-24 h-[420px] w-[420px] glow-cyan animate-drift" style={{ animationDelay: '-7s' }} />
        <div className="relative grid items-center gap-10 lg:grid-cols-[1.4fr_1fr]">
          <div>
            <h2 className="font-display text-3xl font-bold md:text-[40px]">
              Нейроклуб — <span className="text-gradient">990 ₽/мес</span>
            </h2>
            <ul className="mt-7 space-y-3.5">
              {[
                'Обновления всех курсов платформы',
                'Новый промпт-пак каждый месяц',
                'Закрытое комьюнити и живые разборы',
                'Скидки на магазин цифровых инструментов',
              ].map((b) => (
                <li key={b} className="flex items-start gap-3 text-[#9AA6BC]">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-[#22D3EE]" />
                  {b}
                </li>
              ))}
            </ul>
          </div>
          <div className="text-center lg:text-right">
            <div className="font-display text-5xl font-extrabold text-gradient md:text-6xl">990 ₽</div>
            <div className="mt-1 text-sm text-[#5C6B84]">в месяц</div>
            <Link to="/club" className="btn-primary mt-6 w-full lg:w-auto">
              Вступить в Нейроклуб
            </Link>
            <div className="mt-3 text-[12px] text-[#5C6B84]">Отмена в один клик</div>
          </div>
        </div>
      </motion.div>
    </section>
  )
}

/* ---------- 11. FAQ ---------- */

const FAQ = [
  { q: 'Подойдёт ли мне, я новичок?', a: 'Да. Программы построены от простого к сложному: бесплатный интенсив даёт первый результат за вечер, даже если вы никогда не открывали нейросети. Никакого программирования не требуется.' },
  { q: 'Нужен ли VPN и зарубежная карта?', a: 'Нет. Мы работаем на российском стеке — GigaChat, YandexGPT, DeepSeek и другие сервисы доступны из России без VPN. Для зарубежных инструментов есть гайд по легальной оплате за 299 ₽.' },
  { q: 'Как оплатить? Есть ли рассрочка?', a: 'Принимаем карты МИР, Visa, Mastercard и СБП. Доступна рассрочка от 1 658 ₽/мес на 12 месяцев — оформляется онлайн за пару минут.' },
  { q: 'Выдаёте ли сертификат?', a: 'Да, после прохождения курса вы получаете именной сертификат с уникальным номером и публичной страницей проверки — его можно приложить к резюме или показать работодателю.' },
  { q: 'Что такое AI-двойник?', a: 'Это цифровая копия Федина, обученная на его материалах и разборах. Она ведёт уроки, отвечает на вопросы в чате 24/7 и проверяет домашние задания с развёрнутой обратной связью.' },
  { q: 'Можно ли вернуть деньги?', a: 'Да, в течение 7 дней после покупки курса — полный возврат без вопросов, если вы прошли меньше 20% материалов. Подписку на Нейроклуб можно отменить в один клик в любой момент.' },
  { q: 'Как работает Нейроклуб?', a: 'Подписка за 990 ₽/мес открывает обновления всех курсов, новый промпт-пак каждый месяц, закрытое комьюнити и участие в живых разборах. Отмена — в один клик в личном кабинете.' },
]

function Faq() {
  return (
    <section className="bg-[#0D1117] py-24 md:py-32">
      <div className="mx-auto max-w-[840px] px-6">
        <motion.h2
          variants={rise}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="text-center font-display text-3xl font-bold md:text-[44px]"
        >
          Частые <span className="text-gradient">вопросы</span>
        </motion.h2>
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="mt-12"
        >
          <Accordion type="single" collapsible className="space-y-3">
            {FAQ.map((f, i) => (
              <AccordionItem
                key={i}
                value={`item-${i}`}
                className="glass rounded-2xl border-white/[0.08] px-6 data-[state=open]:border-[#7C5CFF]/40"
              >
                <AccordionTrigger className="py-5 text-left text-[15px] font-semibold hover:no-underline [&>svg]:text-[#22D3EE]">
                  {f.q}
                </AccordionTrigger>
                <AccordionContent className="pb-5 text-[14px] leading-relaxed text-[#9AA6BC]">
                  {f.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  )
}

/* ---------- 12. Final CTA ---------- */

function MagneticButton({ children }: { children: React.ReactNode }) {
  const ref = useRef<HTMLButtonElement>(null)
  const x = useSpring(useMotionValue(0), { stiffness: 200, damping: 15 })
  const y = useSpring(useMotionValue(0), { stiffness: 200, damping: 15 })
  return (
    <motion.button
      ref={ref}
      style={{ x, y }}
      onMouseMove={(e) => {
        const r = ref.current!.getBoundingClientRect()
        const dx = e.clientX - (r.left + r.width / 2)
        const dy = e.clientY - (r.top + r.height / 2)
        if (Math.hypot(dx, dy) < 140) {
          x.set(dx * 0.25)
          y.set(dy * 0.25)
        }
      }}
      onMouseLeave={() => {
        x.set(0)
        y.set(0)
      }}
      className="btn-primary w-full sm:w-auto"
      type="submit"
    >
      {children}
    </motion.button>
  )
}

function FinalCta() {
  const [sent, setSent] = useState(false)
  return (
    <section className="relative overflow-hidden py-28 md:py-36">
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-[700px] w-[700px] -translate-x-1/2 -translate-y-1/2 glow-violet animate-drift" />
      <div className="pointer-events-none absolute left-1/4 top-0 h-[400px] w-[400px] glow-cyan animate-drift" style={{ animationDelay: '-6s' }} />
      <div className="relative mx-auto max-w-[760px] px-6 text-center">
        <h2 className="font-display text-4xl font-extrabold md:text-[56px] md:leading-[1.08]">
          <motion.span
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: EASE }}
          >
            Начните <span className="text-gradient">бесплатно</span>. Сегодня.
          </motion.span>
        </h2>
        <motion.p
          variants={rise}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          custom={0.2}
          className="mt-5 text-lg text-[#9AA6BC]"
        >
          3-дневный интенсив «Нейросети за 3 дня» — первый результат уже в первый вечер
        </motion.p>
        {sent ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass mx-auto mt-9 flex max-w-md items-center justify-center gap-3 rounded-2xl p-5 text-[#34D399]"
          >
            <Trophy className="h-5 w-5" />
            Готово! Проверьте почту — интенсив уже ждёт вас.
          </motion.div>
        ) : (
          <motion.form
            variants={rise}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
            custom={0.35}
            onSubmit={(e) => {
              e.preventDefault()
              setSent(true)
            }}
            className="mx-auto mt-9 flex max-w-xl flex-col gap-3 sm:flex-row"
          >
            <input
              type="email"
              required
              placeholder="Ваш email"
              className="h-[52px] flex-1 rounded-xl border border-white/[0.08] bg-[#0D1117] px-5 text-[15px] outline-none transition-all placeholder:text-[#5C6B84] focus:border-[#7C5CFF] focus:shadow-[0_0_24px_rgba(124,92,255,0.25)]"
            />
            <MagneticButton>Забрать интенсив — 0 ₽</MagneticButton>
          </motion.form>
        )}
        <p className="mt-4 text-[12px] text-[#5C6B84]">
          Нажимая, вы соглашаетесь с политикой конфиденциальности
        </p>
      </div>
    </section>
  )
}

/* ---------- Page ---------- */

export default function Home() {
  return (
    <>
      <Hero />
      <ToolsMarquee />
      <ProblemSolution />
      <FunnelSection />
      <Courses />
      <ShopPreview />
      <Expert />
      <Gamification />
      <Reviews />
      <Club />
      <Faq />
      <FinalCta />
    </>
  )
}
