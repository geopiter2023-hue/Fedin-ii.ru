import { useEffect, useMemo, useRef, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowLeft,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Copy,
  Download,
  FileText,
  Maximize,
  Pause,
  Play,
  RotateCcw,
  RotateCw,
  Send,
  X,
} from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { useAuth } from '@/hooks/useAuth'
import { cn } from '@/lib/utils'

const EASE = [0.16, 1, 0.3, 1] as [number, number, number, number]
const XP_REWARD = 200

type LessonData = {
  id: number
  title: string
  durationMin: number
  summary: string | null
  materialsJson: string | null
  promptsJson: string | null
  videoUrl: string | null
}

type ModuleData = { id: number; title: string; lessons: LessonData[] }

/* ── Конфетти на canvas ─────────────────────────────────── */
function Confetti({ fire }: { fire: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    if (!fire || !ref.current) return
    const canvas = ref.current
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    const { innerWidth: w, innerHeight: h } = window
    canvas.width = w
    canvas.height = h
    const colors = ['#7C5CFF', '#22D3EE', '#E879F9', '#34D399', '#FBBF24']
    const parts = Array.from({ length: 90 }).map(() => ({
      x: w / 2,
      y: h / 2,
      vx: (Math.random() - 0.5) * 14,
      vy: Math.random() * -12 - 4,
      size: Math.random() * 7 + 3,
      color: colors[Math.floor(Math.random() * colors.length)],
      rot: Math.random() * Math.PI,
      vr: (Math.random() - 0.5) * 0.25,
      life: 1,
    }))
    let raf = 0
    const start = performance.now()
    const tick = (t: number) => {
      const elapsed = (t - start) / 1000
      ctx.clearRect(0, 0, w, h)
      if (elapsed > 2.2) return
      for (const p of parts) {
        p.x += p.vx
        p.y += p.vy
        p.vy += 0.35
        p.rot += p.vr
        p.life = Math.max(0, 1 - elapsed / 2.2)
        ctx.save()
        ctx.translate(p.x, p.y)
        ctx.rotate(p.rot)
        ctx.globalAlpha = p.life
        ctx.fillStyle = p.color
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6)
        ctx.restore()
      }
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [fire])
  return (
    <canvas
      ref={ref}
      style={{ position: 'fixed', inset: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 90 }}
    />
  )
}

/* ── Мок-видеоплеер ─────────────────────────────────────── */
function MockPlayer({ durationMin, poster }: { durationMin: number; poster: string }) {
  const total = Math.max(durationMin * 60, 60)
  const [playing, setPlaying] = useState(false)
  const [time, setTime] = useState(0)
  const [speed, setSpeed] = useState(1)
  const [controls, setControls] = useState(true)
  const boxRef = useRef<HTMLDivElement>(null)
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    if (!playing) return
    const iv = setInterval(() => {
      setTime((t) => {
        const next = t + 0.25 * speed
        if (next >= total) {
          setPlaying(false)
          return total
        }
        return next
      })
    }, 250)
    return () => clearInterval(iv)
  }, [playing, speed, total])

  const poke = () => {
    setControls(true)
    if (hideTimer.current) clearTimeout(hideTimer.current)
    hideTimer.current = setTimeout(() => setControls(false), 3000)
  }

  const fmt = (s: number) => {
    const m = Math.floor(s / 60)
    const sec = Math.floor(s % 60)
    return `${m}:${sec.toString().padStart(2, '0')}`
  }

  const seek = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    setTime(((e.clientX - rect.left) / rect.width) * total)
  }

  return (
    <div
      ref={boxRef}
      onMouseMove={poke}
      className="gradient-border group relative aspect-video select-none overflow-hidden rounded-[20px]"
    >
      {/* «видео» — стилизованный мок-кадр */}
      <motion.img
        src={poster}
        alt="Кадр урока"
        animate={{ scale: playing ? 1 : 1.02, opacity: playing ? 0.85 : 1 }}
        transition={{ duration: 0.6 }}
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-[#07090F]/90 via-transparent to-[#07090F]/30" />
      {/* водяной знак */}
      <span className="absolute right-4 top-4 font-display text-[11px] font-bold tracking-widest text-white/40">
        FEDIN AI
      </span>

      {/* центральная кнопка */}
      {!playing && (
        <button
          onClick={() => setPlaying(true)}
          className="absolute inset-0 flex items-center justify-center"
          aria-label="Смотреть"
        >
          <span className="relative flex h-20 w-20 items-center justify-center rounded-full bg-brand-gradient shadow-[0_0_40px_rgba(124,92,255,0.6)]">
            <span className="absolute inset-0 animate-ping rounded-full bg-[#7C5CFF]/40" />
            <Play className="h-8 w-8 fill-white text-white" />
          </span>
        </button>
      )}

      {/* контролы */}
      <div
        className={cn(
          'absolute inset-x-0 bottom-0 p-4 transition-opacity duration-300',
          controls || !playing ? 'opacity-100' : 'opacity-0'
        )}
      >
        {/* прогресс */}
        <div className="group/bar relative h-1.5 w-full cursor-pointer rounded-full bg-white/15 transition-all hover:h-2.5" onClick={seek}>
          <div className="absolute inset-y-0 left-0 w-[38%] rounded-full bg-white/10" />
          <div
            className="absolute inset-y-0 left-0 rounded-full bg-brand-gradient"
            style={{ width: `${(time / total) * 100}%` }}
          />
        </div>
        <div className="mt-3 flex items-center gap-2">
          <button onClick={() => setPlaying((p) => !p)} className="rounded-lg p-2 text-white transition hover:bg-white/10" aria-label={playing ? 'Пауза' : 'Играть'}>
            {playing ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
          </button>
          <button onClick={() => setTime((t) => Math.max(0, t - 10))} className="rounded-lg p-2 text-white/80 transition hover:bg-white/10" aria-label="Назад 10 сек">
            <RotateCcw className="h-4.5 w-4.5" />
          </button>
          <button onClick={() => setTime((t) => Math.min(total, t + 10))} className="rounded-lg p-2 text-white/80 transition hover:bg-white/10" aria-label="Вперёд 10 сек">
            <RotateCw className="h-4.5 w-4.5" />
          </button>
          <span className="ml-1 font-mono2 text-[12px] text-white/70">
            {fmt(time)} / {fmt(total)}
          </span>
          <div className="flex-1" />
          <select
            value={speed}
            onChange={(e) => setSpeed(Number(e.target.value))}
            className="rounded-lg border border-white/15 bg-[#0D1117]/80 px-2 py-1 text-[12px] text-white focus:outline-none"
            aria-label="Скорость"
          >
            {[0.75, 1, 1.25, 1.5, 2].map((s) => (
              <option key={s} value={s}>
                {s}×
              </option>
            ))}
          </select>
          <button
            onClick={() => boxRef.current?.requestFullscreen?.()}
            className="rounded-lg p-2 text-white/80 transition hover:bg-white/10"
            aria-label="Во весь экран"
          >
            <Maximize className="h-4.5 w-4.5" />
          </button>
        </div>
      </div>
    </div>
  )
}

/* ── Чат с ИИ-куратором ─────────────────────────────────── */
type Msg = { role: 'user' | 'ai'; text: string }

function AiChat({ lessonId, lessonTitle, open, onClose }: { lessonId: number; lessonTitle: string; open: boolean; onClose: () => void }) {
  const ask = trpc.ai.ask.useMutation()
  const [msgs, setMsgs] = useState<Msg[]>([
    { role: 'ai', text: `Вижу, вы на уроке «${lessonTitle}». Что разобрать?` },
  ])
  const [input, setInput] = useState('')
  const endRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [msgs, ask.isPending])

  const send = (q: string) => {
    const question = q.trim()
    if (!question || ask.isPending) return
    setMsgs((m) => [...m, { role: 'user', text: question }])
    setInput('')
    ask.mutate(
      { lessonId, question },
      { onSuccess: (res) => setMsgs((m) => [...m, { role: 'ai', text: res.answer }]) }
    )
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.aside
          initial={{ x: 440, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: 440, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 260, damping: 28 }}
          className="fixed bottom-0 right-0 top-[72px] z-[70] flex w-full flex-col border-l border-white/[0.08] bg-[#0D1117]/95 backdrop-blur-xl sm:w-[400px]"
        >
          <div className="flex items-center gap-3 border-b border-white/[0.08] p-4">
            <div className="relative">
              <img src="/ai-twin.png" alt="ИИ-куратор" className="h-11 w-11 rounded-full border border-[#E879F9]/40 object-cover" />
              <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-[#0D1117] bg-[#34D399] animate-pulse-dot" />
            </div>
            <div className="flex-1">
              <div className="text-sm font-semibold">ИИ-куратор · AI-двойник Федина</div>
              <span className="chip bg-ai-gradient !px-2.5 !py-0.5 text-[11px] text-white">онлайн</span>
            </div>
            <button onClick={onClose} className="rounded-lg p-2 text-[#9AA6BC] hover:bg-white/5" aria-label="Свернуть чат">
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="flex-1 space-y-3 overflow-y-auto p-4">
            {msgs.map((m, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.25, ease: EASE }}
                className={cn(
                  'max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed',
                  m.role === 'ai'
                    ? 'border border-[#E879F9]/25 bg-white/[0.04] text-[#F2F5FA]'
                    : 'ml-auto bg-[#7C5CFF] text-white'
                )}
              >
                {m.text}
              </motion.div>
            ))}
            {ask.isPending && (
              <div className="flex w-fit items-center gap-1.5 rounded-2xl border border-[#E879F9]/25 bg-white/[0.04] px-4 py-3">
                {[0, 1, 2].map((i) => (
                  <motion.span
                    key={i}
                    animate={{ y: [0, -5, 0] }}
                    transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }}
                    className="h-1.5 w-1.5 rounded-full bg-[#E879F9]"
                  />
                ))}
              </div>
            )}
            <div ref={endRef} />
          </div>

          {msgs.length === 1 && (
            <div className="flex flex-wrap gap-2 px-4 pb-2">
              {['Объясни проще', 'Дай пример промпта', 'Проверь мой вариант'].map((chip) => (
                <button
                  key={chip}
                  onClick={() => send(chip)}
                  className="chip border border-white/[0.1] text-[#9AA6BC] transition-colors hover:border-[#E879F9] hover:text-white"
                >
                  {chip}
                </button>
              ))}
            </div>
          )}

          <form
            onSubmit={(e) => {
              e.preventDefault()
              send(input)
            }}
            className="flex gap-2 border-t border-white/[0.08] p-4"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Задайте вопрос по уроку…"
              className="h-11 flex-1 rounded-xl border border-white/[0.08] bg-[#07090F] px-4 text-sm placeholder:text-[#5C6B84] focus:border-[#E879F9] focus:outline-none"
            />
            <button
              type="submit"
              disabled={ask.isPending || !input.trim()}
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-ai-gradient text-white transition-transform hover:scale-105 disabled:opacity-50"
              aria-label="Отправить"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </motion.aside>
      )}
    </AnimatePresence>
  )
}

/* ── Хелперы парсинга JSON-полей ────────────────────────── */
function parseJsonArray<T>(raw: string | null, fallback: T[]): T[] {
  if (!raw) return fallback
  try {
    const v = JSON.parse(raw)
    return Array.isArray(v) && v.length > 0 ? (v as T[]) : fallback
  } catch {
    return fallback
  }
}

type Material = { title?: string; name?: string; size?: string; url?: string }
type PromptItem = { title?: string; text?: string; prompt?: string }

const TABS = ['Конспект', 'Материалы', 'Промпты', 'Обсуждение'] as const

const MOCK_COMMENTS = [
  { name: 'Марина К.', text: 'Отличный урок! Наконец-то поняла, как строить структуру письма с помощью нейросети.', time: '2 ч назад' },
  { name: 'Дмитрий С.', text: 'А подскажите, этот подход работает и в GigaChat? У меня без VPN только он доступен.', time: '5 ч назад' },
  { name: 'Ольга В.', text: 'Промпт из материалов — огонь. Сэкономил мне часа два на рассылке.', time: 'вчера' },
]

export default function Lesson() {
  const { id } = useParams<{ id: string }>()
  const lessonId = Number(id)
  const navigate = useNavigate()
  const { isAuthenticated, isLoading: authLoading } = useAuth({ redirectOnUnauthenticated: true })

  const list = trpc.courses.list.useQuery()
  const courseQueries = trpc.useQueries((t) =>
    (list.data ?? []).map((c) => t.courses.bySlug({ slug: c.slug }))
  )

  const complete = trpc.me.completeLesson.useMutation()
  const [completed, setCompleted] = useState(false)
  const [showXpModal, setShowXpModal] = useState(false)
  const [xpResult, setXpResult] = useState<{ xp: number; level: number; streakDays: number; xpGained: number } | null>(null)
  const [chatOpen, setChatOpen] = useState(false)
  const [tab, setTab] = useState<(typeof TABS)[number]>('Конспект')
  const [copied, setCopied] = useState<number | null>(null)
  const [comment, setComment] = useState('')
  const [comments, setComments] = useState(MOCK_COMMENTS)
  const [structureOpen, setStructureOpen] = useState(true)
  const currentRef = useRef<HTMLAnchorElement>(null)

  /* Находим урок и его курс среди загруженных */
  const found = useMemo(() => {
    for (const q of courseQueries) {
      const course = q.data
      if (!course) continue
      const modules: ModuleData[] = course.modules.map((m) => ({ id: m.id, title: m.title, lessons: m.lessons }))
      for (const m of modules) {
        const lesson = m.lessons.find((l) => l.id === lessonId)
        if (lesson) return { course, modules, lesson, module: m }
      }
    }
    return null
  }, [courseQueries, lessonId])

  const loading = list.isLoading || courseQueries.some((q) => q.isLoading)

  const flatLessons = useMemo(() => (found ? found.modules.flatMap((m) => m.lessons) : []), [found])
  const idx = flatLessons.findIndex((l) => l.id === lessonId)
  const prevLesson = idx > 0 ? flatLessons[idx - 1] : null
  const nextLesson = idx >= 0 && idx < flatLessons.length - 1 ? flatLessons[idx + 1] : null
  const courseProgress = flatLessons.length ? Math.round(((idx + (completed ? 1 : 0)) / flatLessons.length) * 100) : 0

  useEffect(() => {
    currentRef.current?.scrollIntoView({ block: 'center' })
  }, [found])

  if (authLoading || loading) {
    return (
      <div className="mx-auto max-w-[1280px] px-6 py-10">
        <div className="h-6 w-64 animate-pulse rounded-lg bg-white/5" />
        <div className="mt-6 flex gap-6">
          <div className="flex-1">
            <div className="aspect-video animate-pulse rounded-[20px] bg-white/5" />
            <div className="mt-6 h-8 w-2/3 animate-pulse rounded-lg bg-white/5" />
            <div className="mt-4 h-40 animate-pulse rounded-[20px] bg-white/5" />
          </div>
          <div className="hidden w-[320px] shrink-0 lg:block">
            <div className="h-[480px] animate-pulse rounded-[20px] bg-white/5" />
          </div>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) return null

  if (!found || !Number.isFinite(lessonId)) {
    return (
      <div className="mx-auto flex min-h-[60vh] max-w-[1280px] flex-col items-center justify-center px-6 py-24 text-center">
        <h1 className="font-display text-3xl font-bold">Урок не найден</h1>
        <p className="mt-3 text-[#9AA6BC]">Возможно, он был перемещён или у вас нет к нему доступа.</p>
        <Link to="/dashboard" className="btn-primary mt-8">
          В личный кабинет
        </Link>
      </div>
    )
  }

  const { course, modules, lesson, module } = found

  const materials = parseJsonArray<Material>(lesson.materialsJson, [
    { title: 'Шаблон письма.docx', size: '84 КБ' },
    { title: 'Чек-лист урока.pdf', size: '120 КБ' },
  ])
  const prompts = parseJsonArray<PromptItem>(lesson.promptsJson, [
    {
      title: 'Универсальный каркас промпта',
      text: 'Ты — опытный редактор деловых писем. Контекст: [опиши ситуацию]. Задача: напиши письмо для [аудитория] с целью [цель]. Тон: дружелюбный, но деловой. Формат: 3 абзаца, призыв к действию в конце.',
    },
  ])

  const summaryParagraphs = (lesson.summary ??
    'В этом уроке разбираем практический приём и сразу применяем его на реальной задаче. Вы увидите пошаговый разбор, типичные ошибки и готовые формулировки, которые можно забрать в работу уже сегодня.'
  )
    .split(/\n{2,}|\r?\n/)
    .filter(Boolean)

  const copyPrompt = async (text: string, i: number) => {
    try {
      await navigator.clipboard.writeText(text)
    } catch {
      /* буфер недоступен — тихо */
    }
    setCopied(i)
    setTimeout(() => setCopied(null), 1800)
  }

  const finishLesson = () => {
    if (completed || complete.isPending) return
    complete.mutate(
      { lessonId },
      {
        onSuccess: (res) => {
          setCompleted(true)
          setXpResult(res)
          setShowXpModal(true)
        },
      }
    )
  }

  const posterIdx = (lessonId % 4) + 1
  const poster = `/lesson-thumb-${posterIdx}.png`

  return (
    <div className="relative">
      {/* Верхняя панель */}
      <div className="sticky top-[72px] z-40 border-b border-white/[0.06] bg-[#07090F]/85 backdrop-blur-xl">
        <div className="mx-auto flex h-14 max-w-[1440px] items-center gap-4 px-6">
          <Link to="/dashboard" className="flex items-center gap-1.5 text-sm text-[#9AA6BC] transition-colors hover:text-white">
            <ArrowLeft className="h-4 w-4" /> <span className="hidden sm:inline">В кабинет</span>
          </Link>
          <span className="truncate text-sm font-medium">{course.title}</span>
          <div className="ml-auto flex items-center gap-3">
            <div className="hidden items-center gap-2 sm:flex">
              <div className="h-1.5 w-28 overflow-hidden rounded-full bg-white/[0.08]">
                <motion.div
                  className="h-full rounded-full bg-brand-gradient"
                  animate={{ width: `${courseProgress}%` }}
                  transition={{ duration: 0.6 }}
                />
              </div>
              <span className="text-[12px] text-[#5C6B84]">{courseProgress}%</span>
            </div>
            <span className="chip bg-brand-gradient text-white">+{XP_REWARD} XP</span>
          </div>
        </div>
      </div>

      <div className="mx-auto flex max-w-[1440px] gap-6 px-6 py-8">
        {/* Основная зона */}
        <div className="min-w-0 flex-1 lg:max-w-[900px]">
          <MockPlayer durationMin={lesson.durationMin || 12} poster={poster} />

          {/* Заголовок + действия */}
          <div className="mt-6 flex flex-wrap items-start justify-between gap-4">
            <div>
              <h1 className="font-display text-2xl font-bold md:text-[28px]">{lesson.title}</h1>
              <p className="mt-2 text-sm text-[#5C6B84]">
                {lesson.durationMin || 12} мин · {module.title} · +{XP_REWARD} XP
              </p>
            </div>
            <div className="flex gap-3">
              <motion.button
                onClick={finishLesson}
                disabled={completed || complete.isPending}
                whileTap={{ scale: 0.97 }}
                className={cn(
                  'btn-primary !px-5 !py-2.5 text-sm',
                  completed && '!bg-none !bg-[#34D399]/20 !text-[#34D399] !shadow-none'
                )}
              >
                <Check className="h-4 w-4" />
                {completed ? 'Пройдено' : complete.isPending ? 'Сохраняем…' : 'Завершить урок'}
              </motion.button>
              {nextLesson && (
                <Link to={`/lesson/${nextLesson.id}`} className="btn-ghost !px-5 !py-2.5 text-sm">
                  Следующий урок <ChevronRight className="h-4 w-4" />
                </Link>
              )}
            </div>
          </div>

          {/* Табы */}
          <div className="mt-8">
            <div className="flex gap-1 overflow-x-auto border-b border-white/[0.08]">
              {TABS.map((t) => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={cn(
                    'relative whitespace-nowrap px-4 py-3 text-sm font-medium transition-colors',
                    tab === t ? 'text-white' : 'text-[#5C6B84] hover:text-[#9AA6BC]'
                  )}
                >
                  {t}
                  {tab === t && (
                    <motion.span layoutId="lesson-tab" className="absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-brand-gradient" />
                  )}
                </button>
              ))}
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={tab}
                initial={{ opacity: 0, x: 12 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -12 }}
                transition={{ duration: 0.25, ease: EASE }}
                className="py-6"
              >
                {tab === 'Конспект' && (
                  <div className="space-y-4 text-[15px] leading-relaxed text-[#9AA6BC]">
                    {summaryParagraphs.map((p, i) => (
                      <p key={i}>{p}</p>
                    ))}
                    <div className="rounded-2xl glass p-5">
                      <div className="mb-3 text-sm font-semibold text-white">Ключевые тезисы</div>
                      <ul className="list-disc space-y-2 pl-5">
                        <li>Чёткий контекст — 80% хорошего результата нейросети.</li>
                        <li>Итерируйте: уточняйте запрос, просите варианты и примеры.</li>
                        <li>Российский стек (GigaChat, YandexGPT) закрывает большинство задач без VPN.</li>
                      </ul>
                    </div>
                  </div>
                )}

                {tab === 'Материалы' && (
                  <div className="grid gap-3 sm:grid-cols-2">
                    {materials.map((m, i) => (
                      <div key={i} className="flex items-center gap-4 rounded-2xl glass p-4">
                        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#7C5CFF]/15">
                          <FileText className="h-5 w-5 text-[#7C5CFF]" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-sm font-medium">{m.title ?? m.name ?? `Материал ${i + 1}`}</div>
                          <div className="text-[12px] text-[#5C6B84]">{m.size ?? 'файл'}</div>
                        </div>
                        <button className="btn-ghost !rounded-xl !px-3 !py-2 text-[12px]" aria-label="Скачать">
                          <Download className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {tab === 'Промпты' && (
                  <div className="space-y-4">
                    {prompts.map((p, i) => {
                      const text = p.text ?? p.prompt ?? ''
                      return (
                        <div key={i} className="overflow-hidden rounded-2xl border border-white/[0.08] bg-[#0D1117]">
                          <div className="flex items-center justify-between border-b border-white/[0.06] px-4 py-2.5">
                            <span className="text-[13px] font-medium text-[#9AA6BC]">{p.title ?? `Промпт ${i + 1}`}</span>
                            <button
                              onClick={() => copyPrompt(text, i)}
                              className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[12px] font-medium text-[#22D3EE] transition-colors hover:bg-white/5"
                            >
                              {copied === i ? (
                                <>
                                  <Check className="h-3.5 w-3.5 text-[#34D399]" /> Скопировано
                                </>
                              ) : (
                                <>
                                  <Copy className="h-3.5 w-3.5" /> Копировать
                                </>
                              )}
                            </button>
                          </div>
                          <pre className="overflow-x-auto whitespace-pre-wrap p-4 font-mono2 text-[13px] leading-relaxed text-[#F2F5FA]/90">
                            {text}
                          </pre>
                        </div>
                      )
                    })}
                  </div>
                )}

                {tab === 'Обсуждение' && (
                  <div className="space-y-5">
                    {comments.map((c, i) => (
                      <div key={i} className="flex gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[#7C5CFF] to-[#22D3EE] text-[13px] font-bold text-white">
                          {c.name.slice(0, 1)}
                        </div>
                        <div className="min-w-0 flex-1 rounded-2xl glass p-4">
                          <div className="flex items-baseline gap-2">
                            <span className="text-sm font-semibold">{c.name}</span>
                            <span className="text-[12px] text-[#5C6B84]">{c.time}</span>
                          </div>
                          <p className="mt-1.5 text-sm text-[#9AA6BC]">{c.text}</p>
                        </div>
                      </div>
                    ))}
                    <form
                      onSubmit={(e) => {
                        e.preventDefault()
                        const t = comment.trim()
                        if (!t) return
                        setComments((cs) => [...cs, { name: 'Вы', text: t, time: 'только что' }])
                        setComment('')
                      }}
                      className="flex gap-2"
                    >
                      <input
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        placeholder="Написать комментарий…"
                        className="h-11 flex-1 rounded-xl border border-white/[0.08] bg-[#0D1117] px-4 text-sm placeholder:text-[#5C6B84] focus:border-[#7C5CFF] focus:outline-none"
                      />
                      <button type="submit" className="btn-primary !px-4 !py-0 h-11" aria-label="Отправить комментарий">
                        <Send className="h-4 w-4" />
                      </button>
                    </form>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Нижняя навигация */}
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            {prevLesson ? (
              <Link to={`/lesson/${prevLesson.id}`} className="group rounded-2xl glass p-5 transition-all hover:-translate-x-1 hover:border-[#7C5CFF]/50">
                <div className="flex items-center gap-2 text-[12px] text-[#5C6B84]">
                  <ChevronLeft className="h-4 w-4" /> Предыдущий урок
                </div>
                <div className="mt-2 truncate text-sm font-medium">{prevLesson.title}</div>
                <div className="mt-1 text-[12px] text-[#5C6B84]">{prevLesson.durationMin} мин</div>
              </Link>
            ) : (
              <div />
            )}
            {nextLesson && (
              <Link to={`/lesson/${nextLesson.id}`} className="group rounded-2xl glass p-5 text-right transition-all hover:translate-x-1 hover:border-[#22D3EE]/50">
                <div className="flex items-center justify-end gap-2 text-[12px] text-[#5C6B84]">
                  Следующий урок <ChevronRight className="h-4 w-4" />
                </div>
                <div className="mt-2 truncate text-sm font-medium">{nextLesson.title}</div>
                <div className="mt-1 text-[12px] text-[#5C6B84]">{nextLesson.durationMin} мин</div>
              </Link>
            )}
          </div>
        </div>

        {/* Правая панель: структура курса */}
        <aside className="hidden w-[320px] shrink-0 lg:block">
          <div className="sticky top-[152px] rounded-[20px] glass">
            <button
              onClick={() => setStructureOpen((o) => !o)}
              className="flex w-full items-center justify-between p-5"
            >
              <span className="text-sm font-semibold">Структура курса</span>
              <ChevronDown className={cn('h-4 w-4 text-[#5C6B84] transition-transform', structureOpen && 'rotate-180')} />
            </button>
            <div className="px-5 pb-2">
              <div className="h-1.5 overflow-hidden rounded-full bg-white/[0.08]">
                <motion.div className="h-full rounded-full bg-brand-gradient" animate={{ width: `${courseProgress}%` }} />
              </div>
              <div className="mt-1.5 text-[12px] text-[#5C6B84]">Пройдено {courseProgress}%</div>
            </div>
            {structureOpen && (
              <div className="max-h-[55vh] space-y-4 overflow-y-auto p-5 pt-3">
                {modules.map((m) => (
                  <div key={m.id}>
                    <div className="mb-2 text-[12px] font-semibold uppercase tracking-wider text-[#5C6B84]">
                      {m.title}
                    </div>
                    <div className="space-y-1">
                      {m.lessons.map((l) => {
                        const isCurrent = l.id === lessonId
                        const isDone = isCurrent && completed
                        return (
                          <Link
                            key={l.id}
                            ref={isCurrent ? currentRef : undefined}
                            to={`/lesson/${l.id}`}
                            className={cn(
                              'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors',
                              isCurrent ? 'bg-brand-gradient text-white' : 'text-[#9AA6BC] hover:bg-white/5'
                            )}
                          >
                            {isDone ? (
                              <Check className="h-4 w-4 shrink-0" />
                            ) : isCurrent ? (
                              <Play className="h-4 w-4 shrink-0 fill-white" />
                            ) : (
                              <span className="h-4 w-4 shrink-0 rounded-full border border-white/20" />
                            )}
                            <span className="min-w-0 flex-1 truncate">{l.title}</span>
                            <span className={cn('shrink-0 text-[11px]', isCurrent ? 'text-white/80' : 'text-[#5C6B84]')}>
                              {l.durationMin} мин
                            </span>
                          </Link>
                        )
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </aside>
      </div>

      {/* FAB ИИ-куратора */}
      {!chatOpen && (
        <motion.button
          onClick={() => setChatOpen(true)}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          whileHover={{ scale: 1.06 }}
          className="fixed bottom-6 right-6 z-[60] flex h-[60px] w-[60px] items-center justify-center rounded-full bg-ai-gradient p-[3px] shadow-[0_0_32px_rgba(232,121,249,0.45)]"
          aria-label="Спросить ИИ-куратора"
          title="Спросить ИИ-куратора"
        >
          <span className="absolute inset-0 animate-ping rounded-full bg-[#E879F9]/30" />
          <img src="/ai-twin.png" alt="" className="h-full w-full rounded-full object-cover" />
        </motion.button>
      )}

      <AiChat lessonId={lessonId} lessonTitle={lesson.title} open={chatOpen} onClose={() => setChatOpen(false)} />

      {/* Модалка завершения */}
      <Confetti fire={showXpModal} />
      <AnimatePresence>
        {showXpModal && xpResult && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[80] flex items-center justify-center bg-[rgba(4,6,10,0.7)] p-6 backdrop-blur-sm"
            onClick={() => setShowXpModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 240, damping: 20 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md rounded-[24px] glass p-8 text-center"
            >
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-brand-gradient shadow-[0_0_40px_rgba(124,92,255,0.5)]">
                <Check className="h-8 w-8 text-white" />
              </div>
              <h2 className="mt-5 font-display text-2xl font-bold">Урок пройден!</h2>
              <motion.div
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.2, type: 'spring', stiffness: 200, damping: 12 }}
                className="mt-3 font-display text-4xl font-bold text-gradient"
              >
                +{xpResult.xpGained > 0 ? xpResult.xpGained : XP_REWARD} XP
              </motion.div>
              <p className="mt-3 text-sm text-[#9AA6BC]">
                Всего {xpResult.xp.toLocaleString('ru-RU')} XP · уровень {xpResult.level} · стрик {xpResult.streakDays} дн.
              </p>
              <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/[0.07]">
                <motion.div
                  className="h-full rounded-full bg-brand-gradient"
                  initial={{ width: 0 }}
                  animate={{ width: `${(xpResult.xp % 1000) / 10}%` }}
                  transition={{ delay: 0.3, duration: 0.8, ease: 'easeOut' }}
                />
              </div>
              <div className="mt-7 flex flex-col gap-3 sm:flex-row">
                {nextLesson ? (
                  <button onClick={() => navigate(`/lesson/${nextLesson.id}`)} className="btn-primary flex-1">
                    К следующему уроку
                  </button>
                ) : (
                  <button onClick={() => setShowXpModal(false)} className="btn-primary flex-1">
                    Отлично!
                  </button>
                )}
                <button onClick={() => navigate('/dashboard')} className="btn-ghost flex-1">
                  В кабинет
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
