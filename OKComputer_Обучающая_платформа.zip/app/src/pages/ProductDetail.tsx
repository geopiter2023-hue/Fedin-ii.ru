import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import { ArrowLeft, ArrowRight, Check, FileText, Mail, ShieldCheck, Star } from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { useAuth } from '@/hooks/useAuth'
import { LOGIN_PATH } from '@/const'
import { coverFor, formatPrice } from '@/pages/Shop'

const WHAT_INSIDE: Record<string, string[]> = {
  'prompt-pack': [
    'PDF + Notion-версия с навигацией по темам',
    'Структура: роль → контекст → формат ответа',
    'Готовые переменные под вашу нишу',
    'Бонус: чек-лист качества ответа',
  ],
  guide: [
    'Пошаговые инструкции со скриншотами',
    'Проверенные способы оплаты из России',
    'Сравнение тарифов и сервисов',
    'Обновления при изменении условий',
  ],
  n8n: [
    'Файлы .json — импорт в n8n за минуту',
    'Видео-инструкция по настройке',
    'Комментарии к каждому узлу сценария',
    'Помощь с запуском в комьюнити',
  ],
  preset: [
    'Библиотека стилей с примерами рендеров',
    'Параметры и негативные промпты',
    'Гайд по комбинированию стилей',
    'Новые пресеты — бесплатно',
  ],
  subscription: [
    'Все новые промпт-паки бесплатно',
    'Ежемесячные обновления курсов',
    'Закрытое комьюнити и разборы',
    'Доступ к ИИ-куратору',
  ],
}

const CATEGORY_LABEL: Record<string, string> = {
  'prompt-pack': 'Промпт-пак',
  guide: 'Гайд',
  n8n: 'n8n-связка',
  preset: 'Пресеты',
  subscription: 'Подписка',
}

export default function ProductDetail() {
  const { id: slug = '' } = useParams()
  const navigate = useNavigate()
  const { isAuthenticated } = useAuth()
  const { data: product, isLoading, isError } = trpc.products.bySlug.useQuery({ slug })
  const { data: all } = trpc.products.list.useQuery()
  const checkout = trpc.shop.checkout.useMutation()
  const [done, setDone] = useState(false)
  const [buying, setBuying] = useState(false)

  const similar = (all ?? [])
    .filter((p) => product && p.category === product.category && p.id !== product.id)
    .slice(0, 4)

  const buy = async () => {
    if (!product) return
    if (!isAuthenticated) {
      navigate(LOGIN_PATH)
      return
    }
    setBuying(true)
    try {
      await checkout.mutateAsync({ itemType: 'product', itemId: product.id })
      setDone(true)
    } catch {
      // покажем ошибку ниже
    } finally {
      setBuying(false)
    }
  }

  if (isLoading) {
    return (
      <div className="mx-auto max-w-[1280px] animate-pulse px-6 pb-24 pt-24">
        <div className="h-4 w-40 rounded bg-white/5" />
        <div className="mt-8 grid gap-10 md:grid-cols-2">
          <div className="aspect-[4/5] rounded-[24px] bg-white/5" />
          <div className="space-y-4">
            <div className="h-8 w-3/4 rounded bg-white/5" />
            <div className="h-4 w-full rounded bg-white/5" />
            <div className="h-4 w-2/3 rounded bg-white/5" />
            <div className="h-12 w-48 rounded-[14px] bg-white/5" />
          </div>
        </div>
      </div>
    )
  }

  if (isError || !product) {
    return (
      <div className="mx-auto flex min-h-[60vh] max-w-[1280px] flex-col items-center justify-center px-6 py-24 text-center">
        <h1 className="font-display text-3xl font-bold">Товар не найден</h1>
        <p className="mt-3 text-[#9AA6BC]">Возможно, он был снят с продажи.</p>
        <Link to="/shop" className="btn-primary mt-8">
          <ArrowLeft className="h-4 w-4" /> Вернуться в магазин
        </Link>
      </div>
    )
  }

  return (
    <div className="relative overflow-hidden pb-24">
      <div className="pointer-events-none absolute -top-40 right-0 h-[600px] w-[600px] glow-violet animate-drift" />

      <div className="mx-auto max-w-[1280px] px-6 pt-24">
        <Link
          to="/shop"
          className="inline-flex items-center gap-2 text-sm text-[#9AA6BC] transition-colors hover:text-[#F2F5FA]"
        >
          <ArrowLeft className="h-4 w-4" /> Магазин
        </Link>

        <div className="mt-8 grid gap-10 lg:grid-cols-[minmax(0,480px)_1fr]">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="gradient-border rounded-[24px] p-3">
              <img
                src={coverFor(product)}
                alt={product.title}
                className="aspect-[4/5] w-full rounded-[16px] object-cover"
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.5 }}
          >
            <div className="flex items-center gap-3">
              <span className="chip bg-brand-gradient text-[12px] font-bold text-white">
                {CATEGORY_LABEL[product.category]}
              </span>
              {product.isHit && (
                <span className="chip bg-[#F87171]/15 text-[12px] font-bold text-[#F87171]">Хит</span>
              )}
            </div>
            <h1 className="mt-4 font-display text-3xl font-extrabold md:text-4xl">{product.title}</h1>
            <div className="mt-3 flex items-center gap-1 text-sm text-[#FBBF24]">
              <Star className="h-4 w-4 fill-current" /> 4.9
              <span className="text-[#5C6B84]">· 120+ покупок</span>
            </div>
            <p className="mt-4 max-w-xl text-lg text-[#9AA6BC]">{product.description}</p>

            <h2 className="mt-8 font-display text-lg font-bold">Состав продукта</h2>
            <ul className="mt-3 space-y-2.5 text-[#9AA6BC]">
              {(WHAT_INSIDE[product.category] ?? []).map((w) => (
                <li key={w} className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-[#34D399]" /> {w}
                </li>
              ))}
            </ul>

            <div className="mt-6 grid gap-3 sm:grid-cols-3">
              {[
                { icon: FileText, text: 'Формат: PDF / JSON / Notion' },
                { icon: Mail, text: 'Мгновенная доставка на email' },
                { icon: ShieldCheck, text: 'Возврат 14 дней' },
              ].map((f) => (
                <div key={f.text} className="flex items-center gap-2 rounded-2xl glass-light px-3 py-3 text-[13px] text-[#9AA6BC]">
                  <f.icon className="h-4 w-4 shrink-0 text-[#22D3EE]" /> {f.text}
                </div>
              ))}
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-4">
              <div className="flex items-baseline gap-3">
                <span className="font-display text-4xl font-bold">{formatPrice(product.price)}</span>
                {product.oldPrice && (
                  <span className="text-xl text-[#5C6B84] line-through">
                    {formatPrice(product.oldPrice)}
                  </span>
                )}
              </div>
            </div>

            {done ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mt-6 rounded-[20px] border border-[#34D399]/30 bg-[#34D399]/10 p-5"
              >
                <p className="flex items-center gap-2 font-display font-bold text-[#34D399]">
                  <Check className="h-5 w-5" /> Покупка оформлена
                </p>
                <p className="mt-1 text-sm text-[#9AA6BC]">
                  Файлы уже доступны в личном кабинете.
                </p>
                <Link to="/dashboard" className="btn-primary mt-4 py-2.5 text-sm">
                  Перейти в кабинет <ArrowRight className="h-4 w-4" />
                </Link>
              </motion.div>
            ) : (
              <>
                <button onClick={buy} disabled={buying} className="btn-primary mt-6 disabled:opacity-60">
                  {buying ? 'Оформляем…' : `Купить за ${formatPrice(product.price)}`}
                </button>
                {checkout.isError && (
                  <p className="mt-3 text-sm text-[#F87171]">
                    Не удалось оформить заказ. Попробуйте ещё раз.
                  </p>
                )}
              </>
            )}
          </motion.div>
        </div>

        {/* Похожие продукты */}
        {similar.length > 0 && (
          <section className="mt-20">
            <h2 className="font-display text-2xl font-bold">
              Похожие <span className="text-gradient">продукты</span>
            </h2>
            <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {similar.map((p, i) => (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.06, duration: 0.4 }}
                  whileHover={{ y: -5 }}
                >
                  <Link
                    to={`/shop/${p.slug}`}
                    className="block rounded-[20px] glass-light p-3 transition-colors hover:border-[#7C5CFF]/50"
                  >
                    <img
                      src={coverFor(p)}
                      alt={p.title}
                      loading="lazy"
                      className="aspect-[4/5] w-full rounded-2xl object-cover"
                    />
                    <h3 className="mt-3 font-display text-[15px] font-bold leading-snug">{p.title}</h3>
                    <p className="mt-2 font-display text-lg font-bold text-[#22D3EE]">
                      {formatPrice(p.price)}
                    </p>
                  </Link>
                </motion.div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  )
}
