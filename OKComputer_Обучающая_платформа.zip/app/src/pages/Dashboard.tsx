import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import {
  Flame,
  Zap,
  Play,
  Award,
  Sparkles,
  Send,
  ArrowRight,
  BookOpen,
  Trophy,
  Lock,
  GraduationCap,
  Clock,
  CalendarDays,
  FileDown,
} from 'lucide-react'
import { trpc } from '@/providers/trpc'
import { useAuth } from '@/hooks/useAuth'
import { cn } from '@/lib/utils'

const EASE = [0.16, 1, 0.3, 1] as [number, number, number, number]
const XP_PER_LEVEL = 1000

const rise = (delay = 0) => ({
  initial: { opacity: 0, y: 24 },
  animate: { opacity: 1, y: 0 },
  transition: { delay, duration: 0.5, ease: EASE },
})

/* ── Кольцевой прогресс ─────────────────────────────────── */
function RingProgress({ percent, size = 84 }: { percent: number; size?: number }) {
  const stroke = 7
  const r = (size - stroke) / 2
  const c = 2 * Math.PI * r
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id="ring-grad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#7C5CFF" />
            <stop offset="100%" stopColor="#22D3EE" />
          </linearGradient>
        </defs>
        <circle cx={size / 2} cy={size / 2} r={r} stroke="rgba(255,255,255,0.08)" strokeWidth={stroke} fill="none" />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke="url(#ring-grad)"
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: c - (c * percent) / 100 }}
          transition={{ duration: 1, ease: EASE }}
        />
      </svg>
      <span className="absolute inset-0 flex items-center justify-center font-display text-sm font-bold text-[#F2F5FA]">
        {percent}%
      </span>
    </div>
  )
}

/* ── Heatmap активности (мок, детерминированный) ────────── */
function ActivityHeatmap() {
  const weeks = 12
  const days = 7
  const value = (w: number, d: number) => {
    const x = Math.sin(w * 12.9898 + d * 78.233) * 43758.5453
    return x - Math.floor(x)
  }
  return (
    <div className="flex gap-1.5 overflow-x-auto pb-1">
      {Array.from({ length: weeks }).map((_, w) => (
        <div key={w} className="flex flex-col gap-1.5">
          {Array.from({ length: days }).map((_, d) => {
            const v = value(w, d)
            const level = v > 0.82 ? 3 : v > 0.6 ? 2 : v > 0.38 ? 1 : 0
            return (
              <motion.div
                key={d}
                initial={{ opacity: 0, scale: 0.4 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: w * 0.02, duration: 0.25 }}
                title={level === 0 ? 'Нет активности' : `${level} урок(а)`}
                className={cn(
                  'h-3 w-3 rounded-[4px]',
                  level === 0 && 'bg-[#0D1117]',
                  level === 1 && 'bg-[#22D3EE]/25',
                  level === 2 && 'bg-[#22D3EE]/55',
                  level === 3 && 'bg-[#22D3EE]'
                )}
              />
            )
          })}
        </div>
      ))}
    </div>
  )
}

/* ── Скелетон ───────────────────────────────────────────── */
function DashboardSkeleton() {
  return (
    <div className="mx-auto max-w-[1280px] px-6 py-12">
      <div className="h-9 w-72 animate-pulse rounded-xl bg-white/5" />
      <div className="mt-3 h-4 w-48 animate-pulse rounded-lg bg-white/5" />
      <div className="mt-10 grid gap-5 lg:grid-cols-3">
        {[0, 1, 2].map((i) => (
          <div key={i} className="h-40 animate-pulse rounded-[20px] bg-white/5" />
        ))}
      </div>
      <div className="mt-6 h-44 animate-pulse rounded-[20px] bg-white/5" />
      <div className="mt-6 grid gap-5 md:grid-cols-3">
        {[0, 1, 2].map((i) => (
          <div key={i} className="h-64 animate-pulse rounded-[20px] bg-white/5" />
        ))}
      </div>
    </div>
  )
}

const POSTER_FALLBACK: Record<string, string> = {}

function posterOf(poster: string | null | undefined, slug: string) {
  if (poster) return poster.startsWith('/') ? poster : `/${poster}`
  return POSTER_FALLBACK[slug] ?? '/course-work.png'
}

const LOCKED_ACHIEVEMENTS = [
  { code: 'streak-7', title: 'Стрик 7 дней', hint: 'Занимайтесь 7 дней подряд' },
  { code: 'module-done', title: 'Модуль закрыт', hint: 'Завершите модуль целиком' },
  { code: 'prompt-master', title: 'Промпт-мастер', hint: 'Скопируйте 10 промптов' },
  { code: 'marathon', title: 'Марафонец', hint: 'Стрик 30 дней' },
  { code: 'perfect', title: 'Перфекционист', hint: 'Завершите 5 курсов' },
  { code: 'curious', title: 'Спроси куратора', hint: 'Задайте вопрос ИИ-куратору' },
]

export default function Dashboard() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth({ redirectOnUnauthenticated: true })
  const dash = trpc.me.dashboard.useQuery(undefined, { enabled: isAuthenticated })
  const certs = trpc.me.certificates.useQuery(undefined, { enabled: isAuthenticated })
  const aiAsk = trpc.ai.ask.useMutation()
  const [question, setQuestion] = useState('')
  const [aiAnswer, setAiAnswer] = useState<string | null>(null)

  const courses = dash.data?.courses ?? []
  const stats = dash.data?.stats
  const achievements = dash.data?.achievements ?? []

  const xp = stats?.xp ?? 0
  const level = stats?.level ?? 1
  const xpInLevel = xp % XP_PER_LEVEL
  const xpPercent = Math.round((xpInLevel / XP_PER_LEVEL) * 100)
  const streak = stats?.streakDays ?? 0

  const continueCourse = useMemo(
    () =>
      courses.find((c) => c.progressPercent > 0 && c.progressPercent < 100) ??
      courses.find((c) => c.progressPercent === 0) ??
      null,
    [courses]
  )

  // Находим следующий урок для «Продолжить обучение»
  const continueDetail = trpc.courses.bySlug.useQuery(
    { slug: continueCourse?.course.slug ?? '' },
    { enabled: !!continueCourse }
  )
  const nextLessonId = useMemo(() => {
    if (!continueDetail.data || !continueCourse) return null
    const lessons = continueDetail.data.modules.flatMap((m) => m.lessons)
    const idx = Math.min(continueCourse.completedLessons, lessons.length - 1)
    return lessons[idx]?.id ?? lessons[0]?.id ?? null
  }, [continueDetail.data, continueCourse])

  const totalCompletedLessons = courses.reduce((s, c) => s + c.completedLessons, 0)

  if (authLoading || (isAuthenticated && dash.isLoading)) return <DashboardSkeleton />
  if (!isAuthenticated) return null

  const firstName = user?.name?.split(' ')[0] ?? 'друг'
  const unlocked = new Set(achievements.map((a) => a.code))

  const askCurator = (e?: React.FormEvent) => {
    e?.preventDefault()
    const q = question.trim()
    if (!q || aiAsk.isPending) return
    aiAsk.mutate(
      { question: q },
      {
        onSuccess: (res) => {
          setAiAnswer(res.answer)
          setQuestion('')
        },
      }
    )
  }

  return (
    <div className="relative mx-auto max-w-[1280px] px-6 py-12">
      {/* фоновые свечения */}
      <div className="pointer-events-none absolute -top-24 right-0 h-[500px] w-[500px] glow-violet blur-3xl" />
      <div className="pointer-events-none absolute top-[600px] -left-40 h-[500px] w-[500px] glow-cyan blur-3xl" />

      {/* 1. Приветствие */}
      <motion.div {...rise(0)}>
        <h1 className="font-display text-3xl font-bold md:text-4xl">
          С возвращением, <span className="text-gradient">{firstName}</span>!
        </h1>
        <p className="mt-3 text-[#9AA6BC]">Продолжим с того места, где вы остановились.</p>
      </motion.div>

      {/* Виджеты: XP / стрик / ИИ-куратор */}
      <div className="mt-8 grid gap-5 lg:grid-cols-3">
        {/* XP */}
        <motion.div {...rise(0.08)} className="gradient-border rounded-[20px] p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-[#9AA6BC]">
              <Zap className="h-4 w-4 text-[#22D3EE]" />
              <span className="text-sm font-medium">Уровень {level} · Нейропрактик</span>
            </div>
            <span className="chip bg-brand-gradient text-white">
              <Zap className="h-3.5 w-3.5" /> {xp.toLocaleString('ru-RU')} XP
            </span>
          </div>
          <div className="mt-5 font-display text-4xl font-bold">
            {xpInLevel} <span className="text-lg text-[#5C6B84]">/ {XP_PER_LEVEL} XP</span>
          </div>
          <div className="mt-4 h-2.5 overflow-hidden rounded-full bg-white/[0.07]">
            <motion.div
              className="h-full rounded-full bg-brand-gradient"
              initial={{ width: 0 }}
              animate={{ width: `${xpPercent}%` }}
              transition={{ duration: 1, ease: 'easeOut' }}
            />
          </div>
          <p className="mt-3 text-[13px] text-[#5C6B84]">До уровня {level + 1} осталось {XP_PER_LEVEL - xpInLevel} XP</p>
        </motion.div>

        {/* Стрик */}
        <motion.div {...rise(0.16)} className="glass rounded-[20px] p-6">
          <div className="flex items-center gap-3">
            <motion.div
              animate={{ scale: [1, 1.08, 1] }}
              transition={{ duration: 1.2, repeat: Infinity }}
              className="flex h-11 w-11 items-center justify-center rounded-full bg-[#FBBF24]/15"
            >
              <Flame className="h-5 w-5 text-[#FBBF24]" />
            </motion.div>
            <div>
              <div className="font-display text-2xl font-bold">{streak} дн. подряд</div>
              <div className="text-[13px] text-[#5C6B84]">ваш текущий стрик</div>
            </div>
          </div>
          <div className="mt-5 flex justify-between">
            {['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map((d, i) => {
              const today = (new Date().getDay() + 6) % 7
              const active = i <= today && today - i < Math.max(streak, 1)
              return (
                <div key={d} className="flex flex-col items-center gap-1.5">
                  <div
                    className={cn(
                      'h-2.5 w-2.5 rounded-full',
                      active ? 'bg-brand-gradient' : 'bg-white/10'
                    )}
                  />
                  <span className="text-[11px] text-[#5C6B84]">{d}</span>
                </div>
              )
            })}
          </div>
          <p className="mt-4 text-[13px] text-[#9AA6BC]">
            {streak > 0 ? 'Ещё 1 урок сегодня — и стрик продолжится' : 'Завершите урок, чтобы начать стрик'}
          </p>
        </motion.div>

        {/* ИИ-куратор */}
        <motion.div {...rise(0.24)} className="glass rounded-[20px] p-6">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img src="/ai-twin.png" alt="ИИ-куратор" className="h-12 w-12 rounded-full border border-[#E879F9]/40 object-cover" />
              <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-[#07090F] bg-[#34D399] animate-pulse-dot" />
            </div>
            <div>
              <div className="font-semibold">ИИ-куратор</div>
              <span className="chip bg-ai-gradient text-white !px-3 !py-0.5 text-[11px]">онлайн</span>
            </div>
          </div>
          {aiAnswer && (
            <p className="mt-4 max-h-28 overflow-y-auto rounded-xl border border-[#E879F9]/20 bg-white/[0.03] p-3 text-[13px] text-[#9AA6BC]">
              {aiAnswer}
            </p>
          )}
          <form onSubmit={askCurator} className="mt-4 flex gap-2">
            <input
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Спросите куратора…"
              className="h-11 flex-1 rounded-xl border border-white/[0.08] bg-[#0D1117] px-4 text-sm text-[#F2F5FA] placeholder:text-[#5C6B84] focus:border-[#7C5CFF] focus:outline-none"
            />
            <button
              type="submit"
              disabled={aiAsk.isPending}
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-ai-gradient text-white transition-transform hover:scale-105 disabled:opacity-50"
              aria-label="Отправить вопрос"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </motion.div>
      </div>

      {/* 2. Продолжить обучение */}
      {continueCourse && (
        <motion.div {...rise(0.3)} className="mt-8 overflow-hidden rounded-[20px] glass">
          <div className="flex flex-col md:flex-row">
            <div className="relative md:w-[340px]">
              <img
                src={posterOf(continueCourse.course.poster, continueCourse.course.slug)}
                alt={continueCourse.course.title}
                className="h-48 w-full object-cover md:h-full"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#0D1117]/40" />
            </div>
            <div className="flex flex-1 flex-col justify-center gap-4 p-7">
              <div className="chip w-fit bg-[#7C5CFF]/15 text-[#7C5CFF]">
                <BookOpen className="h-3.5 w-3.5" /> Продолжить обучение
              </div>
              <h3 className="font-display text-xl font-bold md:text-2xl">{continueCourse.course.title}</h3>
              <div>
                <div className="mb-2 flex justify-between text-[13px] text-[#9AA6BC]">
                  <span>
                    Пройдено уроков: {continueCourse.completedLessons} из {continueCourse.course.lessonsCount}
                  </span>
                  <span>{continueCourse.progressPercent}%</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-white/[0.07]">
                  <motion.div
                    className="h-full rounded-full bg-brand-gradient"
                    initial={{ width: 0 }}
                    animate={{ width: `${continueCourse.progressPercent}%` }}
                    transition={{ duration: 0.8, ease: 'easeOut' }}
                  />
                </div>
              </div>
              <div>
                {nextLessonId ? (
                  <Link to={`/lesson/${nextLessonId}`} className="btn-primary w-fit">
                    <Play className="h-4 w-4" /> Продолжить
                  </Link>
                ) : (
                  <Link to={`/courses/${continueCourse.course.slug}`} className="btn-primary w-fit">
                    <Play className="h-4 w-4" /> Открыть курс
                  </Link>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* 3. Мои курсы */}
      <motion.h2 {...rise(0.34)} className="mt-12 font-display text-2xl font-bold">
        Мои курсы
      </motion.h2>
      {courses.length === 0 ? (
        <motion.div {...rise(0.4)} className="mt-6 flex flex-col items-center rounded-[20px] glass p-12 text-center">
          <GraduationCap className="h-12 w-12 text-[#7C5CFF]" />
          <h3 className="mt-4 font-display text-xl font-bold">У вас пока нет курсов</h3>
          <p className="mt-2 max-w-md text-sm text-[#9AA6BC]">
            Выберите первый курс в каталоге — и начните осваивать нейросети уже сегодня.
          </p>
          <Link to="/courses" className="btn-primary mt-6">
            Перейти в каталог <ArrowRight className="h-4 w-4" />
          </Link>
        </motion.div>
      ) : (
        <div className="mt-6 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {courses.map((c, i) => {
            const done = c.progressPercent === 100
            const notStarted = c.progressPercent === 0
            return (
              <motion.div
                key={c.enrollmentId}
                {...rise(0.38 + i * 0.08)}
                whileHover={{ y: -6 }}
                className="group overflow-hidden rounded-[20px] glass"
              >
                <div className="relative">
                  <img
                    src={posterOf(c.course.poster, c.course.slug)}
                    alt={c.course.title}
                    className={cn(
                      'aspect-video w-full object-cover transition-transform duration-300 group-hover:scale-105',
                      notStarted && 'opacity-50 saturate-50'
                    )}
                  />
                  {done && (
                    <span className="chip absolute left-3 top-3 bg-[#34D399]/20 text-[#34D399]">
                      <Trophy className="h-3.5 w-3.5" /> Завершён
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-4 p-5">
                  <RingProgress percent={c.progressPercent} />
                  <div className="min-w-0 flex-1">
                    <h3 className="truncate font-semibold">{c.course.title}</h3>
                    <p className="mt-1 text-[13px] text-[#5C6B84]">
                      {c.completedLessons}/{c.course.lessonsCount} уроков · тариф {c.tariff === 'pro' ? 'PRO' : 'Базовый'}
                    </p>
                    <Link
                      to={`/courses/${c.course.slug}`}
                      className="btn-ghost mt-3 !px-4 !py-2 text-[13px]"
                    >
                      {done ? 'Смотреть сертификат' : notStarted ? 'Начать' : 'Открыть'}
                    </Link>
                  </div>
                </div>
              </motion.div>
            )
          })}
          <motion.div {...rise(0.5)}>
            <Link
              to="/courses"
              className="flex h-full min-h-[220px] flex-col items-center justify-center gap-3 rounded-[20px] border border-dashed border-white/[0.12] p-6 text-center transition-colors hover:border-[#7C5CFF]"
            >
              <Sparkles className="h-8 w-8 text-[#7C5CFF]" />
              <span className="font-semibold">Открыть ещё курс</span>
              <span className="text-[13px] text-[#5C6B84]">Каталог из 5 практических курсов</span>
            </Link>
          </motion.div>
        </div>
      )}

      {/* 4. Достижения */}
      <motion.h2 {...rise(0)} className="mt-12 font-display text-2xl font-bold">
        Достижения · {achievements.length}
      </motion.h2>
      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {achievements.map((a, i) => (
          <motion.div
            key={a.id}
            initial={{ opacity: 0, scale: 0.6 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08, type: 'spring', stiffness: 200, damping: 14 }}
            className="flex flex-col items-center rounded-[20px] glass p-5 text-center"
            title={a.title}
          >
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-brand-gradient shadow-[0_0_24px_rgba(124,92,255,0.4)]">
              <Award className="h-6 w-6 text-white" />
            </div>
            <span className="mt-3 text-[13px] font-medium leading-tight">{a.title}</span>
          </motion.div>
        ))}
        {LOCKED_ACHIEVEMENTS.filter((a) => !unlocked.has(a.code))
          .slice(0, Math.max(0, 6 - achievements.length))
          .map((a) => (
            <div
              key={a.code}
              className="flex flex-col items-center rounded-[20px] border border-white/[0.06] bg-white/[0.02] p-5 text-center opacity-60"
              title={a.hint}
            >
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-white/[0.06]">
                <Lock className="h-5 w-5 text-[#5C6B84]" />
              </div>
              <span className="mt-3 text-[13px] font-medium leading-tight text-[#5C6B84]">{a.title}</span>
              <span className="mt-1 text-[11px] text-[#5C6B84]/70">{a.hint}</span>
            </div>
          ))}
      </div>

      {/* 5. Активность */}
      <motion.h2 {...rise(0)} className="mt-12 font-display text-2xl font-bold">
        Полоса активности
      </motion.h2>
      <motion.div {...rise(0.05)} className="mt-6 flex flex-col gap-8 rounded-[20px] glass p-7 lg:flex-row lg:items-center">
        <div className="flex-1">
          <ActivityHeatmap />
          <div className="mt-4 flex items-center gap-2 text-[12px] text-[#5C6B84]">
            <span>Меньше</span>
            <span className="h-3 w-3 rounded-[4px] bg-[#0D1117]" />
            <span className="h-3 w-3 rounded-[4px] bg-[#22D3EE]/25" />
            <span className="h-3 w-3 rounded-[4px] bg-[#22D3EE]/55" />
            <span className="h-3 w-3 rounded-[4px] bg-[#22D3EE]" />
            <span>Больше</span>
          </div>
        </div>
        <div className="grid shrink-0 grid-cols-3 gap-6 lg:grid-cols-1 lg:gap-4">
          <div className="flex items-center gap-3">
            <BookOpen className="h-5 w-5 text-[#7C5CFF]" />
            <div>
              <div className="font-display text-xl font-bold">{totalCompletedLessons}</div>
              <div className="text-[12px] text-[#5C6B84]">уроков пройдено</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Clock className="h-5 w-5 text-[#22D3EE]" />
            <div>
              <div className="font-display text-xl font-bold">{Math.round((totalCompletedLessons * 15) / 60)}</div>
              <div className="text-[12px] text-[#5C6B84]">часов обучения</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <CalendarDays className="h-5 w-5 text-[#FBBF24]" />
            <div>
              <div className="font-display text-xl font-bold">{streak}</div>
              <div className="text-[12px] text-[#5C6B84]">дней стрик</div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* 6. Сертификаты */}
      <div className="mt-12 flex items-end justify-between">
        <motion.h2 {...rise(0)} className="font-display text-2xl font-bold">
          Сертификаты
        </motion.h2>
        <Link to="/certificates" className="group flex items-center gap-1.5 text-sm font-medium text-[#22D3EE]">
          Все сертификаты
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
        </Link>
      </div>
      {(certs.data ?? []).length === 0 ? (
        <motion.div {...rise(0.05)} className="mt-6 rounded-[20px] glass p-8 text-center text-sm text-[#9AA6BC]">
          Завершите курс на 100% — и сертификат появится здесь.
        </motion.div>
      ) : (
        <div className="mt-6 grid gap-5 md:grid-cols-2">
          {(certs.data ?? []).slice(0, 2).map((cert, i) => (
            <motion.div
              key={cert.id}
              {...rise(0.05 + i * 0.1)}
              whileHover={{ rotate: -1, y: -4 }}
              className="overflow-hidden rounded-[20px] glass"
            >
              <img src="/certificate-template.png" alt="Сертификат" className="aspect-[16/10] w-full object-cover" />
              <div className="flex items-center justify-between gap-3 p-5">
                <div className="min-w-0">
                  <div className="truncate font-semibold">{cert.course?.title}</div>
                  <div className="text-[13px] text-[#5C6B84]">
                    {new Date(cert.issuedAt).toLocaleDateString('ru-RU')} · № {cert.verifyCode}
                  </div>
                </div>
                <Link to="/certificates" className="btn-ghost shrink-0 !px-4 !py-2 text-[13px]">
                  <FileDown className="h-4 w-4" /> Открыть
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}
