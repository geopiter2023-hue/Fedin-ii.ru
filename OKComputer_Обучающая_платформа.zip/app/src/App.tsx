import { Routes, Route } from 'react-router-dom'
import Layout from '@/components/Layout'
import Home from '@/pages/Home'
import Courses from '@/pages/Courses'
import CourseDetail from '@/pages/CourseDetail'
import Shop from '@/pages/Shop'
import ProductDetail from '@/pages/ProductDetail'
import Intensive from '@/pages/Intensive'
import Club from '@/pages/Club'
import Blog from '@/pages/Blog'
import BlogPost from '@/pages/BlogPost'
import Partners from '@/pages/Partners'
import About from '@/pages/About'
import Dashboard from '@/pages/Dashboard'
import Lesson from '@/pages/Lesson'
import Certificates from '@/pages/Certificates'
import Verify from '@/pages/Verify'
import Login from '@/pages/Login'
import NotFound from '@/pages/NotFound'

export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/courses/:id" element={<CourseDetail />} />
        <Route path="/shop" element={<Shop />} />
        <Route path="/shop/:id" element={<ProductDetail />} />
        <Route path="/intensive" element={<Intensive />} />
        <Route path="/club" element={<Club />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/blog/:id" element={<BlogPost />} />
        <Route path="/partners" element={<Partners />} />
        <Route path="/about" element={<About />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/lesson/:id" element={<Lesson />} />
        <Route path="/certificates" element={<Certificates />} />
        <Route path="/verify/:id" element={<Verify />} />
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Layout>
  )
}
