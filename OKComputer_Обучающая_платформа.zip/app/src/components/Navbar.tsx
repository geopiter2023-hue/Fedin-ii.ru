import { useEffect, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import { Menu, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAuth } from '@/hooks/useAuth'
import { LOGIN_PATH } from '@/const'

const NAV_LINKS = [
  { to: '/courses', label: 'Курсы' },
  { to: '/shop', label: 'Магазин' },
  { to: '/intensive', label: 'Интенсив' },
  { to: '/club', label: 'Нейроклуб' },
  { to: '/blog', label: 'Блог' },
  { to: '/partners', label: 'Партнёрам' },
  { to: '/about', label: 'Об эксперте' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const location = useLocation()
  const { user, isAuthenticated, isLoading, logout } = useAuth()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    setOpen(false)
  }, [location.pathname])

  return (
    <>
      <header
        className={cn(
          'fixed inset-x-0 top-0 z-50 h-[72px] transition-all duration-300',
          scrolled ? 'glass shadow-[0_8px_40px_rgba(0,0,0,0.45)]' : 'bg-transparent'
        )}
      >
        <div className="mx-auto flex h-full max-w-[1280px] items-center justify-between px-6">
          <Link to="/" className="flex items-center gap-2" aria-label="FEDIN AI — на главную">
            <img src="/logo.svg" alt="FEDIN AI" className="h-8 w-auto" />
          </Link>

          <nav className="hidden items-center gap-7 lg:flex">
            {NAV_LINKS.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                className={({ isActive }) =>
                  cn(
                    'group relative text-[14px] font-medium transition-colors',
                    isActive ? 'text-[#F2F5FA]' : 'text-[#9AA6BC] hover:text-[#F2F5FA]'
                  )
                }
              >
                {l.label}
                <span className="absolute -bottom-1.5 left-0 h-px w-0 bg-brand-gradient transition-all duration-250 group-hover:w-full" />
              </NavLink>
            ))}
          </nav>

          <div className="hidden items-center gap-3 lg:flex">
            {isLoading ? (
              <div className="h-9 w-20 animate-pulse rounded-[14px] bg-white/5" />
            ) : isAuthenticated && user ? (
              <div className="flex items-center gap-3">
                <span className="chip-xp">⚡ 2 450 XP</span>
                <div className="group relative">
                  <button className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-[#7C5CFF] to-[#22D3EE] text-[13px] font-bold text-white">
                    {(user.name ?? 'U').slice(0, 1).toUpperCase()}
                  </button>
                  <div className="invisible absolute right-0 top-full mt-2 w-48 rounded-2xl border border-white/10 bg-[#0D1117]/95 p-2 opacity-0 backdrop-blur-xl transition-all group-hover:visible group-hover:opacity-100">
                    <Link to="/dashboard" className="block rounded-xl px-4 py-2.5 text-sm text-[#F2F5FA] hover:bg-white/5">Кабинет</Link>
                    <Link to="/certificates" className="block rounded-xl px-4 py-2.5 text-sm text-[#F2F5FA] hover:bg-white/5">Сертификаты</Link>
                    <Link to="/partners" className="block rounded-xl px-4 py-2.5 text-sm text-[#F2F5FA] hover:bg-white/5">Партнёрка</Link>
                    <button onClick={() => logout()} className="block w-full rounded-xl px-4 py-2.5 text-left text-sm text-[#9AA6BC] hover:bg-white/5">Выйти</button>
                  </div>
                </div>
              </div>
            ) : (
              <Link to={LOGIN_PATH} className="btn-ghost px-5 py-2.5 text-[14px]">
                Войти
              </Link>
            )}
            <Link to="/intensive" className="btn-primary px-5 py-2.5 text-[14px]">
              Начать бесплатно
            </Link>
          </div>

          <button
            className="flex h-10 w-10 items-center justify-center rounded-xl glass-light lg:hidden"
            onClick={() => setOpen(true)}
            aria-label="Открыть меню"
          >
            <Menu className="h-5 w-5" />
          </button>
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.28 }}
            className="fixed inset-0 z-[60] bg-[#07090F]/95 backdrop-blur-xl lg:hidden"
          >
            <div className="flex h-[72px] items-center justify-between px-6">
              <img src="/logo.svg" alt="FEDIN AI" className="h-8 w-auto" />
              <button
                className="flex h-10 w-10 items-center justify-center rounded-xl glass-light"
                onClick={() => setOpen(false)}
                aria-label="Закрыть меню"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="flex flex-col gap-2 px-6 pt-8">
              {NAV_LINKS.map((l, i) => (
                <motion.div
                  key={l.to}
                  initial={{ opacity: 0, x: 24 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 * i, duration: 0.3 }}
                >
                  <Link
                    to={l.to}
                    className="block rounded-2xl px-4 py-3.5 font-display text-xl text-[#F2F5FA] hover:bg-white/5"
                  >
                    {l.label}
                  </Link>
                </motion.div>
              ))}
              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="mt-6 flex flex-col gap-3 px-4"
              >
                {isAuthenticated && user ? (
                  <>
                    <Link to="/dashboard" className="btn-ghost w-full">Кабинет</Link>
                    <button onClick={() => logout()} className="btn-ghost w-full">Выйти</button>
                  </>
                ) : (
                  <Link to={LOGIN_PATH} className="btn-ghost w-full">
                    Войти
                  </Link>
                )}
                <Link to="/intensive" className="btn-primary w-full">
                  Начать бесплатно
                </Link>
              </motion.div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
