import { useMemo, useRef } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'

const COUNT = 250
const BOUNDS = { x: 16, y: 9, z: 4 }
const LINK_DIST = 2.2

function Neurons() {
  const pointsRef = useRef<THREE.Points>(null)
  const linesRef = useRef<THREE.LineSegments>(null)
  const { pointer } = useThree()

  const data = useMemo(() => {
    const base = new Float32Array(COUNT * 3)
    const disp = new Float32Array(COUNT * 3)
    const phase = new Float32Array(COUNT)
    const colors = new Float32Array(COUNT * 3)
    const violet = new THREE.Color('#7C5CFF')
    const cyan = new THREE.Color('#22D3EE')
    for (let i = 0; i < COUNT; i++) {
      base[i * 3] = (Math.random() - 0.5) * 2 * BOUNDS.x
      base[i * 3 + 1] = (Math.random() - 0.5) * 2 * BOUNDS.y
      base[i * 3 + 2] = (Math.random() - 0.5) * 2 * BOUNDS.z
      phase[i] = Math.random() * Math.PI * 2
      const c = Math.random() > 0.5 ? violet : cyan
      colors[i * 3] = c.r
      colors[i * 3 + 1] = c.g
      colors[i * 3 + 2] = c.b
    }
    return { base, disp, phase, colors }
  }, [])

  const lineGeom = useMemo(() => new THREE.BufferGeometry(), [])
  const linePos = useMemo(() => new Float32Array(COUNT * COUNT * 3), [])

  useFrame(({ clock }) => {
    const t = clock.elapsedTime
    const pts = pointsRef.current
    if (!pts) return
    const pos = (pts.geometry.attributes.position as THREE.BufferAttribute).array as Float32Array
    const mx = pointer.x * BOUNDS.x
    const my = pointer.y * BOUNDS.y

    for (let i = 0; i < COUNT; i++) {
      const ix = i * 3
      const bx = data.base[ix] + Math.sin(t * 0.3 + data.phase[i]) * 0.6
      const by = data.base[ix + 1] + Math.cos(t * 0.24 + data.phase[i] * 1.3) * 0.5
      const bz = data.base[ix + 2]
      // cursor repel via separate displacement with lerp decay
      const dx = bx + data.disp[ix] - mx
      const dy = by + data.disp[ix + 1] - my
      const d2 = dx * dx + dy * dy
      if (d2 < 9) {
        const d = Math.sqrt(d2) || 0.001
        const f = ((3 - d) / 3) * 0.12
        data.disp[ix] += (dx / d) * f
        data.disp[ix + 1] += (dy / d) * f
      }
      data.disp[ix] *= 0.95
      data.disp[ix + 1] *= 0.95
      data.disp[ix + 2] *= 0.95
      pos[ix] = bx + data.disp[ix]
      pos[ix + 1] = by + data.disp[ix + 1]
      pos[ix + 2] = bz + data.disp[ix + 2]
    }
    pts.geometry.attributes.position.needsUpdate = true

    // rebuild link lines
    let n = 0
    for (let i = 0; i < COUNT; i++) {
      for (let j = i + 1; j < COUNT; j++) {
        const ax = pos[i * 3], ay = pos[i * 3 + 1], az = pos[i * 3 + 2]
        const bx = pos[j * 3], by = pos[j * 3 + 1], bz = pos[j * 3 + 2]
        const dx = ax - bx, dy = ay - by, dz = az - bz
        if (dx * dx + dy * dy + dz * dz < LINK_DIST * LINK_DIST && n < linePos.length - 6) {
          linePos[n++] = ax; linePos[n++] = ay; linePos[n++] = az
          linePos[n++] = bx; linePos[n++] = by; linePos[n++] = bz
        }
      }
    }
    lineGeom.setAttribute('position', new THREE.BufferAttribute(linePos.subarray(0, n), 3))
  })

  return (
    <>
      <points ref={pointsRef}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[data.base.slice(), 3]} />
          <bufferAttribute attach="attributes-color" args={[data.colors, 3]} />
        </bufferGeometry>
        <pointsMaterial size={0.09} vertexColors transparent opacity={0.9} sizeAttenuation depthWrite={false} />
      </points>
      <lineSegments ref={linesRef} geometry={lineGeom}>
        <lineBasicMaterial color="#5b6cff" transparent opacity={0.18} depthWrite={false} />
      </lineSegments>
    </>
  )
}

export default function NeuralCanvas() {
  return (
    <Canvas
      style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}
      camera={{ position: [0, 0, 12], fov: 55 }}
      dpr={[1, 1.5]}
      gl={{ antialias: true, alpha: true }}
    >
      <Neurons />
    </Canvas>
  )
}
