import { Link } from 'react-router-dom'
import { Send, Youtube, Play, Users } from 'lucide-react'

const COLS = [
  {
    title: 'Обучение',
    links: [
      { to: '/courses/neuro-work', label: 'Нейросети для работы' },
      { to: '/courses/neuro-content', label: 'Нейросети для контента' },
      { to: '/courses/neuro-marketing', label: 'Маркетинг и ИИ-агенты' },
      { to: '/courses/vibe-coding', label: 'Вайб-кодинг' },
      { to: '/courses/marketplace-cards', label: 'ИИ-карточки для маркетплейсов' },
      { to: '/intensive', label: 'Бесплатный интенсив' },
    ],
  },
  {
    title: 'Платформа',
    links: [
      { to: '/shop', label: 'Магазин' },
      { to: '/club', label: 'Нейроклуб' },
      { to: '/partners', label: 'Партнёрам' },
      { to: '/blog', label: 'Блог' },
      { to: '/certificates', label: 'Сертификаты' },
    ],
  },
  {
    title: 'Информация',
    links: [
      { to: '/about', label: 'Об эксперте' },
      { to: '/about', label: 'Контакты' },
      { to: '/about', label: 'Оферта' },
      { to: '/about', label: 'Политика конфиденциальности' },
    ],
  },
]

const SOCIALS = [
  { icon: Send, label: 'Telegram' },
  { icon: Users, label: 'VK' },
  { icon: Youtube, label: 'YouTube' },
  { icon: Play, label: 'Rutube' },
]

export default function Footer() {
  return (
    <footer className="relative bg-[#07090F]">
      <div className="h-px w-full bg-gradient-to-r from-transparent via-[#7C5CFF] to-transparent opacity-60" />
      <div className="mx-auto max-w-[1280px] px-6 py-16">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <img src="/logo.svg" alt="FEDIN AI" className="h-9 w-auto" />
            <p className="mt-4 max-w-xs text-sm text-[#9AA6BC]">
              Нейросети — просто, практично, по-русски. Практическое обучение без VPN и зарубежных карт.
            </p>
            <div className="mt-6 flex gap-3">
              {SOCIALS.map((s) => (
                <a
                  key={s.label}
                  href="#"
                  aria-label={s.label}
                  className="flex h-10 w-10 items-center justify-center rounded-xl glass-light text-[#9AA6BC] transition-colors hover:text-[#22D3EE]"
                >
                  <s.icon className="h-4.5 w-4.5" />
                </a>
              ))}
            </div>
          </div>
          {COLS.map((col) => (
            <div key={col.title}>
              <h4 className="font-display text-sm font-bold uppercase tracking-wider text-[#F2F5FA]">
                {col.title}
              </h4>
              <ul className="mt-5 space-y-3">
                {col.links.map((l, i) => (
                  <li key={i}>
                    <Link to={l.to} className="text-sm text-[#9AA6BC] transition-colors hover:text-[#F2F5FA]">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-white/[0.08] pt-8 text-[13px] text-[#5C6B84] md:flex-row">
          <span>© 2025 FEDIN AI · fedin-ii.ru</span>
          <span className="font-mono2">Оплата: карты МИР, Visa/MC · СБП · Рассрочка</span>
        </div>
      </div>
    </footer>
  )
}
