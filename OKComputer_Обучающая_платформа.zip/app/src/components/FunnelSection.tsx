import { useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useGSAP } from '@gsap/react'
import { Link } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'

gsap.registerPlugin(ScrollTrigger, useGSAP)

const STEPS = [
  {
    price: 'Бесплатно',
    title: 'Интенсив «Нейросети за 3 дня»',
    desc: '3 урока, первый результат за вечер. Без карты и обязательств.',
    tag: '0 ₽',
    to: '/intensive',
    cta: 'Забрать интенсив',
  },
  {
    price: '990 ₽',
    title: 'Tripwire: промпт-пак под профессию',
    desc: 'Маркетолог, HR, риелтор, юрист, преподаватель — готовые промпты под вашу задачу.',
    tag: '990 ₽',
    to: '/shop',
    cta: 'Выбрать пак',
  },
  {
    price: 'от 14 900 ₽',
    title: 'Основной курс',
    desc: 'Система, практика на реальных задачах, сертификат и разборы домашних заданий.',
    tag: 'Курс',
    to: '/courses',
    cta: 'Смотреть курсы',
  },
  {
    price: '990 ₽/мес',
    title: 'Нейроклуб',
    desc: 'Обновления всех курсов, новый промпт-пак ежемесячно, закрытое комьюнити.',
    tag: 'Клуб',
    to: '/club',
    cta: 'Вступить',
  },
]

export default function FunnelSection() {
  const root = useRef<HTMLDivElement>(null)

  useGSAP(
    () => {
      const steps = gsap.utils.toArray<HTMLElement>('.funnel-step')
      const line = root.current!.querySelector<HTMLElement>('.funnel-line-fill')!
      const pulse = root.current!.querySelector<HTMLElement>('.funnel-pulse')!

      gsap.set(steps, { opacity: 0.4, scale: 0.96 })
      gsap.set(steps[0], { opacity: 1, scale: 1 })

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: root.current,
          start: 'top top',
          end: '+=200%',
          pin: true,
          scrub: 0.6,
        },
      })

      tl.to(line, { scaleY: 1, ease: 'none', duration: 3 }, 0)
      tl.to(pulse, { top: '100%', ease: 'none', duration: 3 }, 0)
      steps.forEach((step, i) => {
        if (i === 0) return
        tl.to(steps[i - 1], { opacity: 0.4, scale: 0.96, duration: 0.3 }, i * 0.75)
        tl.to(step, { opacity: 1, scale: 1, duration: 0.3 }, i * 0.75)
      })
    },
    { scope: root }
  )

  return (
    <section ref={root} className="relative overflow-hidden bg-[#0D1117] py-24">
      <div className="pointer-events-none absolute -left-40 top-1/3 h-[600px] w-[600px] glow-violet" />
      <div className="mx-auto grid max-w-[1280px] gap-16 px-6 lg:grid-cols-[1fr_1.2fr]">
        <div className="lg:sticky lg:top-32 lg:self-start">
          <span className="chip glass-light text-[#22D3EE]">Как это работает</span>
          <h2 className="mt-6 font-display text-3xl font-bold md:text-[44px] md:leading-[1.1]">
            Путь ученика <span className="text-gradient">FEDIN AI</span>
          </h2>
          <p className="mt-5 max-w-md text-lg text-[#9AA6BC]">
            Четыре ступени — от первого бесплатного урока до закрытого клуба практиков. Начните с нуля и растите в своём темпе.
          </p>
        </div>

        <div className="relative pl-10">
          <div className="absolute bottom-4 left-2 top-4 w-px bg-white/10">
            <div className="funnel-line-fill h-full w-full origin-top scale-y-0 bg-brand-gradient" />
            <div className="funnel-pulse absolute -left-[5px] top-0 h-[11px] w-[11px] rounded-full bg-[#22D3EE] shadow-[0_0_16px_rgba(34,211,238,0.9)]" />
          </div>
          <div className="space-y-8">
            {STEPS.map((s, i) => (
              <div key={i} className="funnel-step gradient-border rounded-[20px] p-7">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-brand-gradient font-display text-lg font-bold text-white">
                    {i + 1}
                  </div>
                  <span className="font-display text-xl font-bold text-gradient">{s.price}</span>
                </div>
                <h3 className="mt-4 font-display text-lg font-bold">{s.title}</h3>
                <p className="mt-2 text-[15px] text-[#9AA6BC]">{s.desc}</p>
                <Link
                  to={s.to}
                  className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-[#22D3EE] transition-all hover:gap-2.5"
                >
                  {s.cta} <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
