import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { localUsers } from "@db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";

const JWT_SECRET = new TextEncoder().encode(
  process.env.APP_SECRET || "neuro-university-secret-key-2025"
);

async function createToken(userId: number, email: string, role: string) {
  return new SignJWT({ userId, email, role, type: "local" })
    .setProtectedHeader({ alg: "HS256" })
    .setExpirationTime("30d")
    .sign(JWT_SECRET);
}

export async function verifyLocalToken(token: string) {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET, { clockTolerance: 60 });
    return payload as { userId: number; email: string; role: string };
  } catch {
    return null;
  }
}

export const localAuthRouter = createRouter({
  // Register
  register: publicQuery
    .input(
      z.object({
        email: z.string().email("Некорректный email"),
        password: z.string().min(6, "Минимум 6 символов"),
        name: z.string().min(1, "Введите имя"),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Check if email exists
      const [existing] = await db
        .select()
        .from(localUsers)
        .where(eq(localUsers.email, input.email));

      if (existing) {
        return { success: false, error: "Email уже зарегистрирован" };
      }

      // Hash password
      const passwordHash = await bcrypt.hash(input.password, 10);

      // Create user
      const [newUser] = await db
        .insert(localUsers)
        .values({
          email: input.email,
          passwordHash,
          name: input.name,
        })
        .$returningId();

      // Generate token
      const token = await createToken(newUser.id, input.email, "user");

      return {
        success: true,
        token,
        user: { id: newUser.id, email: input.email, name: input.name },
      };
    }),

  // Login
  login: publicQuery
    .input(
      z.object({
        email: z.string().email(),
        password: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      const [user] = await db
        .select()
        .from(localUsers)
        .where(eq(localUsers.email, input.email));

      if (!user) {
        return { success: false, error: "Неверный email или пароль" };
      }

      const valid = await bcrypt.compare(input.password, user.passwordHash);
      if (!valid) {
        return { success: false, error: "Неверный email или пароль" };
      }

      const token = await createToken(user.id, user.email, user.role);

      return {
        success: true,
        token,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
        },
      };
    }),

  // Get current user from token
  me: publicQuery.query(async ({ ctx }) => {
    const authHeader = ctx.req.headers.get("x-local-auth-token");
    if (!authHeader) return null;

    const payload = await verifyLocalToken(authHeader);
    if (!payload) return null;

    const db = getDb();
    const [user] = await db
      .select()
      .from(localUsers)
      .where(eq(localUsers.id, payload.userId));

    if (!user) return null;

    return {
      id: user.id,
      email: user.email,
      name: user.name,
      avatar: user.avatar,
      role: user.role,
    };
  }),
});
