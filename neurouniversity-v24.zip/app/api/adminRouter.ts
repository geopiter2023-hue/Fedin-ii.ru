import { z } from "zod";
import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  courses,
  lessons,
  users,
  localUsers,
  purchases,
  accessKeys,
  reviews,
  emailSubscriptions,
  aiNews,
} from "@db/schema";
import { eq, desc, sql, count } from "drizzle-orm";

export const adminRouter = createRouter({
  // ===== DASHBOARD STATS =====
  stats: adminQuery.query(async () => {
    const db = getDb();
    const [courseCount] = await db.select({ count: count() }).from(courses);
    const [userCount] = await db.select({ count: count() }).from(users);
    const [localUserCount] = await db.select({ count: count() }).from(localUsers);
    const [purchaseCount] = await db.select({ count: count() }).from(purchases);
    const [lessonCount] = await db.select({ count: count() }).from(lessons);
    const [reviewCount] = await db.select({ count: count() }).from(reviews);
    const [keyCount] = await db.select({ count: count() }).from(accessKeys);
    const [emailCount] = await db.select({ count: count() }).from(emailSubscriptions);
    const [newsCount] = await db.select({ count: count() }).from(aiNews);

    return {
      courses: courseCount.count,
      users: userCount.count + localUserCount.count,
      purchases: purchaseCount.count,
      lessons: lessonCount.count,
      reviews: reviewCount.count,
      keys: keyCount.count,
      emails: emailCount.count,
      news: newsCount.count,
    };
  }),

  // ===== COURSES CRUD =====
  courseList: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(courses).orderBy(desc(courses.createdAt));
  }),

  courseCreate: adminQuery
    .input(
      z.object({
        title: z.string().min(1),
        slug: z.string().min(1),
        description: z.string(),
        fullDescription: z.string().optional(),
        image: z.string().optional(),
        price: z.string().default("0"),
        oldPrice: z.string().optional(),
        lessonsCount: z.number().default(0),
        duration: z.string().default("12 часов"),
        level: z.enum(["beginner", "intermediate", "advanced"]).default("beginner"),
        category: z.string().default("База"),
        isPublished: z.boolean().default(true),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(courses).values(input).$returningId();
      return { id: result.id, success: true };
    }),

  courseUpdate: adminQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        fullDescription: z.string().optional(),
        price: z.string().optional(),
        oldPrice: z.string().optional(),
        isPublished: z.boolean().optional(),
        level: z.enum(["beginner", "intermediate", "advanced"]).optional(),
        category: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(courses).set(data).where(eq(courses.id, id));
      return { success: true };
    }),

  courseDelete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(courses).where(eq(courses.id, input.id));
      return { success: true };
    }),

  // ===== LESSONS CRUD =====
  lessonList: adminQuery
    .input(z.object({ courseId: z.number() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      if (input?.courseId) {
        return db
          .select()
          .from(lessons)
          .where(eq(lessons.courseId, input.courseId))
          .orderBy(lessons.order);
      }
      return db.select().from(lessons).orderBy(desc(lessons.createdAt));
    }),

  lessonCreate: adminQuery
    .input(
      z.object({
        courseId: z.number(),
        title: z.string().min(1),
        description: z.string().optional(),
        content: z.string().default(""),
        duration: z.string().default("30:00"),
        order: z.number().default(1),
        isFree: z.boolean().default(false),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [result] = await db.insert(lessons).values(input).$returningId();
      return { id: result.id, success: true };
    }),

  lessonUpdate: adminQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        content: z.string().optional(),
        duration: z.string().optional(),
        order: z.number().optional(),
        isFree: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(lessons).set(data).where(eq(lessons.id, id));
      return { success: true };
    }),

  lessonDelete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(lessons).where(eq(lessons.id, input.id));
      return { success: true };
    }),

  // ===== USERS =====
  userList: adminQuery.query(async () => {
    const db = getDb();
    const oauthUsers = await db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        role: users.role,
        createdAt: users.createdAt,
        source: sql<string>`'oauth'`,
      })
      .from(users)
      .orderBy(desc(users.createdAt));

    const local = await db
      .select({
        id: localUsers.id,
        name: localUsers.name,
        email: localUsers.email,
        role: localUsers.role,
        createdAt: localUsers.createdAt,
        source: sql<string>`'local'`,
      })
      .from(localUsers)
      .orderBy(desc(localUsers.createdAt));

    return [...oauthUsers, ...local];
  }),

  userUpdateRole: adminQuery
    .input(z.object({ id: z.number(), role: z.enum(["user", "admin"]), source: z.enum(["oauth", "local"]) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      if (input.source === "oauth") {
        await db.update(users).set({ role: input.role }).where(eq(users.id, input.id));
      } else {
        await db.update(localUsers).set({ role: input.role }).where(eq(localUsers.id, input.id));
      }
      return { success: true };
    }),

  // ===== ACCESS KEYS =====
  keyList: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(accessKeys).orderBy(desc(accessKeys.createdAt));
  }),

  keyCreate: adminQuery
    .input(
      z.object({
        code: z.string().min(3),
        type: z.enum(["test", "promo", "lifetime"]),
        courseId: z.number().optional(),
        maxUses: z.number().default(1),
        expiresAt: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(accessKeys).values({
        code: input.code.toUpperCase(),
        type: input.type,
        courseId: input.courseId || null,
        maxUses: input.maxUses,
        expiresAt: input.expiresAt ? new Date(input.expiresAt) : null,
      });
      return { success: true };
    }),

  keyDelete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.update(accessKeys).set({ isActive: false }).where(eq(accessKeys.id, input.id));
      return { success: true };
    }),

  // ===== REVIEWS =====
  reviewList: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(reviews).orderBy(desc(reviews.createdAt));
  }),

  reviewDelete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(reviews).where(eq(reviews.id, input.id));
      return { success: true };
    }),

  // ===== EMAIL SUBSCRIPTIONS =====
  emailList: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(emailSubscriptions).orderBy(desc(emailSubscriptions.createdAt));
  }),

  // ===== AI GENERATE LESSON CONTENT =====
  aiGenerateLesson: adminQuery
    .input(
      z.object({
        title: z.string().min(1),
        model: z.string().default("deepseek"),
      })
    )
    .mutation(async ({ input }) => {
      const apiKey = process.env.OPENROUTER_API_KEY;
      if (!apiKey) {
        return { success: false, error: "API ключ не настроен", content: "" };
      }

      try {
        const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${apiKey}`,
            "Content-Type": "application/json",
            "HTTP-Referer": "https://neurouniversity.ru",
            "X-Title": "NeuroUniversity",
          },
          body: JSON.stringify({
            model: "deepseek/deepseek-chat-v3-0324:free",
            messages: [
              {
                role: "system",
                content:
                  "Ты — эксперт по образовательному контенту. Напиши подробный урок на русском языке в формате Markdown. Урок должен включать: введение, основную часть с подзаголовками, практические примеры, сравнительные таблицы, чек-листы, домашнее задание. Стиль: профессиональный, но доступный для обычных людей. Без воды, только полезная информация.",
              },
              {
                role: "user",
                content: `Напиши подробный урок на тему: "${input.title}". Объем: 2000-3000 слов.`,
              },
            ],
            temperature: 0.7,
            max_tokens: 4000,
          }),
        });

        const data = await response.json() as { choices?: [{ message?: { content?: string } }] };
        const content = data.choices?.[0]?.message?.content || "";

        return { success: true, content };
      } catch {
        return { success: false, error: "Ошибка генерации", content: "" };
      }
    }),

  // ===== BULK OPEN ALL COURSES FOR TESTING =====
  openAllCourses: adminQuery.mutation(async () => {
    const db = getDb();
    await db.update(courses).set({ isPublished: true });
    return { success: true };
  }),

  // ===== RSS NEWS MANAGEMENT =====
  newsList: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(aiNews).orderBy(desc(aiNews.publishedAt));
  }),

  newsDelete: adminQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(aiNews).where(eq(aiNews.id, input.id));
      return { success: true };
    }),
});
