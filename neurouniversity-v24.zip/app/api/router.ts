import { authRouter } from "./auth-router";
import { localAuthRouter } from "./localAuthRouter";
import { courseRouter } from "./courseRouter";
import { lessonRouter } from "./lessonRouter";
import { purchaseRouter } from "./purchaseRouter";
import { userRouter } from "./userRouter";
import { seedRouter } from "./seedRouter";
import { aiRouter } from "./aiRouter";
import { certificateRouter } from "./certificateRouter";
import { reviewRouter } from "./reviewRouter";
import { referralRouter } from "./referralRouter";
import { emailRouter } from "./emailRouter";
import { accessKeyRouter } from "./accessKeyRouter";
import { rssRouter } from "./rssRouter";
import { adminRouter } from "./adminRouter";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  localAuth: localAuthRouter,
  course: courseRouter,
  lesson: lessonRouter,
  purchase: purchaseRouter,
  user: userRouter,
  seed: seedRouter,
  ai: aiRouter,
  certificate: certificateRouter,
  review: reviewRouter,
  referral: referralRouter,
  email: emailRouter,
  accessKey: accessKeyRouter,
  rss: rssRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
