import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { purchases, courses, unlockedCourses, accessKeys } from "@db/schema";
import { eq, and, isNull, or, gt } from "drizzle-orm";

// Generate unique access key
function generateKey(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let result = "NU";
  for (let i = 0; i < 10; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export const purchaseRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userPurchases = await db
      .select({
        id: purchases.id,
        courseId: purchases.courseId,
        amount: purchases.amount,
        status: purchases.status,
        createdAt: purchases.createdAt,
        courseTitle: courses.title,
        courseSlug: courses.slug,
        courseImage: courses.image,
        courseLessonsCount: courses.lessonsCount,
      })
      .from(purchases)
      .innerJoin(courses, eq(purchases.courseId, courses.id))
      .where(
        and(
          eq(purchases.userId, ctx.user.id),
          eq(purchases.status, "completed")
        )
      );
    return userPurchases;
  }),

  getByCourse: authedQuery
    .input(z.object({ courseId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const [purchase] = await db
        .select()
        .from(purchases)
        .where(
          and(
            eq(purchases.userId, ctx.user.id),
            eq(purchases.courseId, input.courseId)
          )
        );
      return purchase || null;
    }),

  create: authedQuery
    .input(z.object({ courseId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [course] = await db
        .select()
        .from(courses)
        .where(eq(courses.id, input.courseId));

      if (!course) {
        throw new Error("Course not found");
      }

      const existing = await db
        .select()
        .from(purchases)
        .where(
          and(
            eq(purchases.userId, ctx.user.id),
            eq(purchases.courseId, input.courseId)
          )
        );

      if (existing.length > 0) {
        return { purchase: existing[0], accessKey: null };
      }

      // Create purchase
      const [newPurchase] = await db
        .insert(purchases)
        .values({
          userId: ctx.user.id,
          courseId: input.courseId,
          amount: course.price,
          status: "completed",
        })
        .$returningId();

      // Generate access key for this purchase
      const keyCode = generateKey();
      await db.insert(accessKeys).values({
        code: keyCode,
        type: "lifetime",
        courseId: input.courseId,
        maxUses: 1,
        usesCount: 1,
      });

      // Unlock course for user
      await db.insert(unlockedCourses).values({
        userId: ctx.user.id,
        courseId: input.courseId,
        unlockedAt: new Date(),
      });

      const purchase = await db.query.purchases.findFirst({
        where: eq(purchases.id, newPurchase.id),
      });

      return { purchase, accessKey: keyCode };
    }),

  checkAccess: authedQuery
    .input(z.object({ courseId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();

      // Check purchase
      const [purchase] = await db
        .select()
        .from(purchases)
        .where(
          and(
            eq(purchases.userId, ctx.user.id),
            eq(purchases.courseId, input.courseId),
            eq(purchases.status, "completed")
          )
        );

      if (purchase) return true;

      // Check unlocked via key (not expired)
      const [unlocked] = await db
        .select()
        .from(unlockedCourses)
        .where(
          and(
            eq(unlockedCourses.userId, ctx.user.id),
            eq(unlockedCourses.courseId, input.courseId),
            or(
              isNull(unlockedCourses.expiresAt),
              gt(unlockedCourses.expiresAt, new Date())
            )
          )
        );

      return !!unlocked;
    }),
});
