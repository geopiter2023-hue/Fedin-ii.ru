import type { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";
import type { User } from "@db/schema";
import { authenticateRequest } from "./kimi/auth";
import { verifyLocalToken } from "./localAuthRouter";
import { getDb } from "./queries/connection";
import { localUsers } from "@db/schema";
import { eq } from "drizzle-orm";

export type TrpcContext = {
  req: Request;
  resHeaders: Headers;
  user?: User;
};

export async function createContext(
  opts: FetchCreateContextFnOptions,
): Promise<TrpcContext> {
  const ctx: TrpcContext = { req: opts.req, resHeaders: opts.resHeaders };

  // Try OAuth (Kimi) first
  try {
    ctx.user = await authenticateRequest(opts.req.headers);
  } catch {
    // OAuth not available, try local auth
  }

  // Try local auth if OAuth didn't work
  if (!ctx.user) {
    try {
      const localToken = opts.req.headers.get("x-local-auth-token");
      if (localToken) {
        const payload = await verifyLocalToken(localToken);
        if (payload) {
          const db = getDb();
          const [localUser] = await db
            .select()
            .from(localUsers)
            .where(eq(localUsers.id, payload.userId));
          if (localUser) {
            // Map localUser to User shape for compatibility
            ctx.user = {
              id: localUser.id,
              unionId: `local_${localUser.id}`,
              name: localUser.name,
              email: localUser.email,
              avatar: localUser.avatar,
              role: localUser.role,
              createdAt: localUser.createdAt,
              updatedAt: localUser.updatedAt,
            } as User;
          }
        }
      }
    } catch {
      // Local auth not available
    }
  }

  return ctx;
}
