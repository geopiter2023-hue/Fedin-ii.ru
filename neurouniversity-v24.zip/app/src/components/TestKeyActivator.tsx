import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Key, Check, AlertCircle, Info } from "lucide-react";

export default function TestKeyActivator() {
  const { isAuthenticated } = useAuth();
  const [code, setCode] = useState("");
  const [result, setResult] = useState<{
    success: boolean;
    message: string;
  } | null>(null);

  const activate = trpc.accessKey.activate.useMutation({
    onSuccess: (data) => {
      setResult({
        success: data.success,
        message: data.success
          ? data.message || "Курс разблокирован!"
          : data.error || "Ошибка активации",
      });
      if (data.success) setCode("");
    },
    onError: (err) => {
      setResult({ success: false, message: err.message });
    },
  });

  return (
    <Card className="bg-gradient-to-r from-purple-900/30 to-cyan-900/30 border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-lg text-white flex items-center gap-2">
          <Key size={20} className="text-purple-400" />
          Активировать ключ
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!isAuthenticated ? (
          <div className="text-center py-2">
            <p className="text-slate-400 text-sm">
              Войдите, чтобы активировать ключ доступа
            </p>
          </div>
        ) : (
          <>
            <div className="flex gap-2">
              <Input
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Введите ключ доступа"
                className="bg-slate-950 border-slate-600 text-white flex-1 uppercase"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && code.trim()) {
                    activate.mutate({ code: code.trim() });
                  }
                }}
              />
              <Button
                onClick={() => code.trim() && activate.mutate({ code: code.trim() })}
                disabled={!code.trim() || activate.isPending}
                className="bg-gradient-to-r from-purple-500 to-cyan-500 hover:from-purple-600 hover:to-cyan-600"
              >
                {activate.isPending ? "..." : <Key size={16} />}
              </Button>
            </div>

            {result && (
              <div
                className={`flex items-center gap-2 text-sm p-3 rounded-lg ${
                  result.success
                    ? "bg-green-500/10 text-green-400"
                    : "bg-red-500/10 text-red-400"
                }`}
              >
                {result.success ? <Check size={16} /> : <AlertCircle size={16} />}
                {result.message}
              </div>
            )}

            <div className="flex items-start gap-2 text-xs text-slate-500">
              <Info size={14} className="shrink-0 mt-0.5" />
              <p>
                У вас есть ключ? Введите его выше. Ключи можно получить при покупке
                курса или запросить в поддержке.
              </p>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
