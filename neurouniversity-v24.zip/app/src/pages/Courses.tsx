import { useState } from "react";
import { trpc } from "@/providers/trpc";
import Navbar from "@/components/Navbar";
import CourseCard from "@/components/CourseCard";
import { localCourses, categories, levels } from "@/lib/courseData";
import { Search, ArrowLeft } from "lucide-react";
import { Link } from "react-router";

const levelMap: Record<string, string> = {
  "Начинающий": "beginner",
  "Средний": "intermediate",
  "Продвинутый": "advanced",
};

export default function Courses() {
  const [activeCategory, setActiveCategory] = useState("Все");
  const [activeLevel, setActiveLevel] = useState("Все");
  const [search, setSearch] = useState("");

  const { data: apiCourses, isLoading } = trpc.course.list.useQuery({
    category: activeCategory === "Все" ? undefined : activeCategory,
    level: activeLevel === "Все" ? undefined : levelMap[activeLevel],
    search: search || undefined,
  });

  // Use API data if available, fallback to local data
  const courses = apiCourses ?? localCourses;

  return (
    <div className="min-h-screen bg-[#0A0A0F]">
      <Navbar />
      <div className="pt-24 pb-16 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Back button */}
          <Link to="/" className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-white transition-colors mb-4">
            <ArrowLeft className="w-4 h-4" />
            На главную
          </Link>

          {/* Header */}
          <div className="mb-10">
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
              Все <span className="gradient-text">курсы</span>
            </h1>
            <p className="text-slate-400">
              {courses?.length ?? 22} курса по нейросетям для любого уровня
            </p>
          </div>

          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
            <input
              type="text"
              placeholder="Поиск курсов..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-xl bg-[#12121A] border border-white/[0.06] text-white placeholder:text-slate-500 focus:outline-none focus:border-[#8B5CF6]/50 transition-colors"
            />
          </div>

          {/* Category filters */}
          <div className="flex flex-wrap gap-2 mb-4">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeCategory === cat
                    ? "bg-[#8B5CF6] text-white"
                    : "bg-[#12121A] text-slate-400 border border-white/[0.06] hover:text-white hover:border-white/10"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Level filters */}
          <div className="flex flex-wrap gap-2 mb-10">
            {levels.map((lvl) => (
              <button
                key={lvl}
                onClick={() => setActiveLevel(lvl)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeLevel === lvl
                    ? "bg-[#EC4899] text-white"
                    : "bg-[#12121A] text-slate-400 border border-white/[0.06] hover:text-white hover:border-white/10"
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>

          {/* Course grid */}
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 6 }).map((_, i) => (
                <div
                  key={i}
                  className="rounded-2xl bg-[#12121A] border border-white/[0.06] overflow-hidden animate-pulse"
                >
                  <div className="aspect-video bg-white/5" />
                  <div className="p-5 space-y-3">
                    <div className="h-5 bg-white/5 rounded w-3/4" />
                    <div className="h-4 bg-white/5 rounded w-full" />
                    <div className="h-4 bg-white/5 rounded w-2/3" />
                  </div>
                </div>
              ))}
            </div>
          ) : courses && courses.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {courses.map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <p className="text-slate-400 text-lg">Курсы не найдены</p>
              <p className="text-slate-600 text-sm mt-1">
                Попробуйте изменить параметры поиска
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
