import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  decimal,
  int,
  boolean,
  index,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const courses = mysqlTable(
  "courses",
  {
    id: serial("id").primaryKey(),
    slug: varchar("slug", { length: 255 }).notNull().unique(),
    title: varchar("title", { length: 255 }).notNull(),
    subtitle: varchar("subtitle", { length: 500 }),
    description: text("description"),
    longDescription: text("longDescription"),
    image: text("image"),
    level: mysqlEnum("level", ["beginner", "intermediate", "advanced"])
      .notNull()
      .default("beginner"),
    category: varchar("category", { length: 100 }).notNull(),
    price: decimal("price", { precision: 10, scale: 2 }).notNull(),
    oldPrice: decimal("oldPrice", { precision: 10, scale: 2 }),
    duration: varchar("duration", { length: 50 }),
    lessonsCount: int("lessonsCount").notNull().default(0),
    studentsCount: int("studentsCount").notNull().default(0),
    rating: decimal("rating", { precision: 2, scale: 1 }).default("5.0"),
    isPublished: boolean("isPublished").default(true),
    createdAt: timestamp("createdAt").defaultNow(),
    updatedAt: timestamp("updatedAt").defaultNow().$onUpdate(() => new Date()),
  },
  (table) => ({
    categoryIdx: index("category_idx").on(table.category),
    levelIdx: index("level_idx").on(table.level),
    slugIdx: index("slug_idx").on(table.slug),
  })
);

export type Course = typeof courses.$inferSelect;
export type InsertCourse = typeof courses.$inferInsert;

export const lessons = mysqlTable(
  "lessons",
  {
    id: serial("id").primaryKey(),
    courseId: bigint("courseId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => courses.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 255 }).notNull(),
    description: text("description"),
    videoUrl: text("videoUrl"),
    content: text("content"),
    duration: varchar("duration", { length: 20 }),
    order: int("order").notNull(),
    isFree: boolean("isFree").default(false),
    createdAt: timestamp("createdAt").defaultNow(),
  },
  (table) => ({
    courseIdx: index("lesson_course_idx").on(table.courseId),
  })
);

export type Lesson = typeof lessons.$inferSelect;
export type InsertLesson = typeof lessons.$inferInsert;

export const purchases = mysqlTable(
  "purchases",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    courseId: bigint("courseId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => courses.id, { onDelete: "cascade" }),
    amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
    status: mysqlEnum("status", ["pending", "completed", "refunded"])
      .default("completed")
      .notNull(),
    createdAt: timestamp("createdAt").defaultNow(),
  },
  (table) => ({
    userIdx: index("purchase_user_idx").on(table.userId),
    courseIdx: index("purchase_course_idx").on(table.courseId),
  })
);

export type Purchase = typeof purchases.$inferSelect;
export type InsertPurchase = typeof purchases.$inferInsert;

export const progress = mysqlTable(
  "progress",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    lessonId: bigint("lessonId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => lessons.id, { onDelete: "cascade" }),
    completed: boolean("completed").default(false),
    watchedSeconds: int("watchedSeconds").default(0),
    completedAt: timestamp("completedAt"),
    createdAt: timestamp("createdAt").defaultNow(),
  },
  (table) => ({
    userIdx: index("progress_user_idx").on(table.userId),
    lessonIdx: index("progress_lesson_idx").on(table.lessonId),
  })
);

export type Progress = typeof progress.$inferSelect;
export type InsertProgress = typeof progress.$inferInsert;
