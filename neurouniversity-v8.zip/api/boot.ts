import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";
import { createOAuthCallbackHandler } from "./kimi/auth";
import { Paths } from "@contracts/constants";
import { getDb } from "./queries/connection";
import { courses, lessons } from "@db/schema";
import { courseData, lessonTitles, generateLessonContent } from "@db/seed-data";

const app = new Hono<{ Bindings: HttpBindings }>();

app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));
app.get(Paths.oauthCallback, createOAuthCallbackHandler());
app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});
app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

export default app;

if (env.isProduction) {
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);

  // Auto-seed courses on first startup
  async function autoSeed() {
    try {
      const db = getDb();
      const existing = await db.select().from(courses);
      if (existing.length > 0) {
        console.log(`[seed] Database already has ${existing.length} courses, skipping seed.`);
        return;
      }

      console.log("[seed] Seeding courses and lessons...");
      for (const course of courseData) {
        const [inserted] = await db.insert(courses).values(course).$returningId();
        const titles = lessonTitles[course.slug] || [];
        const lessonValues = titles.map((title, i) => ({
          courseId: inserted.id,
          title,
          description: `Разбираем: ${title}`,
          content: generateLessonContent(title),
          duration: `${15 + Math.floor(Math.random() * 25)}:${String(Math.floor(Math.random() * 59)).padStart(2, "0")}`,
          order: i + 1,
          isFree: i === 0,
        }));
        if (lessonValues.length > 0) {
          await db.insert(lessons).values(lessonValues);
        }
        console.log(`[seed]  Created: ${course.title} (${titles.length} lessons)`);
      }
      console.log(`[seed] Done! Created ${courseData.length} courses.`);
    } catch (err) {
      console.error("[seed] Error:", err);
    }
  }

  // Run seed before starting server
  await autoSeed();

  const port = parseInt(process.env.PORT || "3000");
  serve({ fetch: app.fetch, port }, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}
