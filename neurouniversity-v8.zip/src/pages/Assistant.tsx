import { useState, useEffect, useRef, useCallback } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import Navbar from "@/components/Navbar";
import {
  Send,
  Sparkles,
  BookOpen,
  GraduationCap,
  Zap,
  User,
  Volume2,
  VolumeX,
  ArrowRight,
  Loader2,
} from "lucide-react";

interface Message {
  id: string;
  role: "user" | "assistant";
  text: string;
  isTyping?: boolean;
  source?: "ai" | "local";
}

const GREETING = `Привет! Я Нейра — твой AI-консультант в мире нейросетей. Готова ответить на любые вопросы о наших курсах, помочь выбрать подходящий, или просто рассказать, как работает искусственный интеллект. Чем могу помочь?`;

const QUICK_QUESTIONS = [
  "Какие курсы есть для начинающих?",
  "Расскажи про ChatGPT курс",
  "Что такое Prompt Engineering?",
  "Какой курс выбрать для работы?",
  "Сколько стоят курсы?",
  "Что изучают в курсе по Midjourney?",
];

export default function Assistant() {
  const [messages, setMessages] = useState<Message[]>([
    { id: "greet", role: "assistant", text: GREETING, isTyping: false },
  ]);
  const [input, setInput] = useState("");
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [displayedText, setDisplayedText] = useState("");
  const [aiStatus, setAiStatus] = useState<"idle" | "loading" | "error">("idle");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: courses } = trpc.course.list.useQuery({});
  const aiChat = trpc.ai.chat.useMutation();

  // Typing effect for greeting
  useEffect(() => {
    if (messages[0]?.id === "greet" && displayedText.length < GREETING.length) {
      let i = 0;
      const interval = setInterval(() => {
        setDisplayedText(GREETING.slice(0, i));
        i++;
        if (i > GREETING.length) clearInterval(interval);
      }, 12);
      return () => clearInterval(interval);
    }
  }, []);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, displayedText]);

  // Speech synthesis
  const speak = useCallback(
    (text: string) => {
      if (!soundEnabled) return;
      window.speechSynthesis.cancel();
      const cleanText = text.replace(/\*\*/g, "").replace(/\[.*?\]\(.*?\)/g, "").replace(/[#>-]/g, "");
      const utterance = new SpeechSynthesisUtterance(cleanText.slice(0, 300));
      utterance.lang = "ru-RU";
      utterance.rate = 1.1;
      utterance.pitch = 1.1;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    },
    [soundEnabled]
  );

  const stopSpeaking = useCallback(() => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  }, []);

  const handleSend = useCallback(
    async (text: string) => {
      if (!text.trim()) return;
      stopSpeaking();

      const userMsg: Message = {
        id: Date.now().toString(),
        role: "user",
        text: text.trim(),
      };

      setMessages((prev) => [...prev, userMsg]);
      setInput("");
      setAiStatus("loading");

      // Build history (last 10 messages)
      const history = messages
        .filter((m) => m.id !== "greet" && !m.isTyping)
        .slice(-10)
        .map((m) => ({
          role: m.role as "user" | "assistant",
          content: m.text,
        }));

      try {
        const result = await aiChat.mutateAsync({
          message: text.trim(),
          history,
        });

        const assistantMsg: Message = {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          text: result.response,
          isTyping: true,
          source: result.source as "ai" | "local",
        };

        setMessages((prev) => [...prev, assistantMsg]);
        setAiStatus(result.source === "ai" ? "idle" : "idle");

        // Speak response
        setTimeout(() => speak(result.response), 500);
      } catch (err: any) {
        setAiStatus("error");
        console.error("[Assistant] AI error:", err);
        const errorMsg: Message = {
          id: (Date.now() + 2).toString(),
          role: "assistant",
          text: `Ошибка связи с AI: ${err.message || "Неизвестная ошибка"}. Попробуй ещё раз!`,
          source: "local",
        };
        setMessages((prev) => [...prev, errorMsg]);
      }
    },
    [messages, aiChat, speak, stopSpeaking]
  );

  const handleTypingComplete = useCallback(
    (msgId: string) => {
      setMessages((prev) =>
        prev.map((m) => (m.id === msgId ? { ...m, isTyping: false } : m))
      );
    },
    []
  );

  const handleQuickQuestion = (q: string) => handleSend(q);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSend(input);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0F] flex flex-col">
      <Navbar />

      <div className="flex-1 flex flex-col lg:flex-row pt-16">
        {/* Left: Avatar Panel */}
        <div className="lg:w-[340px] shrink-0 p-6 flex flex-col items-center border-b lg:border-b-0 lg:border-r border-white/[0.06]">
          {/* Avatar with hologram effect */}
          <div className="relative mb-4 animate-float">
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-[#8B5CF6] to-[#EC4899] opacity-40 blur-2xl animate-pulse" />
            <div className="relative w-48 h-48 rounded-full overflow-hidden border-2 border-[#8B5CF6]/30 shadow-2xl animate-hologram">
              <img
                src="/avatar-static.png"
                alt="Нейра"
                className="w-full h-full object-cover"
              />
              <div
                className="absolute inset-0 bg-gradient-to-b from-transparent via-[#8B5CF6]/10 to-transparent opacity-50 pointer-events-none"
                style={{ animation: "hologram-scan 3s linear infinite" }}
              />
            </div>
            {isSpeaking && (
              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 flex items-end gap-1">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="sound-bar" style={{ height: 4 }} />
                ))}
              </div>
            )}
            {isSpeaking && (
              <div className="absolute bottom-2 right-2 w-4 h-4 rounded-full bg-emerald-400 border-2 border-[#0A0A0F] animate-pulse" />
            )}
          </div>

          <h2 className="text-xl font-bold text-white mb-1">Нейра</h2>
          <p className="text-sm text-slate-400 mb-2 text-center">
            Твой AI-консультант по курсам
          </p>

          {/* AI Status Badge */}
          <div
            className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium mb-4 ${
              aiStatus === "loading"
                ? "bg-amber-500/15 text-amber-400"
                : aiStatus === "error"
                  ? "bg-rose-500/15 text-rose-400"
                  : "bg-emerald-500/15 text-emerald-400"
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                aiStatus === "loading"
                  ? "bg-amber-400 animate-pulse"
                  : aiStatus === "error"
                    ? "bg-rose-400"
                    : "bg-emerald-400"
              }`}
            />
            {aiStatus === "loading"
              ? "Думаю..."
              : aiStatus === "error"
                ? "Ошибка соединения"
                : "AI активен"}
          </div>

          <div className="flex gap-2 mb-6">
            <button
              onClick={() => {
                if (isSpeaking) stopSpeaking();
                else speak(GREETING);
              }}
              className={`p-2.5 rounded-xl transition-colors ${
                isSpeaking
                  ? "bg-emerald-500/20 text-emerald-400"
                  : "bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white"
              }`}
              title={isSpeaking ? "Остановить" : "Озвучить"}
            >
              {isSpeaking ? (
                <VolumeX className="w-5 h-5" />
              ) : (
                <Volume2 className="w-5 h-5" />
              )}
            </button>
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`p-2.5 rounded-xl transition-colors ${
                soundEnabled
                  ? "bg-[#8B5CF6]/20 text-[#8B5CF6]"
                  : "bg-white/5 text-slate-500"
              }`}
              title={soundEnabled ? "Звук вкл" : "Звук выкл"}
            >
              {soundEnabled ? (
                <Volume2 className="w-5 h-5" />
              ) : (
                <VolumeX className="w-5 h-5" />
              )}
            </button>
          </div>

          {/* Stats */}
          <div className="w-full space-y-3">
            <div className="flex items-center gap-3 p-3 rounded-xl bg-[#12121A] border border-white/[0.06]">
              <BookOpen className="w-5 h-5 text-[#8B5CF6]" />
              <div>
                <p className="text-sm font-medium text-white">
                  {courses?.length || 12} курсов
                </p>
                <p className="text-xs text-slate-500">В базе знаний</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-xl bg-[#12121A] border border-white/[0.06]">
              <GraduationCap className="w-5 h-5 text-[#EC4899]" />
              <div>
                <p className="text-sm font-medium text-white">116+ уроков</p>
                <p className="text-xs text-slate-500">Для изучения</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 rounded-xl bg-[#12121A] border border-white/[0.06]">
              <Zap className="w-5 h-5 text-amber-400" />
              <div>
                <p className="text-sm font-medium text-white">DeepSeek AI</p>
                <p className="text-xs text-slate-500">Модель за ответами</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Chat */}
        <div className="flex-1 flex flex-col min-h-0">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
            {/* Greeting message */}
            <div className="flex gap-3">
              <div className="shrink-0 w-8 h-8 rounded-full gradient-bg flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div className="max-w-[80%] rounded-2xl px-4 py-3 bg-[#12121A] border border-white/[0.06] text-slate-300">
                <div className="whitespace-pre-wrap text-sm leading-relaxed">
                  {messages[0]?.id === "greet" && messages[0]?.isTyping !== false
                    ? displayedText
                    : messages[0]?.text}
                  {messages[0]?.id === "greet" &&
                    displayedText.length < GREETING.length && (
                      <span className="inline-block w-2 h-4 bg-[#8B5CF6] ml-0.5 animate-pulse align-middle" />
                    )}
                </div>
              </div>
            </div>

            {/* Other messages */}
            {messages.slice(1).map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
              >
                <div
                  className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                    msg.role === "assistant"
                      ? "gradient-bg"
                      : "bg-white/10"
                  }`}
                >
                  {msg.role === "assistant" ? (
                    <Sparkles className="w-4 h-4 text-white" />
                  ) : (
                    <User className="w-4 h-4 text-slate-300" />
                  )}
                </div>
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                    msg.role === "user"
                      ? "bg-[#8B5CF6] text-white"
                      : "bg-[#12121A] border border-white/[0.06] text-slate-300"
                  }`}
                >
                  {msg.role === "assistant" && msg.isTyping ? (
                    <TypingBubble
                      text={msg.text}
                      source={msg.source}
                      onComplete={() => handleTypingComplete(msg.id)}
                    />
                  ) : (
                    <div className="prose prose-invert prose-sm max-w-none whitespace-pre-wrap">
                      <FormattedText text={msg.text} />
                      {msg.source === "local" && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 text-[10px] mt-2">
                          локальный режим
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {/* Loading indicator */}
            {aiStatus === "loading" && (
              <div className="flex gap-3">
                <div className="shrink-0 w-8 h-8 rounded-full gradient-bg flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-white animate-spin" />
                </div>
                <div className="px-4 py-3 rounded-2xl bg-[#12121A] border border-white/[0.06]">
                  <Loader2 className="w-5 h-5 text-[#8B5CF6] animate-spin" />
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick questions */}
          {messages.length <= 1 && (
            <div className="px-4 md:px-6 pb-2">
              <p className="text-xs text-slate-500 mb-2">Быстрые вопросы:</p>
              <div className="flex flex-wrap gap-2">
                {QUICK_QUESTIONS.map((q, i) => (
                  <button
                    key={i}
                    onClick={() => handleQuickQuestion(q)}
                    className="px-3 py-1.5 rounded-lg bg-[#12121A] border border-white/[0.06] text-xs text-slate-400 hover:text-white hover:border-[#8B5CF6]/30 transition-all"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input */}
          <div className="p-4 border-t border-white/[0.06]">
            <form onSubmit={handleSubmit} className="flex gap-3">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={
                  aiStatus === "loading"
                    ? "Нейра думает..."
                    : "Спроси Нейру о курсах..."
                }
                disabled={aiStatus === "loading"}
                className="flex-1 px-4 py-3 rounded-xl bg-[#12121A] border border-white/[0.06] text-white placeholder:text-slate-600 focus:outline-none focus:border-[#8B5CF6]/50 transition-colors disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={!input.trim() || aiStatus === "loading"}
                className="px-4 py-3 rounded-xl gradient-bg text-white hover:opacity-90 transition-opacity disabled:opacity-30 disabled:cursor-not-allowed"
              >
                {aiStatus === "loading" ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Send className="w-5 h-5" />
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

// Typing bubble with cursor
function TypingBubble({
  text,
  source,
  onComplete,
}: {
  text: string;
  source?: "ai" | "local";
  onComplete: () => void;
}) {
  const [displayed, setDisplayed] = useState("");

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      i += 3;
      setDisplayed(text.slice(0, i));
      if (i >= text.length) {
        clearInterval(interval);
        onComplete();
      }
    }, 5);
    return () => clearInterval(interval);
  }, [text, onComplete]);

  return (
    <div className="whitespace-pre-wrap">
      <div className="prose prose-invert prose-sm max-w-none">
        <FormattedText text={displayed} />
      </div>
      {displayed.length < text.length && (
        <span className="inline-block w-2 h-4 bg-[#8B5CF6] ml-0.5 animate-pulse align-middle" />
      )}
      {displayed.length >= text.length && source === "local" && (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 text-[10px] mt-2">
          локальный режим — добавь OPENROUTER_API_KEY для полного AI
        </span>
      )}
    </div>
  );
}

// Format text with markdown-like syntax and links
function FormattedText({ text }: { text: string }) {
  // Simple markdown parser for **bold** and [text](/url)
  const parts = text.split(/(\*\*.*?\*\*|\[.*?\]\(.*?\))/g);

  return (
    <>
      {parts.map((part, i) => {
        // Bold
        if (part.startsWith("**") && part.endsWith("**")) {
          return (
            <strong key={i} className="text-white font-semibold">
              {part.slice(2, -2)}
            </strong>
          );
        }
        // Link [text](/url)
        const linkMatch = part.match(/\[([^\]]+)\]\(([^)]+)\)/);
        if (linkMatch) {
          const [, linkText, linkUrl] = linkMatch;
          const before = part.split(linkMatch[0])[0];
          const after = part.split(linkMatch[0])[1];
          return (
            <span key={i}>
              {before}
              <Link
                to={linkUrl}
                className="text-[#8B5CF6] hover:text-[#EC4899] underline transition-colors"
              >
                {linkText} <ArrowRight className="w-3 h-3 inline" />
              </Link>
              {after}
            </span>
          );
        }
        return <span key={i}>{part}</span>;
      })}
    </>
  );
}
