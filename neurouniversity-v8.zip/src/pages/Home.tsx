import { Link } from "react-router";
import { useEffect, useRef } from "react";
import { trpc } from "@/providers/trpc";
import Navbar from "@/components/Navbar";
import CourseCard from "@/components/CourseCard";
import {
  Brain,
  Code2,
  Users,
  Infinity,
  ArrowRight,
  ChevronRight,
  Sparkles,
  Zap,
  Target,
  Star,
  Quote,
} from "lucide-react";

function NeuralNetworkCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
    }> = [];

    const resize = () => {
      canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      canvas.height = canvas.offsetHeight * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };

    const init = () => {
      resize();
      particles = [];
      const count = 80;
      for (let i = 0; i < count; i++) {
        particles.push({
          x: Math.random() * canvas.offsetWidth,
          y: Math.random() * canvas.offsetHeight,
          vx: (Math.random() - 0.5) * 0.3,
          vy: (Math.random() - 0.5) * 0.3,
        });
      }
    };

    const draw = () => {
      const w = canvas.offsetWidth;
      const h = canvas.offsetHeight;
      ctx.clearRect(0, 0, w, h);

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > w) p.vx *= -1;
        if (p.y < 0 || p.y > h) p.vy *= -1;

        for (let j = i + 1; j < particles.length; j++) {
          const q = particles[j];
          const dx = p.x - q.x;
          const dy = p.y - q.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 140) {
            const alpha = (1 - dist / 140) * 0.15;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(q.x, q.y);
            ctx.strokeStyle = `rgba(139, 92, 246, ${alpha})`;
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, 2, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(139, 92, 246, 0.4)";
        ctx.fill();
      }

      animationId = requestAnimationFrame(draw);
    };

    init();
    draw();
    window.addEventListener("resize", init);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener("resize", init);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none"
    />
  );
}

const features = [
  {
    icon: Code2,
    title: "Без кода",
    desc: "Все курсы для людей, не для программистов",
  },
  {
    icon: Target,
    title: "Практика",
    desc: "Каждый урок — конкретный навык, который можно применить сразу",
  },
  {
    icon: Users,
    title: "Сообщество",
    desc: "Чат с менторами и другими студентами",
  },
  {
    icon: Infinity,
    title: "Доступ навсегда",
    desc: "Купил — получил пожизненный доступ",
  },
];

const steps = [
  {
    num: "01",
    title: "Выбери курс",
    desc: "Более 12 курсов по нейросетям для любого уровня",
  },
  {
    num: "02",
    title: "Оплати один раз",
    desc: "Никаких подписок — пожизненный доступ",
  },
  {
    num: "03",
    title: "Учись в своём темпе",
    desc: "Смотри уроки когда удобно, отмечай прогресс",
  },
];

const testimonials = [
  {
    name: "Анна К.",
    role: "Маркетолог",
    text: "За месяц обучения увеличила продуктивность в 3 раза. ChatGPT теперь мой главный помощник.",
    rating: 5,
  },
  {
    name: "Дмитрий М.",
    role: "Предприниматель",
    text: "Курс по автоматизации бизнеса с AI окупился за неделю. Внедрил 5 AI-агентов в компании.",
    rating: 5,
  },
  {
    name: "Елена В.",
    role: "Дизайнер",
    text: "Midjourney изменил мой подход к работе. Теперь я создаю концепты за минуты, а не за дни.",
    rating: 5,
  },
  {
    name: "Сергей П.",
    role: "Фрилансер",
    text: "С нуля до первого заказа с AI прошёл 2 недели. Курсы действительно для обычных людей.",
    rating: 5,
  },
  {
    name: "Мария С.",
    role: "HR-менеджер",
    text: "AI для подбора персонала сократил время на скрининг резюме на 70%.",
    rating: 5,
  },
  {
    name: "Иван Д.",
    role: "Копирайтер",
    text: "Курс по AI-копирайтингу помог мне писать в 4 раза больше текста без потери качества.",
    rating: 5,
  },
];

export default function Home() {
  const { data: courses } = trpc.course.list.useQuery({});
  const popularCourses = courses?.slice(0, 4) || [];

  return (
    <div className="min-h-screen bg-[#0A0A0F]">
      <Navbar />

      {/* Hero */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0A0A0F] via-[#1a103c] to-[#0A0A0F]" />
        <NeuralNetworkCanvas />
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8">
            <Sparkles className="w-4 h-4 text-[#8B5CF6]" />
            <span className="text-sm text-slate-300">
              12 курсов · 2500+ студентов
            </span>
          </div>
          <h1 className="text-5xl md:text-7xl font-black mb-6 leading-tight">
            <span className="text-white">Освой</span>{" "}
            <span className="gradient-text">нейросети</span>
          </h1>
          <p className="text-lg md:text-xl text-slate-400 mb-4 max-w-2xl mx-auto leading-relaxed">
            Понятные курсы для обычных людей. Без кода, без сложной математики
            — только практические навыки.
          </p>
          <p className="text-slate-500 mb-10">
            Научись использовать ChatGPT, Midjourney и десятки других ИИ-инструментов
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/courses">
              <button className="px-8 py-4 rounded-xl text-base font-semibold gradient-bg text-white hover:opacity-90 transition-opacity flex items-center gap-2">
                Начать обучение
                <ArrowRight className="w-5 h-5" />
              </button>
            </Link>
            <Link to="/courses">
              <button className="px-8 py-4 rounded-xl text-base font-semibold border border-white/10 text-white hover:bg-white/5 transition-colors">
                Смотреть курсы
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* Why us */}
      <section className="py-24 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            Почему <span className="gradient-text">мы</span>
          </h2>
          <p className="text-slate-400 text-center mb-16 max-w-xl mx-auto">
            Мы делаем сложное простым
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((f, i) => (
              <div
                key={i}
                className="p-6 rounded-2xl bg-[#12121A] border border-white/[0.06] hover:-translate-y-1 hover:shadow-lg hover:shadow-purple-500/5 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl gradient-bg flex items-center justify-center mb-4">
                  <f.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">
                  {f.title}
                </h3>
                <p className="text-sm text-slate-400">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Popular courses */}
      <section className="py-24 px-4 bg-[#08080C]">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-end justify-between mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-2">
                Популярные <span className="gradient-text">курсы</span>
              </h2>
              <p className="text-slate-400">
                Выбирайте из лучших курсов платформы
              </p>
            </div>
            <Link
              to="/courses"
              className="hidden sm:flex items-center gap-1 text-[#8B5CF6] hover:text-[#EC4899] transition-colors"
            >
              Все курсы
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {popularCourses.map((course) => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-24 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            Как это <span className="gradient-text">работает</span>
          </h2>
          <p className="text-slate-400 text-center mb-16">
            Три простых шага до новых навыков
          </p>
          <div className="relative">
            {/* Connecting line */}
            <div className="absolute left-8 top-12 bottom-12 w-px bg-gradient-to-b from-[#8B5CF6] via-[#EC4899] to-[#8B5CF6] hidden md:block" />
            <div className="space-y-12">
              {steps.map((s, i) => (
                <div
                  key={i}
                  className="relative flex flex-col md:flex-row gap-6 md:gap-12 items-start"
                >
                  <div className="shrink-0 w-16 h-16 rounded-2xl gradient-bg flex items-center justify-center z-10">
                    <span className="text-xl font-bold text-white">
                      {s.num}
                    </span>
                  </div>
                  <div className="pt-2">
                    <h3 className="text-xl font-semibold text-white mb-2">
                      {s.title}
                    </h3>
                    <p className="text-slate-400">{s.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 px-4 bg-[#08080C]">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
            Отзывы <span className="gradient-text">студентов</span>
          </h2>
          <p className="text-slate-400 text-center mb-16">
            Уже более 2500 человек прошли наши курсы
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <div
                key={i}
                className="p-6 rounded-2xl bg-[#12121A] border border-white/[0.06]"
              >
                <Quote className="w-8 h-8 text-[#8B5CF6]/40 mb-4" />
                <p className="text-slate-300 mb-4 leading-relaxed">
                  {t.text}
                </p>
                <div className="flex items-center gap-1 mb-4">
                  {Array.from({ length: t.rating }).map((_, j) => (
                    <Star
                      key={j}
                      className="w-4 h-4 text-amber-400 fill-amber-400"
                    />
                  ))}
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full gradient-bg flex items-center justify-center text-white font-semibold text-sm">
                    {t.name[0]}
                  </div>
                  <div>
                    <div className="text-sm font-medium text-white">
                      {t.name}
                    </div>
                    <div className="text-xs text-slate-500">{t.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <div className="p-12 rounded-3xl bg-gradient-to-br from-[#8B5CF6]/20 via-[#12121A] to-[#EC4899]/20 border border-white/[0.06]">
            <Zap className="w-12 h-12 text-[#8B5CF6] mx-auto mb-6" />
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Готов начать?
            </h2>
            <p className="text-slate-400 mb-8 max-w-lg mx-auto">
              Выбери свой первый курс и начни осваивать нейросети уже сегодня.
              Без кода, без сложностей — только результат.
            </p>
            <Link to="/courses">
              <button className="px-8 py-4 rounded-xl text-base font-semibold gradient-bg text-white hover:opacity-90 transition-opacity inline-flex items-center gap-2">
                Посмотреть все курсы
                <ArrowRight className="w-5 h-5" />
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t border-white/[0.06]">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <Brain className="w-6 h-6 text-[#8B5CF6]" />
            <span className="text-lg font-bold text-white">
              Нейро<span className="gradient-text">Университет</span>
            </span>
          </div>
          <p className="text-sm text-slate-500">
            Образовательная платформа по нейросетям для обычных людей
          </p>
          <p className="text-sm text-slate-600">
            © 2025 НейроУниверситет
          </p>
        </div>
      </footer>
    </div>
  );
}
