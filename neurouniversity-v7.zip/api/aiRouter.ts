import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";

const SYSTEM_PROMPT = `Ты — Нейра, дружелюбный AI-консультант образовательной платформы "НейроУниверситет". Ты помогаешь пользователям выбирать курсы по нейросетям и отвечаешь на вопросы об искусственном интеллекте.

## О платформе
НейроУниверситет — это образовательная платформа с 12 курсами по нейросетям для обычных людей. Никакого кода, только практические навыки.

## Курсы в базе:

### Категория "База" (для начинающих):
1. "Нейросети с нуля" — 12 уроков, 2990₽ (вместо 4990₽). Полный базовый курс. Что такое нейросеть, ChatGPT, Midjourney, как нейросети учатся, где применяются.
2. "ChatGPT: от новичка до эксперта" — 10 уроков, 1990₽ (вместо 3490₽). Как писать промпты, 50+ шаблонов, автоматизация, контент-планы.
3. "Midjourney для творческих профессий" — 8 уроков, 2490₽ (вместо 3990₽). Все параметры Midjourney, стили, персонажи, логотипы.

### Категория "Для работы":
4. "AI для маркетологов" — 10 уроков, 3490₽ (вместо 5490₽). Рекламные тексты, анализ конкурентов, email-маркетинг, SMM.
5. "Нейросети для дизайнеров" — 12 уроков, 2990₽ (вместо 4990₽). Мокапы, иллюстрации, AI-плагины для Figma, UI-киты.
6. "Автоматизация бизнеса с AI" — 8 уроков, 3990₽ (вместо 5990₽). Клиентская поддержка, анализ документов, прогнозирование.

### Категория "Продвинутый":
7. "Prompt Engineering мастерство" — 14 уроков, 4990₽ (вместо 7990₽). Структуры промптов, Chain-of-Thought, Few-shot, оптимизация.
8. "Создание AI-агентов" — 10 уроков, 5990₽ (вместо 8990₽). No-code платформы, автономные агенты, интеграция с сервисами.
9. "Нейросети для анализа данных" — 12 уроков, 4490₽ (вместо 6990₽). Анализ Excel, визуализация, прогнозирование, отчёты.

### Категория "Специальные навыки":
10. "Генерация видео нейросетями" — 8 уроков, 3490₽ (вместо 5490₽). Sora, Runway, анимация, рекламные ролики.
11. "AI для копирайтинга" — 10 уроков, 2490₽ (вместо 3990₽). Продающие тексты, статьи, email, посты.
12. "Защита данных в эпоху AI" — 6 уроков, 1990₽ (вместо 2990₽). Безопасность, приватность, локальные модели.

## Важные правила:
- Всегда отвечай на русском языке
- Будь дружелюбной, энергичной и немного игривой
- Используй эмодзи умеренно
- Если пользователь спрашивает о курсе — давай подробную информацию: цена, количество уроков, что изучает, для кого подходит
- Если пользователь не знает с чего начать — задавай уточняющие вопросы о его целях
- Все цены в рублях (₽)
- Каждый курс включает: доступ навсегда, сертификат, поддержку в чате
- Первый урок каждого курса бесплатный для ознакомления
- Отвечай кратко и по делу, но с теплом
- Если спрашивают про технологии вне курсов — тоже помогай, ты эксперт в AI`;

export const aiRouter = createRouter({
  chat: publicQuery
    .input(
      z.object({
        message: z.string().min(1).max(4000),
        history: z
          .array(
            z.object({
              role: z.enum(["user", "assistant"]),
              content: z.string(),
            })
          )
          .optional()
          .default([]),
      })
    )
    .mutation(async ({ input }) => {
      try {
        // Check for OpenRouter API key
        const apiKey = process.env.OPENROUTER_API_KEY;
        if (!apiKey) {
          // Fallback: return helpful response without AI
          return {
            response: generateFallbackResponse(input.message),
            source: "local",
          };
        }

        const messages = [
          { role: "system", content: SYSTEM_PROMPT },
          ...input.history.map((h) => ({
            role: h.role as "user" | "assistant",
            content: h.content,
          })),
          { role: "user", content: input.message },
        ];

        const response = await fetch(
          "https://openrouter.ai/api/v1/chat/completions",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${apiKey}`,
              "HTTP-Referer": process.env.APP_URL || "https://neurouniversity.ru",
              "X-Title": "НейроУниверситет",
            },
            body: JSON.stringify({
              model: "deepseek/deepseek-chat-v3-0324:free",
              messages,
              max_tokens: 1500,
              temperature: 0.8,
            }),
          }
        );

        if (!response.ok) {
          const error = await response.text();
          console.error("OpenRouter error:", error);
          return {
            response: generateFallbackResponse(input.message),
            source: "local",
          };
        }

        const data = (await response.json()) as {
          choices?: Array<{ message?: { content?: string } }>;
        };
        const content = data.choices?.[0]?.message?.content;

        if (!content) {
          return {
            response: generateFallbackResponse(input.message),
            source: "local",
          };
        }

        return { response: content, source: "ai" };
      } catch (error) {
        console.error("AI chat error:", error);
        return {
          response: generateFallbackResponse(input.message),
          source: "local",
        };
      }
    }),
});

// Fallback response generator when AI API is unavailable
function generateFallbackResponse(query: string): string {
  const q = query.toLowerCase();

  if (q.includes("привет") || q.includes("здравствуй")) {
    return "Привет! Я Нейра — твой AI-консультант по курсам нейросетей. Сейчас я работаю в локальном режиме, но скоро подключу полный ИИ-мозг! Чем могу помочь?";
  }

  if (q.includes("курс") || q.includes("обучение")) {
    return "У нас 12 курсов по нейросетям:\n\n**База (для начинающих):**\n• Нейросети с нуля — 2990₽\n• ChatGPT мастер — 1990₽\n• Midjourney — 2490₽\n\n**Для работы:**\n• AI для маркетологов — 3490₽\n• Нейросети для дизайнеров — 2990₽\n• Автоматизация бизнеса — 3990₽\n\n**Продвинутый:**\n• Prompt Engineering — 4990₽\n• AI-агенты — 5990₽\n• Анализ данных — 4490₽\n\n**Специальные:**\n• Генерация видео — 3490₽\n• AI-копирайтинг — 2490₽\n• Защита данных — 1990₽\n\nКакой курс тебя интересует?";
  }

  if (q.includes("цена") || q.includes("стоимость") || q.includes("сколько")) {
    return "Цены на курсы от 1990₽ до 5990₽. Все курсы со скидкой до 40%!\n\nСамые доступные:\n• Защита данных — 1990₽\n• ChatGPT мастер — 1990₽\n• AI-копирайтинг — 2490₽\n\nПремиум:\n• AI-агенты — 5990₽\n• Prompt Engineering — 4990₽\n\nПожизненный доступ, сертификат, поддержка — всё включено!";
  }

  if (q.includes("начинающий") || q.includes("новичок") || q.includes("с нуля")) {
    return "Для начинающих идеально подойдут:\n\n1. **Нейросети с нуля** (2990₽) — полная база, поймёшь как работает ИИ\n2. **ChatGPT мастер** (1990₽) — освоишь главный инструмент 2025 года\n3. **Midjourney** (2490₽) — если хочешь создавать крутые картинки\n4. **AI-копирайтинг** (2490₽) — для тех, кто работает с текстами\n\nРекомендую начать с **Нейросети с нуля** — он даст отличную базу!";
  }

  return "Отличный вопрос! Сейчас я работаю в локальном режиме. Для подключения полноценного AI добавь OPENROUTER_API_KEY в файл .env — это бесплатно!\n\nА пока могу рассказать о наших курсах — у нас 12 курсов по нейросетям. Что тебя интересует?";
}
