/**
 * Генератор уникального контента для уроков через DeepSeek AI.
 * Запускать: npx tsx db/content-generator.ts
 */
import { getDb } from "../api/queries/connection";
import { lessons, courses } from "./schema";
import { eq } from "drizzle-orm";

const API_KEY = process.env.OPENROUTER_API_KEY;

const SYSTEM_PROMPT = `Ты — эксперт по созданию образовательного контента. 
Пиши развёрнутые, полезные уроки на русском языке. 
Используй markdown: заголовки ##, списки, примеры, цитаты, чек-листы.
Каждый урок должен быть практичным — с конкретными примерами, шагами и домашним заданием.`;

async function generateLessonContent(courseTitle: string, lessonTitle: string): Promise<string> {
  if (!API_KEY) {
    throw new Error("OPENROUTER_API_KEY не задан в .env");
  }

  const prompt = `Напиши подробный урок для курса "${courseTitle}" на тему "${lessonTitle}".
Урок должен содержать:
1. Краткое введение (почему это важно)
2. Теория простым языком
3. Практический пример с пошаговой инструкцией
4. Полезные лайфхаки
5. Домашнее задание
6. Чек-лист для самопроверки

Формат: markdown. Объём: 800-1200 слов.`;

  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${API_KEY}`,
      "HTTP-Referer": "https://neurouniversity.ru",
      "X-Title": "НейроУниверситет Content Gen",
    },
    body: JSON.stringify({
      model: "deepseek/deepseek-chat-v3-0324:free",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: prompt },
      ],
      max_tokens: 2000,
      temperature: 0.7,
    }),
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`API error: ${response.status} — ${err}`);
  }

  const data = await response.json() as {
    choices?: Array<{ message?: { content?: string } }>;
  };

  const content = data.choices?.[0]?.message?.content;
  if (!content) throw new Error("Empty content from AI");

  return content;
}

async function main() {
  console.log("🚀 Генерация уникального контента для уроков...");
  const db = getDb();

  const allCourses = await db.select().from(courses);
  console.log(`📚 Найдено ${allCourses.length} курсов`);

  for (const course of allCourses) {
    const courseLessons = await db
      .select()
      .from(lessons)
      .where(eq(lessons.courseId, course.id))
      .orderBy(lessons.order);

    console.log(`\n📖 ${course.title} — ${courseLessons.length} уроков`);

    for (const lesson of courseLessons) {
      // Skip if content is already generated (not template)
      if (lesson.content && lesson.content.length > 500 && !lesson.content.includes("В этом уроке мы подробно разберём")) {
        console.log(`  ✅ ${lesson.title} — уже есть контент`);
        continue;
      }

      try {
        console.log(`  📝 Генерация: ${lesson.title}...`);
        const content = await generateLessonContent(course.title, lesson.title);

        await db
          .update(lessons)
          .set({ content })
          .where(eq(lessons.id, lesson.id));

        console.log(`  ✅ Сохранено (${content.length} chars)`);

        // Rate limiting — wait between requests
        await new Promise((r) => setTimeout(r, 2000));
      } catch (err: any) {
        console.error(`  ❌ Ошибка для "${lesson.title}":`, err.message);
        // Continue with next lesson
        await new Promise((r) => setTimeout(r, 5000));
      }
    }
  }

  console.log("\n🎉 Готово! Все уроки обновлены.");
}

main().catch(console.error);
