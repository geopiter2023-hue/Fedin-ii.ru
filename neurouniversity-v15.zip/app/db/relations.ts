import { relations } from "drizzle-orm";
import { users, courses, lessons, purchases, progress } from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  purchases: many(purchases),
  progress: many(progress),
}));

export const coursesRelations = relations(courses, ({ many }) => ({
  lessons: many(lessons),
  purchases: many(purchases),
}));

export const lessonsRelations = relations(lessons, ({ one, many }) => ({
  course: one(courses, {
    fields: [lessons.courseId],
    references: [courses.id],
  }),
  progress: many(progress),
}));

export const purchasesRelations = relations(purchases, ({ one }) => ({
  user: one(users, {
    fields: [purchases.userId],
    references: [users.id],
  }),
  course: one(courses, {
    fields: [purchases.courseId],
    references: [courses.id],
  }),
}));

export const progressRelations = relations(progress, ({ one }) => ({
  user: one(users, {
    fields: [progress.userId],
    references: [users.id],
  }),
  lesson: one(lessons, {
    fields: [progress.lessonId],
    references: [lessons.id],
  }),
}));
