import { useState } from "react";
import { Link, useLocation } from "react-router";
import { Sparkles, X } from "lucide-react";

export default function FloatingAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  // Hide on assistant page itself
  if (location.pathname === "/assistant") return null;

  return (
    <>
      {/* Chat bubble preview */}
      {isOpen && (
        <div className="fixed bottom-20 right-6 z-50 max-w-[280px] animate-fade-in">
          <div className="p-4 rounded-2xl bg-[#12121A] border border-white/[0.06] shadow-2xl shadow-purple-500/10 relative">
            <button
              onClick={() => setIsOpen(false)}
              className="absolute top-2 right-2 text-slate-500 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-full gradient-bg flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="text-sm font-semibold text-white">Нейра</span>
            </div>
            <p className="text-xs text-slate-400 mb-3">
              Привет! Я твой AI-консультант. Спроси меня о любых курсах!
            </p>
            <Link
              to="/assistant"
              onClick={() => setIsOpen(false)}
              className="block w-full text-center px-4 py-2 rounded-xl gradient-bg text-white text-sm font-medium hover:opacity-90 transition-opacity"
            >
              Начать диалог
            </Link>
          </div>
        </div>
      )}

      {/* Floating button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full gradient-bg shadow-lg shadow-purple-500/30 flex items-center justify-center hover:scale-110 transition-transform"
      >
        {isOpen ? (
          <X className="w-6 h-6 text-white" />
        ) : (
          <div className="relative">
            <Sparkles className="w-6 h-6 text-white" />
            {/* Pulse ring */}
            <span className="absolute inset-0 rounded-full gradient-bg animate-ping opacity-30" />
          </div>
        )}
      </button>
    </>
  );
}
