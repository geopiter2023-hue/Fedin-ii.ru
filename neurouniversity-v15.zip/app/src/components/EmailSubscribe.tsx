import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Mail, Check, Bell } from "lucide-react";

export default function EmailSubscribe() {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const subscribe = trpc.email.subscribe.useMutation({
    onSuccess: () => {
      setSubscribed(true);
      setEmail("");
      setName("");
    },
  });

  if (subscribed) {
    return (
      <Card className="bg-gradient-to-r from-green-900/30 to-cyan-900/30 border-green-500/30">
        <CardContent className="p-6 text-center">
          <Check size={32} className="text-green-400 mx-auto mb-2" />
          <h3 className="text-lg font-semibold text-white">Вы подписаны!</h3>
          <p className="text-slate-400 text-sm">Спасибо за подписку на обновления НейроУниверситета</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-r from-cyan-900/30 to-purple-900/30 border-cyan-500/30">
      <CardContent className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <Bell size={24} className="text-cyan-400" />
          <div>
            <h3 className="text-lg font-semibold text-white">Подпишитесь на обновления</h3>
            <p className="text-slate-400 text-sm">Получайте уведомления о новых курсах и акциях</p>
          </div>
        </div>
        <div className="flex flex-col sm:flex-row gap-2">
          <Input
            type="text"
            placeholder="Ваше имя (необязательно)"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="bg-slate-950 border-slate-600 text-white sm:w-1/3"
          />
          <div className="flex-1 flex gap-2">
            <Input
              type="email"
              placeholder="Ваш email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-slate-950 border-slate-600 text-white flex-1"
            />
            <Button
              onClick={() => {
                if (email.includes("@")) {
                  subscribe.mutate({ email, name: name || undefined });
                }
              }}
              disabled={!email.includes("@") || subscribe.isPending}
              className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
            >
              <Mail size={16} className="mr-1" />
              {subscribe.isPending ? "..." : "OK"}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
