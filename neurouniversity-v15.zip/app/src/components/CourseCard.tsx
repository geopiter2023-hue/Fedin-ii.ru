import { Link } from "react-router";
import { Clock, Star, BookOpen } from "lucide-react";

interface CourseCardProps {
  course: {
    id: number;
    slug: string;
    title: string;
    subtitle?: string | null;
    description?: string | null;
    image?: string | null;
    level: string;
    category: string;
    price: string;
    oldPrice?: string | null;
    duration?: string | null;
    lessonsCount: number;
    studentsCount: number;
    rating: string | null;
  };
  showProgress?: boolean;
  completedLessons?: number;
  totalLessons?: number;
}

const levelLabels: Record<string, string> = {
  beginner: "Начинающий",
  intermediate: "Средний",
  advanced: "Продвинутый",
};

const levelColors: Record<string, string> = {
  beginner: "bg-emerald-500/15 text-emerald-400",
  intermediate: "bg-amber-500/15 text-amber-400",
  advanced: "bg-rose-500/15 text-rose-400",
};

export default function CourseCard({
  course,
  showProgress,
  completedLessons = 0,
  totalLessons = 0,
}: CourseCardProps) {
  const price = parseFloat(course.price);
  const oldPrice = course.oldPrice ? parseFloat(course.oldPrice) : null;
  const progressPercent =
    totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;

  return (
    <div className="group rounded-2xl bg-[#12121A] border border-white/[0.06] overflow-hidden hover:-translate-y-1 hover:shadow-xl hover:shadow-purple-500/10 transition-all duration-300">
      {/* Image */}
      <div className="relative aspect-video overflow-hidden">
        <img
          src={course.image || "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&q=80"}
          alt={course.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3">
          <span
            className={`px-2.5 py-1 rounded-full text-xs font-medium ${
              levelColors[course.level] || levelColors.beginner
            }`}
          >
            {levelLabels[course.level] || course.level}
          </span>
        </div>
        <div className="absolute top-3 right-3">
          <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-white/10 text-white backdrop-blur-sm">
            {course.category}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-5">
        <h3 className="text-base font-semibold text-white line-clamp-2 mb-1">
          {course.title}
        </h3>
        <p className="text-sm text-slate-400 line-clamp-2 mb-3">
          {course.subtitle || course.description}
        </p>

        {/* Meta */}
        <div className="flex items-center gap-4 text-xs text-slate-500 mb-4">
          <span className="flex items-center gap-1">
            <BookOpen className="w-3.5 h-3.5" />
            {course.lessonsCount} уроков
          </span>
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            {course.duration}
          </span>
          <span className="flex items-center gap-1">
            <Star className="w-3.5 h-3.5 text-amber-400" />
            {course.rating}
          </span>
        </div>

        {/* Progress */}
        {showProgress && totalLessons > 0 && (
          <div className="mb-4">
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-slate-400">
                {completedLessons}/{totalLessons} уроков
              </span>
              <span className="text-[#8B5CF6]">{progressPercent}%</span>
            </div>
            <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full gradient-bg transition-all duration-700"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold gradient-text">
              {price.toLocaleString("ru-RU")} ₽
            </span>
            {oldPrice && (
              <span className="text-sm text-slate-500 line-through">
                {oldPrice.toLocaleString("ru-RU")} ₽
              </span>
            )}
          </div>
          <Link
            to={
              showProgress && progressPercent > 0
                ? `/learn/${course.slug}`
                : `/courses/${course.slug}`
            }
          >
            <button className="px-4 py-2 rounded-xl text-sm font-medium gradient-bg text-white hover:opacity-90 transition-opacity">
              {showProgress && progressPercent > 0
                ? "Продолжить"
                : "Подробнее"}
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
