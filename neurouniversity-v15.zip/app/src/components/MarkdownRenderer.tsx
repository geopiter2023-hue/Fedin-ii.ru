import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

interface MarkdownRendererProps {
  content: string;
}

export default function MarkdownRenderer({ content }: MarkdownRendererProps) {
  return (
    <div className="prose prose-invert max-w-none prose-headings:text-white prose-headings:font-semibold prose-h2:text-xl prose-h2:mt-6 prose-h2:mb-3 prose-h3:text-lg prose-h3:mt-4 prose-h3:mb-2 prose-p:text-slate-300 prose-p:leading-relaxed prose-p:mb-3 prose-li:text-slate-300 prose-li:my-1 prose-strong:text-white prose-strong:font-semibold prose-a:text-[#8B5CF6] prose-a:no-underline hover:prose-a:underline prose-blockquote:border-l-[#8B5CF6] prose-blockquote:bg-[#8B5CF6]/5 prose-blockquote:py-1 prose-blockquote:px-4 prose-blockquote:rounded-r-lg prose-code:text-[#EC4899] prose-code:bg-white/5 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-pre:bg-[#12121A] prose-pre:border prose-pre:border-white/[0.06]">
      <ReactMarkdown remarkPlugins={[remarkGfm]}>{content}</ReactMarkdown>
    </div>
  );
}
