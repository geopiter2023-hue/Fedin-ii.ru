import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Key, Check, AlertCircle, Gift, Copy } from "lucide-react";

export default function TestKeyActivator() {
  const { isAuthenticated } = useAuth();
  const [code, setCode] = useState("");
  const [result, setResult] = useState<{
    success: boolean;
    message: string;
  } | null>(null);

  const activate = trpc.accessKey.activate.useMutation({
    onSuccess: (data) => {
      setResult({
        success: data.success,
        message: data.success
          ? data.message || "Курс разблокирован!"
          : data.error || "Ошибка активации",
      });
      if (data.success) setCode("");
    },
    onError: (err) => {
      setResult({ success: false, message: err.message });
    },
  });

  const availableKeys = [
    { code: "NEUROTEST2025", desc: "Тестовый доступ (100 активаций)" },
    { code: "STUDENT2025", desc: "Студенческий доступ (500 активаций)" },
    { code: "BETA2025", desc: "Бета-доступ (200 активаций)" },
    { code: "PROMO50", desc: "Промо-доступ (50 активаций)" },
  ];

  return (
    <Card className="bg-gradient-to-r from-purple-900/30 to-cyan-900/30 border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-lg text-white flex items-center gap-2">
          <Key size={20} className="text-purple-400" />
          Тестовый доступ к курсам
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!isAuthenticated ? (
          <div className="text-center py-2">
            <p className="text-slate-400 text-sm">
              Войдите, чтобы активировать тестовый ключ
            </p>
          </div>
        ) : (
          <>
            <div className="flex gap-2">
              <Input
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Введите тестовый ключ"
                className="bg-slate-950 border-slate-600 text-white flex-1 uppercase"
                onKeyDown={(e) => {
                  if (e.key === "Enter" && code.trim()) {
                    activate.mutate({ code: code.trim() });
                  }
                }}
              />
              <Button
                onClick={() => code.trim() && activate.mutate({ code: code.trim() })}
                disabled={!code.trim() || activate.isPending}
                className="bg-gradient-to-r from-purple-500 to-cyan-500 hover:from-purple-600 hover:to-cyan-600"
              >
                {activate.isPending ? "..." : <Key size={16} />}
              </Button>
            </div>

            {result && (
              <div
                className={`flex items-center gap-2 text-sm p-3 rounded-lg ${
                  result.success
                    ? "bg-green-500/10 text-green-400"
                    : "bg-red-500/10 text-red-400"
                }`}
              >
                {result.success ? <Check size={16} /> : <AlertCircle size={16} />}
                {result.message}
              </div>
            )}

            <div className="border-t border-slate-700/50 pt-4">
              <p className="text-xs text-slate-500 mb-3 flex items-center gap-1">
                <Gift size={12} />
                Доступные тестовые ключи (скопируйте и активируйте):
              </p>
              <div className="space-y-2">
                {availableKeys.map((k) => (
                  <div
                    key={k.code}
                    className="flex items-center justify-between bg-slate-950/50 rounded-lg px-3 py-2"
                  >
                    <div>
                      <code className="text-cyan-400 text-sm font-mono font-bold">
                        {k.code}
                      </code>
                      <p className="text-slate-500 text-xs">{k.desc}</p>
                    </div>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(k.code);
                        setCode(k.code);
                      }}
                      className="text-slate-400 hover:text-white transition-colors p-1"
                      title="Копировать"
                    >
                      <Copy size={14} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
