import { useState } from "react";
import { Link } from "react-router";
import Navbar from "@/components/Navbar";
import {
  Brain,
  MessageSquare,
  Palette,
  Video,
  Music,
  Code2,
  BarChart3,
  Bot,
  Package,
  Shield,
  Zap,
  CheckCircle2,
  Circle,
  ArrowRight,
  Sparkles,
  Target,
  TrendingUp,
  Volume2,
  Lock,
  Unlock,
} from "lucide-react";

interface Skill {
  id: string;
  title: string;
  icon: React.ElementType;
  description: string;
  tools: string[];
  level: "beginner" | "intermediate" | "advanced";
  status: "available" | "planned" | "locked";
  courseSlug?: string;
  color: string;
}

interface Category {
  id: string;
  title: string;
  description: string;
  icon: React.ElementType;
  skills: Skill[];
  color: string;
  bgColor: string;
}

const categories: Category[] = [
  {
    id: "foundation",
    title: "База ИИ",
    description: "Начни с фундамента — пойми, как работает искусственный интеллект",
    icon: Brain,
    color: "#8B5CF6",
    bgColor: "bg-[#8B5CF6]/10",
    skills: [
      {
        id: "ai-basics",
        title: "Нейросети с нуля",
        icon: Brain,
        description: "Пойми, что такое нейросеть, как она думает и учится. Без кода, без математики.",
        tools: ["ChatGPT", "Midjourney", "Claude"],
        level: "beginner",
        status: "available",
        courseSlug: "neural-networks-from-scratch",
        color: "#8B5CF6",
      },
      {
        id: "chatgpt",
        title: "ChatGPT Мастер",
        icon: MessageSquare,
        description: "Используй ChatGPT на 100%. Промпты, автоматизация, 50+ шаблонов.",
        tools: ["ChatGPT", "GPT-4", "Claude"],
        level: "beginner",
        status: "available",
        courseSlug: "chatgpt-master",
        color: "#EC4899",
      },
      {
        id: "midjourney",
        title: "Midjourney Pro",
        icon: Palette,
        description: "Создавай профессиональные изображения. Стили, персонажи, логотипы.",
        tools: ["Midjourney", "DALL-E", "Stable Diffusion"],
        level: "beginner",
        status: "available",
        courseSlug: "midjourney-creative",
        color: "#EC4899",
      },
    ],
  },
  {
    id: "content",
    title: "Контент и тексты",
    description: "Создавай тексты, изображения, видео и аудио с помощью ИИ",
    icon: Sparkles,
    color: "#10B981",
    bgColor: "bg-emerald-500/10",
    skills: [
      {
        id: "copywriting",
        title: "AI Копирайтинг",
        icon: MessageSquare,
        description: "Пиши продающие тексты, статьи, email-рассылки, посты для соцсетей.",
        tools: ["ChatGPT", "Jasper", "Copy.ai"],
        level: "beginner",
        status: "available",
        courseSlug: "ai-copywriting",
        color: "#10B981",
      },
      {
        id: "video",
        title: "AI Видео",
        icon: Video,
        description: "Создавай видеоролики, анимацию, рекламные клипы без камеры.",
        tools: ["Sora", "Runway", "CapCut AI"],
        level: "intermediate",
        status: "available",
        courseSlug: "ai-video-generation",
        color: "#10B981",
      },
      {
        id: "audio",
        title: "AI Аудио",
        icon: Music,
        description: "Генерируй музыку, озвучку, подкасты, звуковые эффекты.",
        tools: ["Suno", "ElevenLabs", "Murf"],
        level: "intermediate",
        status: "planned",
        color: "#10B981",
      },
    ],
  },
  {
    id: "work",
    title: "Для работы",
    description: "Внедряй ИИ в профессиональную деятельность",
    icon: Target,
    color: "#F59E0B",
    bgColor: "bg-amber-500/10",
    skills: [
      {
        id: "marketing",
        title: "AI Маркетинг",
        icon: TrendingUp,
        description: "Автоматизируй маркетинг. Креативы, анализ конкурентов, SMM.",
        tools: ["ChatGPT", "Canva AI", "Metricool"],
        level: "intermediate",
        status: "available",
        courseSlug: "ai-for-marketers",
        color: "#F59E0B",
      },
      {
        id: "design",
        title: "AI Дизайн",
        icon: Palette,
        description: "Создавай мокапы, UI-киты, иллюстрации. AI-плагины для Figma.",
        tools: ["Midjourney", "Figma AI", "Photoshop AI"],
        level: "intermediate",
        status: "available",
        courseSlug: "ai-for-designers",
        color: "#F59E0B",
      },
      {
        id: "data",
        title: "AI Анализ данных",
        icon: BarChart3,
        description: "Анализируй таблицы, создавай отчёты, прогнозируй тренды.",
        tools: ["ChatGPT", "Claude", "Julius AI"],
        level: "intermediate",
        status: "available",
        courseSlug: "ai-data-analysis",
        color: "#F59E0B",
      },
    ],
  },
  {
    id: "advanced",
    title: "Продвинутый уровень",
    description: "Стань экспертом в ИИ — создавай автоматизацию и агентов",
    icon: Zap,
    color: "#EF4444",
    bgColor: "bg-rose-500/10",
    skills: [
      {
        id: "prompt",
        title: "Prompt Engineering",
        icon: Target,
        description: "Мастерство промптов. Chain-of-Thought, Few-shot, оптимизация.",
        tools: ["ChatGPT", "Claude", "Anthropic Console"],
        level: "advanced",
        status: "available",
        courseSlug: "prompt-engineering",
        color: "#EF4444",
      },
      {
        id: "agents",
        title: "AI Агенты",
        icon: Bot,
        description: "Создавай автономных ИИ-ассистентов. No-code автоматизация.",
        tools: ["n8n", "Make", "Zapier"],
        level: "advanced",
        status: "available",
        courseSlug: "ai-agents",
        color: "#EF4444",
      },
      {
        id: "business",
        title: "AI для бизнеса",
        icon: TrendingUp,
        description: "Автоматизируй бизнес-процессы. CRM, HR, финансы с ИИ.",
        tools: ["ChatGPT", "n8n", "Notion AI"],
        level: "intermediate",
        status: "available",
        courseSlug: "ai-business-automation",
        color: "#EF4444",
      },
    ],
  },
  {
    id: "security",
    title: "Безопасность",
    description: "Защити данные при работе с ИИ",
    icon: Shield,
    color: "#06B6D4",
    bgColor: "bg-cyan-500/10",
    skills: [
      {
        id: "security",
        title: "Защита данных в эпоху AI",
        icon: Shield,
        description: "Что нельзя отправлять в ИИ. Настройки приватности, локальные модели.",
        tools: ["Local LLMs", "Ollama", "Private GPT"],
        level: "beginner",
        status: "available",
        courseSlug: "ai-data-security",
        color: "#06B6D4",
      },
    ],
  },
  {
    id: "new2025",
    title: "Новинки 2025 🔥",
    description: "Самые актуальные AI-навыки этого года",
    icon: Zap,
    color: "#EC4899",
    bgColor: "bg-pink-500/10",
    skills: [
      {
        id: "cursor",
        title: "Программирование с Cursor",
        icon: Code2,
        description: "Пиши код как senior с Cursor IDE и GitHub Copilot. Сайты, боты, приложения.",
        tools: ["Cursor", "Copilot", "Windsurf"],
        level: "beginner",
        status: "available",
        courseSlug: "ai-coding-cursor",
        color: "#EC4899",
      },
      {
        id: "music",
        title: "Создание музыки с Suno",
        icon: Music,
        description: "Генерируй треки любого жанра за минуты. Для блогеров, геймдевов, музыкантов.",
        tools: ["Suno", "Udio", "ElevenLabs"],
        level: "beginner",
        status: "available",
        courseSlug: "ai-music-generation",
        color: "#EC4899",
      },
      {
        id: "photo-ai",
        title: "AI-обработка фотографий",
        icon: Palette,
        description: "Photoshop AI, Generative Fill, удаление объектов, замена фона за секунды.",
        tools: ["Photoshop AI", "Topaz", "Clipdrop"],
        level: "beginner",
        status: "available",
        courseSlug: "ai-photo-editing",
        color: "#EC4899",
      },
      {
        id: "youtube",
        title: "AI для YouTube и блогеров",
        icon: Video,
        description: "Сценарии, превью, субтитры, озвучка — создавай контент в 10 раз быстрее.",
        tools: ["ChatGPT", "CapCut", "ElevenLabs"],
        level: "beginner",
        status: "available",
        courseSlug: "ai-youtube-blogger",
        color: "#EC4899",
      },
      {
        id: "ecommerce",
        title: "AI для E-commerce",
        icon: TrendingUp,
        description: "Описания товаров, фото, чат-боты. Для Wildberries, Ozon, Shopify.",
        tools: ["ChatGPT", "Canva", "n8n"],
        level: "intermediate",
        status: "available",
        courseSlug: "ai-ecommerce",
        color: "#EC4899",
      },
      {
        id: "presentations",
        title: "AI презентации и документы",
        icon: Sparkles,
        description: "Gamma, Beautiful.ai — создавай презентации и отчёты за минуты.",
        tools: ["Gamma", "Beautiful.ai", "Tome"],
        level: "beginner",
        status: "available",
        courseSlug: "ai-presentation-gamma",
        color: "#EC4899",
      },
      {
        id: "tg-bots",
        title: "Telegram-боты с AI без кода",
        icon: Bot,
        description: "Создавай умных ботов с ChatGPT для бизнеса. Заявки, CRM, рассылки.",
        tools: ["Botpress", "n8n", "Make"],
        level: "beginner",
        status: "available",
        courseSlug: "ai-telegram-bots",
        color: "#EC4899",
      },
      {
        id: "dubbing",
        title: "AI-дубляж и перевод видео",
        icon: Volume2,
        description: "Озвучивай видео на 50+ языках. HeyGen, клон голоса, синхронизация губ.",
        tools: ["HeyGen", "ElevenLabs", "Rask AI"],
        level: "intermediate",
        status: "available",
        courseSlug: "ai-dubbing-translation",
        color: "#EC4899",
      },
      {
        id: "freelance",
        title: "AI для фрилансера",
        icon: Target,
        description: "Зарабатывай больше. Портфолио, КП, переписка, сметы — всё с AI.",
        tools: ["ChatGPT", "Notion AI", "Grammarly"],
        level: "beginner",
        status: "available",
        courseSlug: "ai-freelancer",
        color: "#EC4899",
      },
      {
        id: "3d",
        title: "3D-модели с AI",
        icon: Package,
        description: "Создавай 3D из текста и фото. Tripo, Meshy — для геймдева и дизайна.",
        tools: ["Tripo3D", "Meshy", "Luma AI"],
        level: "intermediate",
        status: "available",
        courseSlug: "ai-3d-generation",
        color: "#EC4899",
      },
    ],
  },
];

const levelLabels: Record<string, string> = {
  beginner: "Начинающий",
  intermediate: "Средний",
  advanced: "Продвинутый",
};

const levelColors: Record<string, string> = {
  beginner: "bg-emerald-500/15 text-emerald-400",
  intermediate: "bg-amber-500/15 text-amber-400",
  advanced: "bg-rose-500/15 text-rose-400",
};

const statusIcons: Record<string, React.ElementType> = {
  available: CheckCircle2,
  planned: Circle,
  locked: Lock,
};

export default function Roadmap() {
  const [expandedCategory, setExpandedCategory] = useState<string | null>("foundation");
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null);

  const completedCount = categories.reduce(
    (acc, cat) => acc + cat.skills.filter((s) => s.status === "available").length,
    0
  );
  const totalCount = categories.reduce((acc, cat) => acc + cat.skills.length, 0);

  return (
    <div className="min-h-screen bg-[#0A0A0F]">
      <Navbar />

      {/* Hero */}
      <div className="relative pt-16">
        <div className="relative h-72 md:h-96 overflow-hidden">
          <img
            src="/roadmap-hero.png"
            alt="AI Roadmap"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0F] via-[#0A0A0F]/70 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10">
            <div className="max-w-6xl mx-auto">
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="w-5 h-5 text-[#8B5CF6]" />
                <span className="text-sm text-[#8B5CF6] font-medium">Актуальные навыки 2025</span>
              </div>
              <h1 className="text-3xl md:text-5xl font-black text-white mb-3">
                Roadmap <span className="gradient-text">ИИ-навыков</span>
              </h1>
              <p className="text-slate-400 text-lg max-w-2xl mb-4">
                Полная карта навыков работы с искусственным интеллектом. От базовых концепций до создания автономных AI-агентов.
              </p>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10">
                  <Unlock className="w-4 h-4 text-emerald-400" />
                  <span className="text-sm text-white">{completedCount} навыков доступно</span>
                </div>
                <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10">
                  <Lock className="w-4 h-4 text-slate-500" />
                  <span className="text-sm text-slate-400">{totalCount - completedCount} в разработке</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Progress bar */}
      <div className="px-4 py-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-slate-400">Прогресс платформы</span>
            <span className="text-sm text-[#8B5CF6] font-medium">
              {Math.round((completedCount / totalCount) * 100)}%
            </span>
          </div>
          <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full gradient-bg rounded-full transition-all duration-1000"
              style={{ width: `${(completedCount / totalCount) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="px-4 pb-20">
        <div className="max-w-6xl mx-auto space-y-6">
          {categories.map((category) => (
            <div
              key={category.id}
              className="rounded-2xl bg-[#12121A] border border-white/[0.06] overflow-hidden"
            >
              {/* Category Header */}
              <button
                onClick={() =>
                  setExpandedCategory(
                    expandedCategory === category.id ? null : category.id
                  )
                }
                className="w-full flex items-center gap-4 p-5 md:p-6 text-left hover:bg-white/[0.02] transition-colors"
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `${category.color}15` }}
                >
                  <category.icon
                    className="w-6 h-6"
                    style={{ color: category.color }}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-1">
                    <h2 className="text-lg font-bold text-white">
                      {category.title}
                    </h2>
                    <span
                      className="px-2 py-0.5 rounded-full text-xs font-medium"
                      style={{
                        backgroundColor: `${category.color}15`,
                        color: category.color,
                      }}
                    >
                      {category.skills.length} навыков
                    </span>
                  </div>
                  <p className="text-sm text-slate-400 truncate">
                    {category.description}
                  </p>
                </div>
                <ArrowRight
                  className={`w-5 h-5 text-slate-500 shrink-0 transition-transform ${
                    expandedCategory === category.id ? "rotate-90" : ""
                  }`}
                />
              </button>

              {/* Skills Grid */}
              {expandedCategory === category.id && (
                <div className="px-5 md:px-6 pb-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4 border-t border-white/[0.06]">
                    {category.skills.map((skill) => {
                      const StatusIcon = statusIcons[skill.status];
                      const isHovered = hoveredSkill === skill.id;

                      return (
                        <div
                          key={skill.id}
                          onMouseEnter={() => setHoveredSkill(skill.id)}
                          onMouseLeave={() => setHoveredSkill(null)}
                          className={`relative p-5 rounded-xl border transition-all duration-300 ${
                            skill.status === "available"
                              ? "bg-[#1A1A25] border-white/[0.06] hover:-translate-y-1 hover:shadow-lg"
                              : skill.status === "planned"
                                ? "bg-[#1A1A25]/50 border-white/[0.04] opacity-70"
                                : "bg-[#1A1A25]/30 border-white/[0.04] opacity-50"
                          }`}
                          style={
                            isHovered && skill.status === "available"
                              ? {
                                  boxShadow: `0 8px 32px ${skill.color}15`,
                                  borderColor: `${skill.color}30`,
                                }
                              : {}
                          }
                        >
                          {/* Status badge */}
                          <div className="absolute top-3 right-3">
                            <StatusIcon
                              className={`w-4 h-4 ${
                                skill.status === "available"
                                  ? "text-emerald-400"
                                  : skill.status === "planned"
                                    ? "text-amber-400"
                                    : "text-slate-600"
                              }`}
                            />
                          </div>

                          {/* Icon */}
                          <div
                            className="w-10 h-10 rounded-lg flex items-center justify-center mb-3"
                            style={{ backgroundColor: `${skill.color}15` }}
                          >
                            <skill.icon
                              className="w-5 h-5"
                              style={{ color: skill.color }}
                            />
                          </div>

                          {/* Content */}
                          <h3 className="text-base font-semibold text-white mb-1">
                            {skill.title}
                          </h3>
                          <p className="text-sm text-slate-400 mb-3 line-clamp-2">
                            {skill.description}
                          </p>

                          {/* Tools */}
                          <div className="flex flex-wrap gap-1.5 mb-3">
                            {skill.tools.map((tool) => (
                              <span
                                key={tool}
                                className="px-2 py-0.5 rounded-md bg-white/5 text-xs text-slate-500"
                              >
                                {tool}
                              </span>
                            ))}
                          </div>

                          {/* Footer */}
                          <div className="flex items-center justify-between">
                            <span
                              className={`px-2 py-0.5 rounded-full text-xs font-medium ${levelColors[skill.level]}`}
                            >
                              {levelLabels[skill.level]}
                            </span>

                            {skill.status === "available" && skill.courseSlug ? (
                              <Link
                                to={`/courses/${skill.courseSlug}`}
                                className="flex items-center gap-1 text-xs font-medium transition-colors"
                                style={{ color: skill.color }}
                              >
                                К курсу
                                <ArrowRight className="w-3 h-3" />
                              </Link>
                            ) : skill.status === "planned" ? (
                              <span className="text-xs text-amber-400/70">
                                Скоро
                              </span>
                            ) : (
                              <span className="text-xs text-slate-600">
                                <Lock className="w-3 h-3 inline" />
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="px-4 pb-16">
        <div className="max-w-3xl mx-auto text-center">
          <div className="p-8 rounded-3xl bg-gradient-to-br from-[#8B5CF6]/20 via-[#12121A] to-[#EC4899]/20 border border-white/[0.06]">
            <Sparkles className="w-10 h-10 text-[#8B5CF6] mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-3">
              Начни свой путь в мир ИИ
            </h2>
            <p className="text-slate-400 mb-6 max-w-lg mx-auto">
              Выбери первый навык и начни осваивать искусственный интеллект уже сегодня. Каждый курс — это шаг к будущему.
            </p>
            <Link to="/courses">
              <button className="px-8 py-3 rounded-xl gradient-bg text-white font-semibold hover:opacity-90 transition-opacity inline-flex items-center gap-2">
                Выбрать курс
                <ArrowRight className="w-5 h-5" />
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
