import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/Navbar";
import {
  Users,
  BookOpen,
  Award,
  TrendingUp,
  Shield,
  Loader2,
} from "lucide-react";

export default function Admin() {
  const { user, isLoading } = useAuth();

  const { data: stats } = trpc.certificate.adminStats.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  const { data: certs } = trpc.certificate.adminList.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  const { data: courses } = trpc.course.list.useQuery({});

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
      </div>
    );
  }

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-16 h-16 text-rose-400 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-white mb-2">Доступ запрещён</h1>
          <p className="text-slate-400 mb-6">Эта страница только для администраторов.</p>
          <Link to="/" className="text-[#8B5CF6] hover:underline">
            На главную
          </Link>
        </div>
      </div>
    );
  }

  const statCards = [
    {
      icon: Users,
      label: "Пользователей",
      value: stats?.totalUsers || 0,
      color: "text-[#8B5CF6]",
      bg: "bg-[#8B5CF6]/10",
    },
    {
      icon: BookOpen,
      label: "Курсов",
      value: courses?.length || 0,
      color: "text-[#EC4899]",
      bg: "bg-[#EC4899]/10",
    },
    {
      icon: TrendingUp,
      label: "Покупок",
      value: stats?.totalPurchases || 0,
      color: "text-emerald-400",
      bg: "bg-emerald-500/10",
    },
    {
      icon: Award,
      label: "Сертификатов",
      value: stats?.totalCertificates || 0,
      color: "text-amber-400",
      bg: "bg-amber-500/10",
    },
  ];

  return (
    <div className="min-h-screen bg-[#0A0A0F]">
      <Navbar />
      <div className="pt-24 pb-16 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-xl bg-[#8B5CF6]/15 flex items-center justify-center">
              <Shield className="w-5 h-5 text-[#8B5CF6]" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Админ-панель</h1>
              <p className="text-sm text-slate-500">
                Управление платформой
              </p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {statCards.map((s, i) => (
              <div
                key={i}
                className="p-5 rounded-2xl bg-[#12121A] border border-white/[0.06]"
              >
                <div
                  className={`w-10 h-10 rounded-xl ${s.bg} flex items-center justify-center mb-3`}
                >
                  <s.icon className={`w-5 h-5 ${s.color}`} />
                </div>
                <div className="text-2xl font-bold text-white mb-1">
                  {s.value}
                </div>
                <div className="text-sm text-slate-500">{s.label}</div>
              </div>
            ))}
          </div>

          {/* Courses Table */}
          <div className="rounded-2xl bg-[#12121A] border border-white/[0.06] overflow-hidden mb-8">
            <div className="p-5 border-b border-white/[0.06]">
              <h2 className="text-lg font-bold text-white">Курсы</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/[0.06]">
                    <th className="text-left px-5 py-3 text-xs font-medium text-slate-500 uppercase">
                      Курс
                    </th>
                    <th className="text-left px-5 py-3 text-xs font-medium text-slate-500 uppercase">
                      Категория
                    </th>
                    <th className="text-left px-5 py-3 text-xs font-medium text-slate-500 uppercase">
                      Цена
                    </th>
                    <th className="text-left px-5 py-3 text-xs font-medium text-slate-500 uppercase">
                      Уроков
                    </th>
                    <th className="text-left px-5 py-3 text-xs font-medium text-slate-500 uppercase">
                      Студентов
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {courses?.map((course) => (
                    <tr
                      key={course.id}
                      className="border-b border-white/[0.04] hover:bg-white/[0.02]"
                    >
                      <td className="px-5 py-3">
                        <span className="text-sm text-white font-medium">
                          {course.title}
                        </span>
                      </td>
                      <td className="px-5 py-3">
                        <span className="px-2 py-0.5 rounded-full text-xs bg-white/5 text-slate-400">
                          {course.category}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-sm text-emerald-400">
                        {parseFloat(course.price).toLocaleString("ru-RU")} ₽
                      </td>
                      <td className="px-5 py-3 text-sm text-slate-400">
                        {course.lessonsCount}
                      </td>
                      <td className="px-5 py-3 text-sm text-slate-400">
                        {course.studentsCount}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Certificates Table */}
          <div className="rounded-2xl bg-[#12121A] border border-white/[0.06] overflow-hidden">
            <div className="p-5 border-b border-white/[0.06]">
              <h2 className="text-lg font-bold text-white">Сертификаты</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/[0.06]">
                    <th className="text-left px-5 py-3 text-xs font-medium text-slate-500 uppercase">
                      №
                    </th>
                    <th className="text-left px-5 py-3 text-xs font-medium text-slate-500 uppercase">
                      Пользователь
                    </th>
                    <th className="text-left px-5 py-3 text-xs font-medium text-slate-500 uppercase">
                      Курс
                    </th>
                    <th className="text-left px-5 py-3 text-xs font-medium text-slate-500 uppercase">
                      Дата
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {certs?.map((cert) => (
                    <tr
                      key={cert.id}
                      className="border-b border-white/[0.04] hover:bg-white/[0.02]"
                    >
                      <td className="px-5 py-3 text-sm font-mono text-[#8B5CF6]">
                        {cert.certificateNumber.slice(0, 20)}...
                      </td>
                      <td className="px-5 py-3 text-sm text-white">
                        {cert.userName || "—"}
                        <span className="text-slate-500 ml-2">
                          {cert.userEmail}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-sm text-slate-300">
                        {cert.courseTitle}
                      </td>
                      <td className="px-5 py-3 text-sm text-slate-400">
                        {cert.issuedAt
                          ? new Date(cert.issuedAt).toLocaleDateString("ru-RU")
                          : "—"}
                      </td>
                    </tr>
                  ))}
                  {(!certs || certs.length === 0) && (
                    <tr>
                      <td
                        colSpan={4}
                        className="px-5 py-8 text-center text-slate-500"
                      >
                        Пока нет выданных сертификатов
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
