import { useState, useEffect } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Gift, Users, Award, Copy, Check, Link as LinkIcon, ArrowRight } from "lucide-react";
import { Link } from "react-router";

export default function ReferralPage() {
  const { isAuthenticated } = useAuth();
  const [copied, setCopied] = useState(false);

  const { data: codeData } = trpc.referral.myCode.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const { data: stats } = trpc.referral.stats.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const trackMutation = trpc.referral.track.useMutation();

  // Track referral on mount if ref param exists
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get("ref");
    if (ref && isAuthenticated) {
      trackMutation.mutate({ code: ref });
    }
  }, [isAuthenticated]);

  const copyLink = () => {
    if (codeData?.link) {
      navigator.clipboard.writeText(codeData.link);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white flex items-center justify-center">
        <Card className="bg-slate-900/80 border-slate-700/50 max-w-md w-full mx-4">
          <CardHeader className="text-center">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500 to-purple-500 flex items-center justify-center mx-auto mb-4">
              <Gift size={32} />
            </div>
            <CardTitle className="text-2xl text-white">Реферальная программа</CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-slate-400">
              Приглашайте друзей и получайте бонусы! Войдите в систему, чтобы участвовать в программе.
            </p>
            <Link to="/login">
              <Button className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600">
                Войти в систему
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white">
      <div className="max-w-5xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
            Реферальная программа
          </h1>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Приглашайте друзей в НейроУниверситет и получайте по 500 рублей за каждого!
          </p>
        </div>

        {/* Stats cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
          <Card className="bg-slate-900/60 border-slate-700/50">
            <CardContent className="p-6 text-center">
              <Users className="mx-auto mb-3 text-cyan-400" size={32} />
              <div className="text-3xl font-bold text-white">{stats?.invited || 0}</div>
              <div className="text-slate-400 text-sm">Приглашено друзей</div>
            </CardContent>
          </Card>
          <Card className="bg-slate-900/60 border-slate-700/50">
            <CardContent className="p-6 text-center">
              <Award className="mx-auto mb-3 text-purple-400" size={32} />
              <div className="text-3xl font-bold text-white">{stats?.completed || 0}</div>
              <div className="text-slate-400 text-sm">Успешных регистраций</div>
            </CardContent>
          </Card>
          <Card className="bg-slate-900/60 border-slate-700/50">
            <CardContent className="p-6 text-center">
              <Gift className="mx-auto mb-3 text-green-400" size={32} />
              <div className="text-3xl font-bold text-white">{stats?.bonus || 0} ₽</div>
              <div className="text-slate-400 text-sm">Заработано бонусов</div>
            </CardContent>
          </Card>
        </div>

        {/* Referral link */}
        <Card className="bg-gradient-to-r from-cyan-900/30 to-purple-900/30 border-cyan-500/30 mb-10">
          <CardHeader>
            <CardTitle className="text-lg text-white flex items-center gap-2">
              <LinkIcon size={20} />
              Ваша реферальная ссылка
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <div className="flex-1 bg-slate-950 rounded-lg px-4 py-3 text-slate-300 font-mono text-sm truncate">
                {codeData?.link || "Загрузка..."}
              </div>
              <Button
                onClick={copyLink}
                variant="outline"
                className="border-slate-600 hover:bg-slate-800 text-white"
              >
                {copied ? <Check size={18} className="text-green-400" /> : <Copy size={18} />}
              </Button>
            </div>
            {copied && (
              <p className="text-green-400 text-sm">Ссылка скопирована в буфер обмена!</p>
            )}
          </CardContent>
        </Card>

        {/* How it works */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              step: "01",
              title: "Поделитесь ссылкой",
              desc: "Отправьте вашу уникальную реферальную ссылку друзьям в любой удобный способ",
              icon: <LinkIcon size={24} className="text-cyan-400" />,
            },
            {
              step: "02",
              title: "Друг регистрируется",
              desc: "Ваш друг переходит по ссылке и создает аккаунт в НейроУниверситете",
              icon: <Users size={24} className="text-purple-400" />,
            },
            {
              step: "03",
              title: "Получите бонус",
              desc: "За каждую успешную регистрацию вы получаете 500 рублей на баланс",
              icon: <Gift size={24} className="text-green-400" />,
            },
          ].map((item) => (
            <Card key={item.step} className="bg-slate-900/60 border-slate-700/50 relative overflow-hidden">
              <div className="absolute top-2 right-4 text-6xl font-bold text-slate-800/50">
                {item.step}
              </div>
              <CardContent className="p-6 relative z-10">
                <div className="mb-4">{item.icon}</div>
                <h3 className="text-lg font-semibold text-white mb-2">{item.title}</h3>
                <p className="text-slate-400 text-sm">{item.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-10">
          <Link to="/courses">
            <Button
              size="lg"
              className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
            >
              Выбрать курс для изучения
              <ArrowRight size={18} className="ml-2" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
