import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Newspaper,
  RefreshCw,
  ExternalLink,
  Clock,
  Globe,
  Sparkles,
  Bot,
  Brain,
} from "lucide-react";

const categoryColors: Record<string, string> = {
  AI: "bg-purple-500/20 text-purple-400",
  ML: "bg-cyan-500/20 text-cyan-400",
  OpenAI: "bg-green-500/20 text-green-400",
  Google: "bg-blue-500/20 text-blue-400",
  Anthropic: "bg-orange-500/20 text-orange-400",
  Meta: "bg-indigo-500/20 text-indigo-400",
  General: "bg-slate-500/20 text-slate-400",
};

export default function AiNewsPage() {
  const [isSyncing, setIsSyncing] = useState(false);
  const { data: news, isLoading, refetch } = trpc.rss.latest.useQuery({ limit: 50 });
  const { data: syncResult, refetch: refetchSync } = trpc.rss.sync.useQuery(
    undefined,
    { enabled: false }
  );

  const handleSync = async () => {
    setIsSyncing(true);
    await refetchSync();
    await refetch();
    setIsSyncing(false);
  };

  const categories = [...new Set(news?.map((n) => n.category).filter(Boolean) || [])];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white">
      <div className="max-w-5xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
            AI-новости
          </h1>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Автоматически обновляемая лента новостей из мира искусственного интеллекта
          </p>
          <div className="flex items-center justify-center gap-4 mt-6">
            <Button
              onClick={handleSync}
              disabled={isSyncing}
              className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
            >
              <RefreshCw
                size={16}
                className={`mr-2 ${isSyncing ? "animate-spin" : ""}`}
              />
              {isSyncing ? "Обновление..." : "Обновить новости"}
            </Button>
            <Badge variant="outline" className="border-slate-600 text-slate-400">
              <Bot size={12} className="mr-1" />
              {news?.length || 0} новостей
            </Badge>
          </div>
          {syncResult && (
            <p className="text-green-400 text-sm mt-2">
              Добавлено {syncResult.synced} новых новостей
            </p>
          )}
        </div>

        {/* Categories */}
        {categories.length > 0 && (
          <div className="flex flex-wrap gap-2 justify-center mb-8">
            <Badge className="bg-purple-500/20 text-purple-400 cursor-pointer">Все</Badge>
            {categories.map((cat) => (
              <Badge
                key={cat}
                variant="outline"
                className={categoryColors[cat || "General"] || "bg-slate-500/20 text-slate-400"}
              >
                {cat}
              </Badge>
            ))}
          </div>
        )}

        {/* Sources info */}
        <Card className="bg-slate-900/60 border-slate-700/50 mb-8">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-sm text-slate-400">
              <Globe size={16} className="text-cyan-400" />
              <span>Источники:</span>
              <span className="text-slate-300">Habr AI, Habr ML, OpenAI Blog</span>
              <Sparkles size={14} className="text-purple-400 ml-2" />
              <span className="text-slate-500">Автообновление каждые 6 часов</span>
            </div>
          </CardContent>
        </Card>

        {/* News list */}
        {isLoading ? (
          <div className="text-center py-12 text-slate-400">
            <RefreshCw size={32} className="animate-spin mx-auto mb-4" />
            Загрузка новостей...
          </div>
        ) : news && news.length > 0 ? (
          <div className="space-y-4">
            {news.map((item) => (
              <Card
                key={item.id}
                className="bg-slate-900/60 border-slate-700/50 hover:border-purple-500/30 transition-all group"
              >
                <CardContent className="p-5">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge
                          className={
                            categoryColors[item.category || "General"] ||
                            "bg-slate-500/20 text-slate-400"
                          }
                        >
                          {item.category || "General"}
                        </Badge>
                        <span className="text-xs text-slate-500 flex items-center gap-1">
                          <Clock size={10} />
                          {item.publishedAt
                            ? new Date(item.publishedAt).toLocaleDateString("ru-RU")
                            : ""}
                        </span>
                        <span className="text-xs text-slate-600 flex items-center gap-1">
                          <Newspaper size={10} />
                          {item.source}
                        </span>
                      </div>
                      <h3 className="text-white font-medium mb-2 group-hover:text-purple-400 transition-colors">
                        {item.title}
                      </h3>
                      {item.summary && (
                        <p className="text-slate-400 text-sm line-clamp-3">{item.summary}</p>
                      )}
                    </div>
                    {item.sourceUrl && (
                      <a
                        href={item.sourceUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="shrink-0 text-slate-500 hover:text-cyan-400 transition-colors p-2"
                      >
                        <ExternalLink size={18} />
                      </a>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <Brain size={48} className="text-slate-700 mx-auto mb-4" />
            <p className="text-slate-400 text-lg mb-2">Новостей пока нет</p>
            <p className="text-slate-500 text-sm mb-6">
              Нажмите "Обновить новости" чтобы загрузить актуальные новости из RSS-источников
            </p>
            <Button
              onClick={handleSync}
              disabled={isSyncing}
              className="bg-gradient-to-r from-cyan-500 to-purple-500"
            >
              <RefreshCw
                size={16}
                className={`mr-2 ${isSyncing ? "animate-spin" : ""}`}
              />
              Загрузить новости
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
