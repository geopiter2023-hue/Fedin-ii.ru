import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import MarkdownRenderer from "@/components/MarkdownRenderer";
import {
  CheckCircle,
  Lock,
  Play,
  Pause,
  ChevronLeft,
  ChevronRight,
  BookOpen,
  ArrowLeft,
  Circle,
  Volume2,
  Maximize,
  SkipBack,
  SkipForward,
} from "lucide-react";

function VideoPlayer({
  lesson,
  courseImage,
  canAccess,
  courseSlug,
}: {
  lesson: { title: string; duration: string | null; isFree: boolean | null };
  courseImage: string;
  canAccess: boolean;
  courseSlug: string;
}) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isHovering, setIsHovering] = useState(false);

  if (!canAccess) {
    return (
      <div className="relative aspect-video rounded-2xl bg-[#12121A] border border-white/[0.06] overflow-hidden mb-6 flex flex-col items-center justify-center">
        <div className="absolute inset-0">
          <img
            src={courseImage}
            alt=""
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-black/60" />
        </div>
        <div className="relative z-10 text-center p-6">
          <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-4 border border-white/10">
            <Lock className="w-7 h-7 text-slate-400" />
          </div>
          <p className="text-white font-semibold mb-2">Урок заблокирован</p>
          <p className="text-sm text-slate-400 mb-5 max-w-sm">
            Купите курс, чтобы получить доступ ко всем урокам
          </p>
          <Link
            to={`/courses/${courseSlug}`}
            className="inline-flex px-6 py-2.5 rounded-xl gradient-bg text-white text-sm font-medium hover:opacity-90 transition-opacity"
          >
            Купить курс
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div
      className="relative aspect-video rounded-2xl overflow-hidden mb-6 group"
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      {/* Background image */}
      <img
        src={courseImage}
        alt=""
        className={`absolute inset-0 w-full h-full object-cover transition-all duration-500 ${
          isPlaying ? "opacity-40 scale-105" : "opacity-60"
        }`}
      />
      <div
        className={`absolute inset-0 transition-opacity duration-300 ${
          isPlaying
            ? "bg-gradient-to-t from-black/80 via-black/40 to-transparent"
            : "bg-black/50"
        }`}
      />

      {/* Center play button */}
      {!isPlaying && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
          <button
            onClick={() => {
              setIsPlaying(true);
              // Simulate progress
              let p = 0;
              const interval = setInterval(() => {
                p += 2;
                setProgress(p);
                if (p >= 100) {
                  clearInterval(interval);
                  setTimeout(() => setIsPlaying(false), 500);
                }
              }, 100);
            }}
            className="w-20 h-20 rounded-full gradient-bg flex items-center justify-center shadow-lg shadow-purple-500/30 hover:scale-110 transition-transform duration-200 mb-4"
          >
            <Play className="w-9 h-9 text-white ml-1" fill="white" />
          </button>
          <p className="text-white font-medium text-lg">{lesson.title}</p>
          <p className="text-sm text-slate-400 mt-1">
            Длительность: {lesson.duration}
          </p>
          {lesson.isFree && (
            <span className="mt-2 px-3 py-1 rounded-full text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/20">
              Бесплатный урок
            </span>
          )}
        </div>
      )}

      {/* Playing state overlay */}
      {isPlaying && progress < 100 && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
          <div className="w-16 h-16 rounded-full border-2 border-white/20 flex items-center justify-center mb-4">
            <Pause className="w-7 h-7 text-white" />
          </div>
          <p className="text-white font-medium mb-2">Загрузка видео...</p>
          <div className="w-48 h-1 bg-white/20 rounded-full overflow-hidden">
            <div
              className="h-full gradient-bg rounded-full transition-all duration-100"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-xs text-slate-400 mt-3">
            Видео будет доступно в ближайшее время
          </p>
        </div>
      )}

      {isPlaying && progress >= 100 && (
        <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
          <p className="text-white font-medium mb-2">Видео скоро будет доступно</p>
          <p className="text-sm text-slate-400">
        Запись урока в процессе подготовки
          </p>
          <button
            onClick={() => {
              setIsPlaying(false);
              setProgress(0);
            }}
            className="mt-4 px-4 py-2 rounded-lg bg-white/10 text-sm text-white hover:bg-white/20 transition-colors"
          >
            Закрыть
          </button>
        </div>
      )}

      {/* Bottom controls bar */}
      {isPlaying && (
        <div
          className={`absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/90 to-transparent z-20 transition-opacity duration-300 ${
            isHovering ? "opacity-100" : "opacity-0"
          }`}
        >
          {/* Progress bar */}
          <div className="w-full h-1 bg-white/20 rounded-full mb-3 cursor-pointer">
            <div
              className="h-full gradient-bg rounded-full"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsPlaying(false)}
                className="text-white hover:text-[#8B5CF6] transition-colors"
              >
                <SkipBack className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  setIsPlaying(false);
                  setProgress(0);
                }}
                className="text-white hover:text-[#8B5CF6] transition-colors"
              >
                <Pause className="w-5 h-5" />
              </button>
              <button className="text-white hover:text-[#8B5CF6] transition-colors">
                <SkipForward className="w-4 h-4" />
              </button>
              <span className="text-xs text-slate-400 ml-2">
                00:00 / {lesson.duration}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <Volume2 className="w-4 h-4 text-slate-400" />
              <Maximize className="w-4 h-4 text-slate-400" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function Learn() {
  const { courseSlug, lessonId } = useParams<{
    courseSlug: string;
    lessonId?: string;
  }>();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  const { data: course } = trpc.course.getBySlug.useQuery(
    { slug: courseSlug || "" },
    { enabled: !!courseSlug }
  );

  const { data: lessonsList } = trpc.course.getLessons.useQuery(
    { courseId: course?.id || 0 },
    { enabled: !!course?.id }
  );

  const { data: hasAccess } = trpc.purchase.checkAccess.useQuery(
    { courseId: course?.id || 0 },
    { enabled: !!course?.id && isAuthenticated }
  );

  const { data: progressData } = trpc.lesson.getProgress.useQuery(
    { courseId: course?.id || 0 },
    { enabled: !!course?.id && isAuthenticated }
  );

  const utils = trpc.useUtils();
  const markComplete = trpc.lesson.markComplete.useMutation({
    onSuccess: () => {
      utils.lesson.getProgress.invalidate();
      utils.user.getDashboard.invalidate();
    },
  });

  const completedLessonIds = new Set(
    progressData?.lessons.filter((l) => l.isCompleted).map((l) => l.id) || []
  );

  const currentLessonId = lessonId
    ? parseInt(lessonId)
    : lessonsList?.[0]?.id;

  const currentLesson = lessonsList?.find((l) => l.id === currentLessonId);

  const currentIndex =
    lessonsList?.findIndex((l) => l.id === currentLessonId) ?? -1;
  const prevLesson = currentIndex > 0 ? lessonsList?.[currentIndex - 1] : null;
  const nextLesson =
    currentIndex < (lessonsList?.length ?? 0) - 1
      ? lessonsList?.[currentIndex + 1]
      : null;

  const canAccess =
    hasAccess || currentLesson?.isFree;

  useEffect(() => {
    if (courseSlug && lessonsList && lessonsList.length > 0 && !lessonId) {
      navigate(`/learn/${courseSlug}/${lessonsList[0].id}`, { replace: true });
    }
  }, [courseSlug, lessonsList, lessonId, navigate]);

  if (!course || !lessonsList) {
    return (
      <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center">
        <div className="animate-pulse text-slate-400">Загрузка...</div>
      </div>
    );
  }

  const progressPercent = progressData?.completionRate || 0;

  return (
    <div className="min-h-screen bg-[#0A0A0F] flex">
      {/* Sidebar */}
      <aside className="w-80 shrink-0 border-r border-white/[0.06] bg-[#0D0D14] overflow-y-auto h-screen sticky top-0 hidden lg:block">
        <div className="p-4">
          <Link
            to={`/courses/${course.slug}`}
            className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-white mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            Назад к курсу
          </Link>

          <h3 className="text-sm font-semibold text-white mb-1 line-clamp-2">
            {course.title}
          </h3>

          {/* Progress */}
          <div className="mb-4">
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-slate-400">
                {progressData?.completedLessons || 0} /{" "}
                {progressData?.totalLessons || lessonsList.length} уроков
              </span>
              <span className="text-[#8B5CF6]">{progressPercent}%</span>
            </div>
            <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full gradient-bg transition-all duration-700"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Lessons list */}
          <div className="space-y-1">
            {lessonsList.map((lesson) => {
              const isActive = lesson.id === currentLessonId;
              const isCompleted = completedLessonIds.has(lesson.id);
              const lessonAccessible = hasAccess || lesson.isFree;

              return (
                <button
                  key={lesson.id}
                  onClick={() => {
                    if (lessonAccessible) {
                      navigate(`/learn/${courseSlug}/${lesson.id}`);
                    }
                  }}
                  disabled={!lessonAccessible}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all ${
                    isActive
                      ? "bg-[#8B5CF6]/15 border-l-2 border-[#8B5CF6]"
                      : "hover:bg-white/5 border-l-2 border-transparent"
                  } ${!lessonAccessible ? "opacity-50 cursor-not-allowed" : ""}`}
                >
                  <div className="shrink-0">
                    {isCompleted ? (
                      <CheckCircle className="w-5 h-5 text-emerald-400" />
                    ) : isActive ? (
                      <Play className="w-5 h-5 text-[#8B5CF6]" />
                    ) : lessonAccessible ? (
                      <Circle className="w-5 h-5 text-slate-600" />
                    ) : (
                      <Lock className="w-5 h-5 text-slate-600" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p
                      className={`text-sm truncate ${
                        isActive ? "text-white font-medium" : "text-slate-400"
                      }`}
                    >
                      {lesson.order}. {lesson.title}
                    </p>
                    <span className="text-xs text-slate-600">
                      {lesson.duration}
                    </span>
                  </div>
                  {lesson.isFree && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-500/15 text-emerald-400 shrink-0">
                      Free
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 min-h-screen">
        {/* Mobile header */}
        <div className="lg:hidden p-4 border-b border-white/[0.06] bg-[#0D0D14]">
          <Link
            to={`/courses/${course.slug}`}
            className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4" />
            {course.title}
          </Link>
        </div>

        {currentLesson ? (
          <div className="p-4 md:p-8 max-w-4xl">
            {/* Video Player */}
            <VideoPlayer
              lesson={currentLesson}
              courseImage={course.image || ""}
              canAccess={!!canAccess}
              courseSlug={course.slug}
            />

            {/* Lesson info */}
            <div className="mb-8">
              <div className="flex items-center gap-3 mb-3">
                <span className="px-2.5 py-1 rounded-lg bg-[#8B5CF6]/15 text-[#8B5CF6] text-xs font-medium">
                  Урок {currentLesson.order}
                </span>
                <span className="text-xs text-slate-500">
                  {currentLesson.duration}
                </span>
              </div>
              <h1 className="text-2xl font-bold text-white mb-4">
                {currentLesson.title}
              </h1>
              <MarkdownRenderer content={currentLesson.content || ""} />
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-6 border-t border-white/[0.06]">
              {canAccess && (
                <button
                  onClick={() => {
                    if (!completedLessonIds.has(currentLesson.id)) {
                      markComplete.mutate({ lessonId: currentLesson.id });
                    }
                  }}
                  disabled={
                    completedLessonIds.has(currentLesson.id) ||
                    markComplete.isPending
                  }
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    completedLessonIds.has(currentLesson.id)
                      ? "bg-emerald-500/15 text-emerald-400"
                      : "gradient-bg text-white hover:opacity-90"
                  }`}
                >
                  <CheckCircle className="w-4 h-4" />
                  {completedLessonIds.has(currentLesson.id)
                    ? "Урок пройден"
                    : "Отметить как пройденный"}
                </button>
              )}

              <div className="flex items-center gap-3">
                {prevLesson && (
                  <button
                    onClick={() =>
                      navigate(`/learn/${courseSlug}/${prevLesson.id}`)
                    }
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#12121A] border border-white/[0.06] text-sm text-slate-400 hover:text-white transition-colors"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    Предыдущий
                  </button>
                )}
                {nextLesson && (
                  <button
                    onClick={() =>
                      navigate(`/learn/${courseSlug}/${nextLesson.id}`)
                    }
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#12121A] border border-white/[0.06] text-sm text-slate-400 hover:text-white transition-colors"
                  >
                    Следующий
                    <ChevronRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Mobile lesson navigation */}
            <div className="lg:hidden mt-8">
              <h4 className="text-sm font-medium text-white mb-3">
                Уроки курса
              </h4>
              <div className="space-y-1 max-h-64 overflow-y-auto">
                {lessonsList.map((lesson) => {
                  const isActive = lesson.id === currentLessonId;
                  const isCompleted = completedLessonIds.has(lesson.id);
                  return (
                    <button
                      key={lesson.id}
                      onClick={() => {
                        if (hasAccess || lesson.isFree) {
                          navigate(`/learn/${courseSlug}/${lesson.id}`);
                        }
                      }}
                      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left ${
                        isActive ? "bg-[#8B5CF6]/15" : "hover:bg-white/5"
                      }`}
                    >
                      {isCompleted ? (
                        <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                      ) : (
                        <BookOpen className="w-4 h-4 text-slate-600 shrink-0" />
                      )}
                      <span
                        className={`text-sm truncate ${
                          isActive ? "text-white" : "text-slate-400"
                        }`}
                      >
                        {lesson.order}. {lesson.title}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center h-64">
            <p className="text-slate-400">Урок не найден</p>
          </div>
        )}
      </main>
    </div>
  );
}
