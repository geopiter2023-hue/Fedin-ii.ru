import { useState } from "react";
import { useParams, Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/Navbar";
import {
  Award,
  CheckCircle2,
  Download,
  Share2,
  ArrowLeft,
  Loader2,
} from "lucide-react";

export default function CertificatePage() {
  const { courseId } = useParams<{ courseId: string }>();
  const { isAuthenticated } = useAuth();
  const [justIssued, setJustIssued] = useState(false);

  const { data: eligibility, isLoading: eligLoading } =
    trpc.certificate.checkEligibility.useQuery(
      { courseId: parseInt(courseId || "0") },
      { enabled: !!courseId && isAuthenticated }
    );

  const { data: userCerts } = trpc.certificate.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const utils = trpc.useUtils();
  const issueCert = trpc.certificate.issue.useMutation({
    onSuccess: () => {
      utils.certificate.list.invalidate();
      utils.certificate.checkEligibility.invalidate();
      setJustIssued(true);
    },
  });

  // Find existing certificate for this course
  const existingCert = userCerts?.find(
    (c) => c.courseSlug === courseId // simplified check
  );

  if (eligLoading) {
    return (
      <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-[#8B5CF6] animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0F]">
      <Navbar />
      <div className="pt-24 pb-16 px-4">
        <div className="max-w-4xl mx-auto">
          <Link
            to="/dashboard"
            className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-white mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Назад в кабинет
          </Link>

          {/* Certificate Card */}
          <div className="relative p-8 md:p-12 rounded-3xl bg-gradient-to-br from-[#12121A] via-[#1A1A2E] to-[#12121A] border border-[#8B5CF6]/20 overflow-hidden">
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-[#8B5CF6]/5 rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-[#EC4899]/5 rounded-full blur-3xl" />

            <div className="relative text-center">
              {/* Badge */}
              <div className="w-20 h-20 rounded-full gradient-bg flex items-center justify-center mx-auto mb-6 shadow-lg shadow-purple-500/30">
                <Award className="w-10 h-10 text-white" />
              </div>

              <h1 className="text-3xl md:text-4xl font-black text-white mb-2">
                Сертификат
              </h1>
              <p className="text-slate-400 mb-8">
                НейроУниверситет подтверждает прохождение курса
              </p>

              {/* Certificate Body */}
              <div className="p-6 md:p-8 rounded-2xl bg-white/[0.03] border border-white/[0.06] mb-8">
                <p className="text-sm text-slate-500 mb-4 uppercase tracking-widest">
                  Удостоверение №
                </p>
                <p className="text-lg font-mono text-[#8B5CF6] mb-6">
                  {existingCert?.certificateNumber ||
                    issueCert.data?.certificateNumber ||
                    "—"}
                </p>

                <div className="w-16 h-px bg-gradient-to-r from-transparent via-[#8B5CF6] to-transparent mx-auto mb-6" />

                {eligibility?.eligible ? (
                  <>
                    <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-4" />
                    <p className="text-emerald-400 font-medium mb-2">
                      Курс пройден!
                    </p>
                    <p className="text-slate-400 text-sm">
                      Пройдено {eligibility.completedCount} из{" "}
                      {eligibility.totalLessons} уроков (
                      {eligibility.percent}%)
                    </p>
                  </>
                ) : (
                  <>
                    <p className="text-amber-400 font-medium mb-2">
                      {eligibility?.reason}
                    </p>
                    {eligibility && "percent" in eligibility && (
                      <div className="mt-4">
                        <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden max-w-xs mx-auto">
                          <div
                            className="h-full gradient-bg rounded-full"
                            style={{ width: `${eligibility.percent}%` }}
                          />
                        </div>
                        <p className="text-xs text-slate-500 mt-2">
                          {eligibility.completedCount} / {eligibility.totalLessons} уроков
                        </p>
                      </div>
                    )}
                  </>
                )}
              </div>

              {/* Actions */}
              {eligibility?.eligible && !existingCert && !justIssued && (
                <button
                  onClick={() =>
                    issueCert.mutate({ courseId: parseInt(courseId || "0") })
                  }
                  disabled={issueCert.isPending}
                  className="px-8 py-3 rounded-xl gradient-bg text-white font-semibold hover:opacity-90 transition-opacity disabled:opacity-50 mb-4"
                >
                  {issueCert.isPending
                    ? "Выдача..."
                    : "Получить сертификат"}
                </button>
              )}

              {(existingCert || justIssued) && (
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <button className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-white/5 border border-white/10 text-white hover:bg-white/10 transition-colors">
                    <Download className="w-4 h-4" />
                    Скачать PDF
                  </button>
                  <button className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-white/5 border border-white/10 text-white hover:bg-white/10 transition-colors">
                    <Share2 className="w-4 h-4" />
                    Поделиться
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
