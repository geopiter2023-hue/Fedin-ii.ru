import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Star, MessageSquare, Send, User } from "lucide-react";
import { Link } from "react-router";

function StarRating({ rating, onRate }: { rating: number; onRate?: (r: number) => void }) {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          onClick={() => onRate?.(star)}
          className={`transition-colors ${onRate ? "cursor-pointer hover:scale-110" : "cursor-default"}`}
        >
          <Star
            size={20}
            className={star <= rating ? "fill-yellow-400 text-yellow-400" : "text-gray-400"}
          />
        </button>
      ))}
    </div>
  );
}

export default function ReviewsPage() {
  const { isAuthenticated } = useAuth();
  const [selectedCourse, setSelectedCourse] = useState<number>(0);
  const [rating, setRating] = useState(5);
  const [text, setText] = useState("");

  const { data: courses } = trpc.course.list.useQuery();
  const { data: reviews, isLoading } = trpc.review.listByCourse.useQuery(
    { courseId: selectedCourse || (courses?.[0]?.id ?? 0) },
    { enabled: !!selectedCourse || !!courses?.length }
  );
  const { data: stats } = trpc.review.stats.useQuery(
    { courseId: selectedCourse || (courses?.[0]?.id ?? 0) },
    { enabled: !!selectedCourse || !!courses?.length }
  );

  const utils = trpc.useUtils();
  const createReview = trpc.review.create.useMutation({
    onSuccess: () => {
      setText("");
      setRating(5);
      utils.review.listByCourse.invalidate();
      utils.review.stats.invalidate();
    },
  });

  const activeCourseId = selectedCourse || courses?.[0]?.id || 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white">
      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">
            Отзывы студентов
          </h1>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            Узнайте, что говорят наши студенты о курсах. Поделитесь своим опытом обучения
          </p>
        </div>

        {/* Course selector */}
        {courses && courses.length > 0 && (
          <div className="mb-8">
            <label className="block text-sm font-medium text-slate-400 mb-3">Выберите курс</label>
            <div className="flex flex-wrap gap-2">
              {courses.map((course) => (
                <button
                  key={course.id}
                  onClick={() => setSelectedCourse(course.id)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    activeCourseId === course.id
                      ? "bg-gradient-to-r from-cyan-500 to-purple-500 text-white"
                      : "bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white"
                  }`}
                >
                  {course.title}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Stats */}
        {stats && (
          <Card className="bg-slate-900/60 border-slate-700/50 mb-8">
            <CardContent className="p-6 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="text-4xl font-bold text-yellow-400">{stats.avgRating}</div>
                <div>
                  <StarRating rating={Math.round(parseFloat(stats.avgRating))} />
                  <p className="text-slate-400 text-sm mt-1">{stats.count} отзывов</p>
                </div>
              </div>
              <MessageSquare className="text-slate-600" size={40} />
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Reviews list */}
          <div className="lg:col-span-2 space-y-4">
            {isLoading ? (
              <div className="text-center py-12 text-slate-400">Загрузка отзывов...</div>
            ) : reviews && reviews.length > 0 ? (
              reviews.map((review) => (
                <Card key={review.id} className="bg-slate-900/60 border-slate-700/50">
                  <CardContent className="p-5">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-purple-500 flex items-center justify-center flex-shrink-0">
                        {review.userAvatar ? (
                          <img src={review.userAvatar} alt="" className="w-10 h-10 rounded-full" />
                        ) : (
                          <User size={18} />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-white">
                            {review.userName || "Аноним"}
                          </span>
                          <StarRating rating={review.rating} />
                        </div>
                        <p className="text-slate-300 text-sm leading-relaxed">{review.text}</p>
                        <p className="text-slate-500 text-xs mt-2">
                          {review.createdAt
                            ? new Date(review.createdAt).toLocaleDateString("ru-RU")
                            : ""}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center py-12 text-slate-400">
                <MessageSquare size={48} className="mx-auto mb-4 opacity-50" />
                <p>Пока нет отзывов. Будьте первым!</p>
              </div>
            )}
          </div>

          {/* Add review form */}
          <div>
            <Card className="bg-slate-900/60 border-slate-700/50 sticky top-4">
              <CardHeader>
                <CardTitle className="text-lg text-white">Оставить отзыв</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {isAuthenticated ? (
                  <>
                    <div>
                      <label className="block text-sm text-slate-400 mb-2">Ваша оценка</label>
                      <StarRating rating={rating} onRate={setRating} />
                    </div>
                    <div>
                      <label className="block text-sm text-slate-400 mb-2">Ваш отзыв</label>
                      <Textarea
                        value={text}
                        onChange={(e) => setText(e.target.value)}
                        placeholder="Расскажите о вашем опыте обучения... (минимум 10 символов)"
                        className="bg-slate-800 border-slate-600 text-white min-h-[120px]"
                      />
                    </div>
                    <Button
                      onClick={() => {
                        if (text.length >= 10) {
                          createReview.mutate({
                            courseId: activeCourseId,
                            rating,
                            text,
                          });
                        }
                      }}
                      disabled={text.length < 10 || createReview.isPending}
                      className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600"
                    >
                      <Send size={16} className="mr-2" />
                      {createReview.isPending ? "Отправка..." : "Отправить отзыв"}
                    </Button>
                    {createReview.isSuccess && (
                      <p className="text-green-400 text-sm text-center">Спасибо за ваш отзыв!</p>
                    )}
                  </>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-slate-400 mb-4">Войдите, чтобы оставить отзыв</p>
                    <Link to="/login">
                      <Button className="w-full bg-gradient-to-r from-cyan-500 to-purple-500">
                        Войти
                      </Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
