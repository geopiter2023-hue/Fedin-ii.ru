import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router'
import './index.css'
import { TRPCProvider } from "@/providers/trpc"
import App from './App.tsx'

// Register PWA service worker
try {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js')
        .then(() => console.log('[PWA] Service Worker registered'))
        .catch((err) => console.log('[PWA] SW registration failed:', err))
    })
  }
} catch {
  console.log('[PWA] Service Worker not supported')
}

// Request push notifications permission
try {
  if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission()
  }
} catch {
  console.log('[Push] Notifications not supported')
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <TRPCProvider>
        <App />
      </TRPCProvider>
    </BrowserRouter>
  </StrictMode>,
)
