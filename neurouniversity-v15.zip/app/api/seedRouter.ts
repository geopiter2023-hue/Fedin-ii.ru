import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { courses, lessons } from "@db/schema";
import { courseData, lessonTitles, generateLessonContent } from "@db/seed-data";

export const seedRouter = createRouter({
  run: publicQuery.mutation(async () => {
    const db = getDb();

    const existing = await db.select().from(courses);
    if (existing.length > 0) {
      return { message: "Already seeded", count: existing.length };
    }

    for (const course of courseData) {
      const [inserted] = await db.insert(courses).values(course).$returningId();
      const titles = lessonTitles[course.slug] || [];
      const lessonValues = titles.map((title, i) => ({
        courseId: inserted.id,
        title,
        description: `Разбираем: ${title}`,
        content: generateLessonContent(title),
        duration: `${15 + Math.floor(Math.random() * 25)}:${String(Math.floor(Math.random() * 59)).padStart(2, "0")}`,
        order: i + 1,
        isFree: i === 0,
      }));
      if (lessonValues.length > 0) {
        await db.insert(lessons).values(lessonValues);
      }
    }

    return { message: "Seeded successfully", count: courseData.length };
  }),
});
