import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { aiNews } from "@db/schema";
import { desc, eq, sql } from "drizzle-orm";

// RSS sources configuration
const RSS_SOURCES = [
  {
    name: "Habr AI",
    url: "https://habr.com/ru/rss/hub/artificial_intelligence/all/",
    category: "AI",
  },
  {
    name: "Habr ML",
    url: "https://habr.com/ru/rss/hub/machine_learning/all/",
    category: "ML",
  },
  {
    name: "OpenAI Blog",
    url: "https://openai.com/blog/rss.xml",
    category: "OpenAI",
  },
];

// Simple RSS parser
async function fetchRSSFeed(source: (typeof RSS_SOURCES)[0]) {
  try {
    const response = await fetch(source.url, {
      headers: {
        "User-Agent": "NeuroUniversity-RSS-Bot/1.0",
      },
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) return [];

    const xml = await response.text();
    const items: Array<{
      title: string;
      link: string;
      description: string;
      pubDate: string;
    }> = [];

    // Simple regex-based RSS parsing
    const itemRegex = /<item>([\s\S]*?)<\/item>/g;
    let match;

    while ((match = itemRegex.exec(xml)) !== null) {
      const itemContent = match[1];

      const titleMatch = itemContent.match(/<title>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/title>/);
      const linkMatch = itemContent.match(/<link>(.*?)<\/link>/);
      const descMatch = itemContent.match(
        /<description>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/description>/
      );
      const dateMatch = itemContent.match(/<pubDate>(.*?)<\/pubDate>/);

      if (titleMatch && linkMatch) {
        items.push({
          title: titleMatch[1].trim().replace(/<[^>]*>/g, ""),
          link: linkMatch[1].trim(),
          description: (descMatch?.[1] || "")
            .trim()
            .replace(/<[^>]*>/g, "")
            .slice(0, 500),
          pubDate: dateMatch?.[1] || new Date().toISOString(),
        });
      }
    }

    return items.slice(0, 10); // Max 10 items per source
  } catch {
    return [];
  }
}

export const rssRouter = createRouter({
  // Fetch and store news from RSS
  sync: publicQuery.query(async () => {
    const db = getDb();
    const results = [];

    for (const source of RSS_SOURCES) {
      const items = await fetchRSSFeed(source);

      for (const item of items) {
        try {
          // Skip if already exists
          const [existing] = await db
            .select({ id: aiNews.id })
            .from(aiNews)
            .where(sql`BINARY ${aiNews.sourceUrl} = ${item.link}`)
            .limit(1);

          if (!existing) {
            await db.insert(aiNews).values({
              title: item.title,
              summary: item.description,
              source: source.name,
              sourceUrl: item.link,
              publishedAt: new Date(item.pubDate),
              category: source.category,
            });
            results.push({ title: item.title, source: source.name });
          }
        } catch {
          // Skip duplicates or errors
        }
      }
    }

    return { synced: results.length, items: results };
  }),

  // Get latest news
  latest: publicQuery
    .input(z.object({ limit: z.number().default(20) }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(aiNews)
        .orderBy(desc(aiNews.publishedAt))
        .limit(input?.limit || 20);
    }),

  // Get by category
  byCategory: publicQuery
    .input(z.object({ category: z.string(), limit: z.number().default(10) }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(aiNews)
        .where(eq(aiNews.category, input.category))
        .orderBy(desc(aiNews.publishedAt))
        .limit(input.limit);
    }),

  // Get sources list
  sources: publicQuery.query(() => {
    return RSS_SOURCES.map((s) => ({ name: s.name, category: s.category }));
  }),
});
