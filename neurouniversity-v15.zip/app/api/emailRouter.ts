import { z } from "zod";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { emailSubscriptions } from "@db/schema";
import { eq, count } from "drizzle-orm";

export const emailRouter = createRouter({
  // Subscribe
  subscribe: publicQuery
    .input(z.object({ email: z.string().email(), name: z.string().optional() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      try {
        await db.insert(emailSubscriptions).values({
          email: input.email,
          name: input.name || null,
        });
        return { success: true };
      } catch {
        // Already subscribed
        return { success: true, message: "Already subscribed" };
      }
    }),

  // Unsubscribe
  unsubscribe: publicQuery
    .input(z.object({ email: z.string().email() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(emailSubscriptions)
        .set({ isActive: false })
        .where(eq(emailSubscriptions.email, input.email));
      return { success: true };
    }),

  // Admin: list subscribers
  list: adminQuery.query(async () => {
    const db = getDb();
    return db.select().from(emailSubscriptions).orderBy(emailSubscriptions.createdAt);
  }),

  // Admin: subscriber count
  count: adminQuery.query(async () => {
    const db = getDb();
    const [result] = await db.select({ count: count() }).from(emailSubscriptions);
    return result?.count || 0;
  }),
});
