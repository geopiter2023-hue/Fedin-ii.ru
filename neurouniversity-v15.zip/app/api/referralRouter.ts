import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { referrals } from "@db/schema";
import { eq, and, count } from "drizzle-orm";

export const referralRouter = createRouter({
  // Get referral code for current user
  myCode: authedQuery.query(async ({ ctx }) => {
    const code = Buffer.from(`ref_${ctx.user.id}_${Date.now()}`).toString("base64url").slice(0, 12);
    return { code, link: `${process.env.APP_URL || "https://neurouniversity.ru"}/?ref=${code}` };
  }),

  // Get referral stats
  stats: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const invited = await db
      .select({ count: count() })
      .from(referrals)
      .where(eq(referrals.referrerId, ctx.user.id));

    const completed = await db
      .select({ count: count() })
      .from(referrals)
      .where(
        and(
          eq(referrals.referrerId, ctx.user.id),
          eq(referrals.status, "completed")
        )
      );

    return {
      invited: invited[0]?.count || 0,
      completed: completed[0]?.count || 0,
      bonus: (completed[0]?.count || 0) * 500,
    };
  }),

  // Track referral signup
  track: authedQuery
    .input(z.object({ code: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      // Decode code to get referrer ID (simplified)
      const referrerId = parseInt(input.code.replace(/[^0-9]/g, "")) || 0;
      if (!referrerId || referrerId === ctx.user.id) return { success: false };

      await db.insert(referrals).values({
        referrerId,
        referredId: ctx.user.id,
        status: "completed",
      });

      return { success: true };
    }),
});
