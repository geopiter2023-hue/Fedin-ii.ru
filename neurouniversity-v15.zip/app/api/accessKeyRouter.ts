import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { accessKeys, unlockedCourses } from "@db/schema";
import { eq, and, sql } from "drizzle-orm";

export const accessKeyRouter = createRouter({
  // Activate a key
  activate: authedQuery
    .input(z.object({ code: z.string().min(3).max(50) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      // Find the key
      const [key] = await db
        .select()
        .from(accessKeys)
        .where(eq(accessKeys.code, input.code.toUpperCase()));

      if (!key) {
        return { success: false, error: "Ключ не найден" };
      }

      if (!key.isActive) {
        return { success: false, error: "Ключ деактивирован" };
      }

      if (key.expiresAt && new Date() > key.expiresAt) {
        return { success: false, error: "Срок действия ключа истёк" };
      }

      if (key.maxUses > 0 && key.usesCount >= key.maxUses) {
        return { success: false, error: "Ключ исчерпан" };
      }

      // Check if user already unlocked this course
      if (key.courseId) {
        const [existing] = await db
          .select()
          .from(unlockedCourses)
          .where(
            and(
              eq(unlockedCourses.userId, ctx.user.id),
              eq(unlockedCourses.courseId, key.courseId)
            )
          );

        if (existing) {
          return { success: false, error: "У вас уже есть доступ к этому курсу" };
        }

        // Unlock the course
        await db.insert(unlockedCourses).values({
          userId: ctx.user.id,
          courseId: key.courseId,
          keyId: key.id,
          expiresAt: key.type === "test" ? sql`DATE_ADD(NOW(), INTERVAL 30 DAY)` : null,
        });
      }

      // Increment uses count
      await db
        .update(accessKeys)
        .set({ usesCount: key.usesCount + 1 })
        .where(eq(accessKeys.id, key.id));

      return {
        success: true,
        message: "Курс успешно разблокирован!",
        type: key.type,
      };
    }),

  // Get user's unlocked courses
  myUnlocked: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db
      .select()
      .from(unlockedCourses)
      .where(eq(unlockedCourses.userId, ctx.user.id));
  }),

  // Check if user has access to a course (via purchase or key)
  checkAccess: authedQuery
    .input(z.object({ courseId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();

      // Check purchase
      const { purchases } = await import("@db/schema");
      const [purchase] = await db
        .select()
        .from(purchases)
        .where(
          and(
            eq(purchases.userId, ctx.user.id),
            eq(purchases.courseId, input.courseId)
          )
        );

      if (purchase) return { hasAccess: true, source: "purchase" };

      // Check unlocked via key
      const [unlocked] = await db
        .select()
        .from(unlockedCourses)
        .where(
          and(
            eq(unlockedCourses.userId, ctx.user.id),
            eq(unlockedCourses.courseId, input.courseId)
          )
        );

      if (unlocked) {
        // Check if not expired
        if (unlocked.expiresAt && new Date() > unlocked.expiresAt) {
          return { hasAccess: false, source: null, error: "Срок доступа истёк" };
        }
        return { hasAccess: true, source: "key" };
      }

      return { hasAccess: false, source: null };
    }),

  // Admin: create keys
  create: authedQuery
    .input(
      z.object({
        code: z.string().min(3).max(50),
        type: z.enum(["test", "promo", "lifetime"]),
        courseId: z.number().optional(),
        maxUses: z.number().min(1).default(1),
        expiresAt: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Only admin check
      if (ctx.user.role !== "admin") {
        return { success: false, error: "Только администратор" };
      }

      const db = getDb();
      await db.insert(accessKeys).values({
        code: input.code.toUpperCase(),
        type: input.type,
        courseId: input.courseId || null,
        maxUses: input.maxUses,
        expiresAt: input.expiresAt ? new Date(input.expiresAt) : null,
      });

      return { success: true };
    }),

  // Admin: list all keys
  list: authedQuery.query(async ({ ctx }) => {
    if (ctx.user.role !== "admin") return [];
    const db = getDb();
    return db.select().from(accessKeys).orderBy(accessKeys.createdAt);
  }),
});
