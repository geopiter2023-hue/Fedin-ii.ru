import { z } from "zod";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { lessons, progress } from "@db/schema";
import { eq, and } from "drizzle-orm";

export const lessonRouter = createRouter({
  getByCourse: publicQuery
    .input(z.object({ courseId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(lessons)
        .where(eq(lessons.courseId, input.courseId))
        .orderBy(lessons.order);
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [lesson] = await db
        .select()
        .from(lessons)
        .where(eq(lessons.id, input.id));
      return lesson || null;
    }),

  markComplete: authedQuery
    .input(z.object({ lessonId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const existing = await db
        .select()
        .from(progress)
        .where(
          and(
            eq(progress.userId, ctx.user.id),
            eq(progress.lessonId, input.lessonId)
          )
        );

      if (existing.length > 0) {
        await db
          .update(progress)
          .set({ completed: true, completedAt: new Date() })
          .where(eq(progress.id, existing[0].id));
        return existing[0];
      }

      const [newProgress] = await db
        .insert(progress)
        .values({
          userId: ctx.user.id,
          lessonId: input.lessonId,
          completed: true,
          completedAt: new Date(),
        })
        .$returningId();

      return db.query.progress.findFirst({
        where: eq(progress.id, newProgress.id),
      });
    }),

  getProgress: authedQuery
    .input(z.object({ courseId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const courseLessons = await db
        .select()
        .from(lessons)
        .where(eq(lessons.courseId, input.courseId))
        .orderBy(lessons.order);

      const userProgress = await db
        .select()
        .from(progress)
        .where(
          and(
            eq(progress.userId, ctx.user.id),
            eq(progress.completed, true)
          )
        );

      const completedLessonIds = new Set(
        userProgress.map((p) => p.lessonId)
      );

      const completedCount = courseLessons.filter((l) =>
        completedLessonIds.has(l.id)
      ).length;

      return {
        totalLessons: courseLessons.length,
        completedLessons: completedCount,
        completionRate:
          courseLessons.length > 0
            ? Math.round((completedCount / courseLessons.length) * 100)
            : 0,
        lessons: courseLessons.map((l) => ({
          ...l,
          isCompleted: completedLessonIds.has(l.id),
        })),
      };
    }),
});
