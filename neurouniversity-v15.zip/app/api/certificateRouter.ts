import { z } from "zod";
import { createRouter, authedQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { certificates, courses, users, lessons, progress, purchases } from "@db/schema";
import { eq, and, count, desc } from "drizzle-orm";

export const certificateRouter = createRouter({
  // Get user's certificates
  list: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db
      .select({
        id: certificates.id,
        certificateNumber: certificates.certificateNumber,
        issuedAt: certificates.issuedAt,
        courseTitle: courses.title,
        courseSlug: courses.slug,
      })
      .from(certificates)
      .innerJoin(courses, eq(certificates.courseId, courses.id))
      .where(eq(certificates.userId, ctx.user.id))
      .orderBy(desc(certificates.issuedAt));
  }),

  // Check if user can get certificate for a course
  checkEligibility: authedQuery
    .input(z.object({ courseId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();

      // Check purchase
      const [purchase] = await db
        .select()
        .from(purchases)
        .where(
          and(
            eq(purchases.userId, ctx.user.id),
            eq(purchases.courseId, input.courseId),
            eq(purchases.status, "completed")
          )
        );
      if (!purchase) return { eligible: false, reason: "Курс не куплен" };

      // Check existing certificate
      const [existing] = await db
        .select()
        .from(certificates)
        .where(
          and(
            eq(certificates.userId, ctx.user.id),
            eq(certificates.courseId, input.courseId)
          )
        );
      if (existing) return { eligible: false, reason: "Сертификат уже выдан", certificateNumber: existing.certificateNumber };

      // Get course lessons
      const courseLessons = await db
        .select()
        .from(lessons)
        .where(eq(lessons.courseId, input.courseId));

      const totalLessons = courseLessons.length;
      if (totalLessons === 0) return { eligible: false, reason: "В курсе нет уроков" };

      // Get completed lessons
      const completed = await db
        .select()
        .from(progress)
        .where(
          and(
            eq(progress.userId, ctx.user.id),
            eq(progress.completed, true)
          )
        );

      const completedLessonIds = new Set(completed.map((p) => p.lessonId));
      const completedCount = courseLessons.filter((l) =>
        completedLessonIds.has(l.id)
      ).length;

      const percent = Math.round((completedCount / totalLessons) * 100);

      if (percent >= 80) {
        return { eligible: true, percent, completedCount, totalLessons };
      }

      return {
        eligible: false,
        reason: `Пройдено ${percent}% уроков. Нужно минимум 80%`,
        percent,
        completedCount,
        totalLessons,
      };
    }),

  // Issue certificate
  issue: authedQuery
    .input(z.object({ courseId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      // Verify eligibility
      const [purchase] = await db
        .select()
        .from(purchases)
        .where(
          and(
            eq(purchases.userId, ctx.user.id),
            eq(purchases.courseId, input.courseId),
            eq(purchases.status, "completed")
          )
        );
      if (!purchase) throw new Error("Курс не куплен");

      const [existing] = await db
        .select()
        .from(certificates)
        .where(
          and(
            eq(certificates.userId, ctx.user.id),
            eq(certificates.courseId, input.courseId)
          )
        );
      if (existing) return existing;

      // Generate unique certificate number
      const certNumber = `NU-${Date.now()}-${ctx.user.id}-${input.courseId}`;

      const [newCert] = await db
        .insert(certificates)
        .values({
          userId: ctx.user.id,
          courseId: input.courseId,
          certificateNumber: certNumber,
        })
        .$returningId();

      return db.query.certificates.findFirst({
        where: eq(certificates.id, newCert.id),
      });
    }),

  // Get certificate by number (public)
  getByNumber: authedQuery
    .input(z.object({ number: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [cert] = await db
        .select({
          id: certificates.id,
          certificateNumber: certificates.certificateNumber,
          issuedAt: certificates.issuedAt,
          userName: users.name,
          courseTitle: courses.title,
          courseSlug: courses.slug,
        })
        .from(certificates)
        .innerJoin(users, eq(certificates.userId, users.id))
        .innerJoin(courses, eq(certificates.courseId, courses.id))
        .where(eq(certificates.certificateNumber, input.number));
      return cert || null;
    }),

  // Admin: all certificates
  adminList: adminQuery.query(async () => {
    const db = getDb();
    return db
      .select({
        id: certificates.id,
        certificateNumber: certificates.certificateNumber,
        issuedAt: certificates.issuedAt,
        userName: users.name,
        userEmail: users.email,
        courseTitle: courses.title,
      })
      .from(certificates)
      .innerJoin(users, eq(certificates.userId, users.id))
      .innerJoin(courses, eq(certificates.courseId, courses.id))
      .orderBy(desc(certificates.issuedAt));
  }),

  // Admin: stats
  adminStats: adminQuery.query(async () => {
    const db = getDb();
    const [totalCerts] = await db.select({ count: count() }).from(certificates);
    const [totalUsers] = await db.select({ count: count() }).from(users);
    const [totalPurchases] = await db.select({ count: count() }).from(purchases);
    return {
      totalCertificates: totalCerts.count,
      totalUsers: totalUsers.count,
      totalPurchases: totalPurchases.count,
    };
  }),
});
