import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { purchases, courses, lessons, progress } from "@db/schema";
import { eq, and, inArray } from "drizzle-orm";

export const userRouter = createRouter({
  getStats: authedQuery.query(async ({ ctx }) => {
    const db = getDb();

    const userPurchases = await db
      .select()
      .from(purchases)
      .where(
        and(
          eq(purchases.userId, ctx.user.id),
          eq(purchases.status, "completed")
        )
      );

    const courseIds = userPurchases.map((p) => p.courseId);

    let totalLessons = 0;
    let completedLessons = 0;

    if (courseIds.length > 0) {
      const userProgress = await db
        .select()
        .from(progress)
        .where(
          and(
            eq(progress.userId, ctx.user.id),
            eq(progress.completed, true)
          )
        );

      completedLessons = userProgress.length;

      const allLessons = await db
        .select()
        .from(lessons)
        .where(inArray(lessons.courseId, courseIds));

      totalLessons = allLessons.length;
    }

    return {
      coursesPurchased: userPurchases.length,
      lessonsCompleted: completedLessons,
      totalLessons,
      hoursLearned: Math.round(completedLessons * 0.4),
      certificates: completedLessons > 0 ? userPurchases.length : 0,
    };
  }),

  getDashboard: authedQuery.query(async ({ ctx }) => {
    const db = getDb();

    const userPurchases = await db
      .select({
        id: purchases.id,
        courseId: purchases.courseId,
        createdAt: purchases.createdAt,
      })
      .from(purchases)
      .where(
        and(
          eq(purchases.userId, ctx.user.id),
          eq(purchases.status, "completed")
        )
      );

    if (userPurchases.length === 0) {
      return { activeCourses: [] };
    }

    const courseIds = userPurchases.map((p) => p.courseId);

    const purchasedCourses = await db
      .select()
      .from(courses)
      .where(inArray(courses.id, courseIds));

    const userProgress = await db
      .select()
      .from(progress)
      .where(
        and(
          eq(progress.userId, ctx.user.id),
          eq(progress.completed, true)
        )
      );

    const completedLessonIds = new Set(userProgress.map((p) => p.lessonId));

    const activeCourses = await Promise.all(
      purchasedCourses.map(async (course) => {
        const courseLessons = await db
          .select()
          .from(lessons)
          .where(eq(lessons.courseId, course.id));

        const completedCount = courseLessons.filter((l) =>
          completedLessonIds.has(l.id)
        ).length;

        return {
          ...course,
          completedLessons: completedCount,
          totalLessons: courseLessons.length,
          progressPercent:
            courseLessons.length > 0
              ? Math.round((completedCount / courseLessons.length) * 100)
              : 0,
        };
      })
    );

    return { activeCourses };
  }),
});
