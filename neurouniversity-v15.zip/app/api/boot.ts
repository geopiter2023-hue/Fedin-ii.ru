import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";
import { createOAuthCallbackHandler } from "./kimi/auth";
import { Paths } from "@contracts/constants";
import { getDb } from "./queries/connection";
import { courses, lessons, accessKeys } from "@db/schema";
import { courseData, lessonTitles, generateLessonContent } from "@db/seed-data";

// Seed test access keys
async function seedTestKeys() {
  try {
    const db = getDb();
    const existing = await db.select().from(accessKeys);
    if (existing.length > 0) {
      console.log(`[seed-keys] Already have ${existing.length} keys, skipping.`);
      return;
    }

    // Create universal test key (unlocks ALL courses)
    const testKeys = [
      { code: "NEUROTEST2025", type: "test" as const, courseId: null, maxUses: 100 },
      { code: "ADMIN999", type: "lifetime" as const, courseId: null, maxUses: 999 },
      { code: "PROMO50", type: "promo" as const, courseId: null, maxUses: 50 },
      { code: "STUDENT2025", type: "test" as const, courseId: null, maxUses: 500 },
      { code: "BETA2025", type: "test" as const, courseId: null, maxUses: 200 },
    ];

    for (const key of testKeys) {
      await db.insert(accessKeys).values(key);
    }

    console.log(`[seed-keys] Created ${testKeys.length} test keys: NEUROTEST2025, ADMIN999, PROMO50, STUDENT2025, BETA2025`);
  } catch (err) {
    console.error("[seed-keys] Error:", err);
  }
}

// Auto-seed function
async function autoSeed() {
  try {
    const db = getDb();
    const existing = await db.select().from(courses);
    if (existing.length > 0) {
      console.log(`[seed] Database already has ${existing.length} courses, skipping seed.`);
      // Still seed test keys even if courses exist
      await seedTestKeys();
      return;
    }

    console.log("[seed] Seeding 22 courses and lessons...");
    for (const course of courseData) {
      const [inserted] = await db.insert(courses).values(course).$returningId();
      const titles = lessonTitles[course.slug] || [];
      const lessonValues = titles.map((title, i) => ({
        courseId: inserted.id,
        title,
        description: `Разбираем: ${title}`,
        content: generateLessonContent(title),
        duration: `${15 + Math.floor(Math.random() * 25)}:${String(Math.floor(Math.random() * 59)).padStart(2, "0")}`,
        order: i + 1,
        isFree: i === 0,
      }));
      if (lessonValues.length > 0) {
        await db.insert(lessons).values(lessonValues);
      }
      console.log(`[seed]  ${course.title} (${titles.length} lessons)`);
    }
    console.log(`[seed] Done! Created ${courseData.length} courses with lessons.`);

    // Seed test keys after courses
    await seedTestKeys();
  } catch (err) {
    console.error("[seed] Error:", err);
  }
}

const app = new Hono<{ Bindings: HttpBindings }>();

app.use(bodyLimit({ maxSize: 50 * 1024 * 1024 }));
app.get(Paths.oauthCallback, createOAuthCallbackHandler());
app.use("/api/trpc/*", async (c) => {
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext,
  });
});
app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

export default app;

if (env.isProduction) {
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);

  // Run seed before starting server
  await autoSeed();

  const port = parseInt(process.env.PORT || "3000");
  serve({ fetch: app.fetch, port }, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}
