import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { env } from "./lib/env";

const SYSTEM_PROMPT = `Ты — Нейра, дружелюбный AI-консультант образовательной платформы "НейроУниверситет". Ты помогаешь пользователям выбирать курсы по нейросетям и отвечаешь на вопросы об искусственном интеллекте.

## О платформе
НейроУниверситет — это образовательная платформа с 20 курсами по нейросетям для обычных людей. Никакого кода, только практические навыки.

## Все курсы:

### Категория "База" (для начинающих):
1. "Нейросети с нуля" — 12 уроков, 2990₽. Что такое нейросеть, ChatGPT, Midjourney, как учатся, где применяются.
2. "ChatGPT: от новичка до эксперта" — 10 уроков, 1990₽. Промпты, 50+ шаблонов, автоматизация, контент-планы.
3. "Midjourney для творческих профессий" — 8 уроков, 2490₽. Параметры, стили, персонажи, логотипы.

### Категория "Для работы":
4. "AI для маркетологов" — 10 уроков, 3490₽. Рекламные тексты, анализ конкурентов, email, SMM.
5. "Нейросети для дизайнеров" — 12 уроков, 2990₽. Мокапы, иллюстрации, AI-плагины Figma, UI-киты.
6. "Автоматизация бизнеса с AI" — 8 уроков, 3990₽. Клиентская поддержка, документы, прогнозирование.

### Категория "Продвинутый":
7. "Prompt Engineering мастерство" — 14 уроков, 4990₽. Структуры промптов, Chain-of-Thought, Few-shot.
8. "Создание AI-агентов" — 10 уроков, 5990₽. No-code платформы, автономные агенты, интеграция.
9. "Нейросети для анализа данных" — 12 уроков, 4490₽. Excel, визуализация, прогнозы, отчёты.

### Категория "Специальные навыки":
10. "Генерация видео нейросетями" — 8 уроков, 3490₽. Sora, Runway, анимация, рекламные ролики.
11. "AI для копирайтинга" — 10 уроков, 2490₽. Продающие тексты, статьи, email, посты.
12. "Защита данных в эпоху AI" — 6 уроков, 1990₽. Безопасность, приватность, локальные модели.

### Категория "Новинки 2025" (самые актуальные):
13. "Программирование с Cursor и AI" — 14 уроков, 4990₽. Cursor IDE, GitHub Copilot, создание сайтов и ботов без кода.
14. "Создание музыки с Suno и Udio" — 8 уроков, 3490₽. Генерация треков любого жанра, звуковые эффекты, озвучка.
15. "AI-обработка фотографий" — 10 уроков, 2990₽. Photoshop AI, Generative Fill, удаление объектов, замена фона.
16. "AI для YouTube и блогеров" — 12 уроков, 3490₽. Сценарии, превью, субтитры, озвучка, SEO.
17. "AI для E-commerce и продаж" — 10 уроков, 3990₽. Описания товаров, фото, чат-боты, Wildberries/Ozon.
18. "AI презентации и документы" — 8 уроков, 2490₽. Gamma, Beautiful.ai, отчёты, питчи за минуты.
19. "Telegram-боты с AI без кода" — 10 уроков, 3490₽. Боты с ChatGPT, сбор заявок, CRM-интеграция.
20. "AI-дубляж и перевод видео" — 8 уроков, 4490₽. HeyGen, клон голоса, синхронизация губ, 50+ языков.
21. "AI для фрилансера" — 10 уроков, 2990₽. Поиск клиентов, КП, портфолио, увеличение дохода x2.
22. "3D-модели с AI: Tripo и Meshy" — 10 уроков, 3990₽. 3D из текста/фото, текстуры, геймдев-ассеты.

## Важные правила:
- Всегда отвечай на русском языке
- Будь дружелюбной, энергичной и немного игривой
- Используй эмодзи умеренно
- Если пользователь спрашивает о курсе — давай подробную информацию
- Если не знает с чего начать — задавай уточняющие вопросы
- Все цены в рублях (₽)
- Каждый курс: доступ навсегда, сертификат, поддержка
- Первый урок каждого курса бесплатный`;

export const aiRouter = createRouter({
  chat: publicQuery
    .input(
      z.object({
        message: z.string().min(1).max(4000),
        history: z
          .array(
            z.object({
              role: z.enum(["user", "assistant"]),
              content: z.string(),
            })
          )
          .optional()
          .default([]),
      })
    )
    .mutation(async ({ input }) => {
      const apiKey = env.openrouterApiKey;

      try {
        if (!apiKey) {
          console.warn("[ai] OPENROUTER_API_KEY not set, using fallback");
          return {
            response: generateFallbackResponse(input.message),
            source: "local",
          };
        }

        const messages = [
          { role: "system" as const, content: SYSTEM_PROMPT },
          ...input.history.map((h) => ({
            role: h.role as "user" | "assistant",
            content: h.content,
          })),
          { role: "user" as const, content: input.message },
        ];

        const response = await fetch(
          "https://openrouter.ai/api/v1/chat/completions",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${apiKey}`,
              "HTTP-Referer": env.appUrl,
              "X-Title": "НейроУниверситет",
            },
            body: JSON.stringify({
              model: "deepseek/deepseek-chat-v3-0324:free",
              messages,
              max_tokens: 1500,
              temperature: 0.8,
            }),
          }
        );

        if (!response.ok) {
          const error = await response.text();
          console.error("[ai] OpenRouter HTTP error:", response.status, error);
          throw new Error(`OpenRouter API error: ${response.status}`);
        }

        const data = (await response.json()) as {
          choices?: Array<{ message?: { content?: string } }>;
          error?: { message?: string };
        };

        if (data.error) {
          console.error("[ai] OpenRouter returned error:", data.error);
          throw new Error(data.error.message || "Unknown API error");
        }

        const content = data.choices?.[0]?.message?.content;
        if (!content) {
          console.error("[ai] Empty response from OpenRouter");
          throw new Error("Empty response from AI");
        }

        console.log("[ai] Success, response length:", content.length);
        return { response: content, source: "ai" };
      } catch (error: any) {
        console.error("[ai] Chat error:", error.message || error);
        if (!apiKey) {
          return {
            response: generateFallbackResponse(input.message),
            source: "local",
          };
        }
        throw error;
      }
    }),
});

function generateFallbackResponse(query: string): string {
  const q = query.toLowerCase();

  if (q.includes("привет") || q.includes("здравствуй")) {
    return "Привет! Я Нейра — твой AI-консультант по курсам нейросетей. У нас уже 20+ курсов! Чем могу помочь?";
  }

  if (q.includes("курс") || q.includes("что есть")) {
    return "У нас 20 курсов по нейросетям:\n\n**База:** Нейросети с нуля, ChatGPT мастер, Midjourney\n\n**Для работы:** AI для маркетологов, AI для дизайнеров, Автоматизация бизнеса\n\n**Продвинутый:** Prompt Engineering, AI-агенты, Анализ данных\n\n**Специальные:** Видео, Копирайтинг, Безопасность\n\n**Новинки 2025:** Программирование с Cursor, Музыка с Suno, AI-фото, YouTube, E-commerce, Презентации, Telegram-боты, Дубляж, Фриланс, 3D-модели\n\nО каком хочешь узнать подробнее?";
  }

  if (q.includes("новый") || q.includes("новинк") || q.includes("2025")) {
    return "Наши новейшие курсы 2025:\n\n• **Программирование с Cursor** (4990₽) — пиши код как senior без знаний\n• **Музыка с Suno и Udio** (3490₽) — генерируй треки любого жанра\n• **AI-обработка фото** (2990₽) — Photoshop AI, ретушь за секунды\n• **AI для YouTube** (3490₽) — сценарии, превью, субтитры\n• **AI для E-commerce** (3990₽) — автоматизация магазинов\n• **Telegram-боты с AI** (3490₽) — боты без кода\n• **AI-дубляж видео** (4490₽) — озвучка на 50+ языках\n• **3D-модели с AI** (3990₽) — 3D из текста и фото\n\nКакой интересен?";
  }

  if (q.includes("цена") || q.includes("стоимость")) {
    return "Цены от 1990₽ до 5990₽. Скидки до 40%! Всё включено: доступ навсегда, сертификат, поддержка.\n\nСамые доступные: Защита данных (1990₽), ChatGPT (1990₽), AI-копирайтинг (2490₽), Презентации (2490₽)\n\nПремиум: AI-агенты (5990₽), Prompt Engineering (4990₽), Cursor (4990₽)";
  }

  return "Отличный вопрос! У нас 20 курсов по нейросетям — от базы до создания AI-агентов. Спроси про конкретный курс или скажи чем занимаешься — подберу идеальный!";
}
