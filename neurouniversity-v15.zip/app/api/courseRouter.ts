import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { courses, lessons } from "@db/schema";
import { eq, and, like, or } from "drizzle-orm";

export const courseRouter = createRouter({
  list: publicQuery
    .input(
      z
        .object({
          category: z.string().optional(),
          level: z.string().optional(),
          search: z.string().optional(),
        })
        .optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input?.category && input.category !== "all") {
        conditions.push(eq(courses.category, input.category));
      }

      if (input?.level && input.level !== "all") {
        conditions.push(eq(courses.level, input.level as "beginner" | "intermediate" | "advanced"));
      }

      if (input?.search) {
        conditions.push(
          or(
            like(courses.title, `%${input.search}%`),
            like(courses.description, `%${input.search}%`)
          )
        );
      }

      conditions.push(eq(courses.isPublished, true));

      if (conditions.length === 1) {
        return db.select().from(courses).where(conditions[0]);
      }
      if (conditions.length > 1) {
        return db
          .select()
          .from(courses)
          .where(and(...conditions));
      }

      return db.select().from(courses);
    }),

  getBySlug: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [course] = await db
        .select()
        .from(courses)
        .where(eq(courses.slug, input.slug));
      return course || null;
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [course] = await db
        .select()
        .from(courses)
        .where(eq(courses.id, input.id));
      return course || null;
    }),

  getLessons: publicQuery
    .input(z.object({ courseId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(lessons)
        .where(eq(lessons.courseId, input.courseId))
        .orderBy(lessons.order);
    }),
});
