import { z } from "zod";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { reviews, users } from "@db/schema";
import { eq, desc, avg } from "drizzle-orm";

export const reviewRouter = createRouter({
  // List reviews for a course
  listByCourse: publicQuery
    .input(z.object({ courseId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select({
          id: reviews.id,
          rating: reviews.rating,
          text: reviews.text,
          createdAt: reviews.createdAt,
          userName: users.name,
          userAvatar: users.avatar,
        })
        .from(reviews)
        .innerJoin(users, eq(reviews.userId, users.id))
        .where(eq(reviews.courseId, input.courseId))
        .orderBy(desc(reviews.createdAt));
    }),

  // Create review
  create: authedQuery
    .input(
      z.object({
        courseId: z.number(),
        rating: z.number().min(1).max(5),
        text: z.string().min(10).max(1000),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [newReview] = await db
        .insert(reviews)
        .values({
          userId: ctx.user.id,
          courseId: input.courseId,
          rating: input.rating,
          text: input.text,
        })
        .$returningId();

      return db.query.reviews.findFirst({
        where: eq(reviews.id, newReview.id),
      });
    }),

  // Get average rating for a course
  stats: publicQuery
    .input(z.object({ courseId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const result = await db
        .select({ avgRating: avg(reviews.rating), count: avg(reviews.id) })
        .from(reviews)
        .where(eq(reviews.courseId, input.courseId));

      return {
        avgRating: result[0]?.avgRating
          ? parseFloat(result[0].avgRating).toFixed(1)
          : "0.0",
        count: result[0]?.count ? parseInt(result[0].count) : 0,
      };
    }),
});
