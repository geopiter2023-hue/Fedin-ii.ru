import { Routes, Route } from 'react-router'
import Home from './pages/Home'
import Courses from './pages/Courses'
import CourseDetail from './pages/CourseDetail'
import Learn from './pages/Learn'
import Dashboard from './pages/Dashboard'
import Assistant from './pages/Assistant'
import Roadmap from './pages/Roadmap'
import CertificatePage from './pages/Certificate'
import ReviewsPage from './pages/Reviews'
import ReferralPage from './pages/Referral'
import Admin from './pages/Admin'
import Login from './pages/Login'
import NotFound from './pages/NotFound'
import FloatingAssistant from './components/FloatingAssistant'

export default function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/courses/:slug" element={<CourseDetail />} />
        <Route path="/learn/:courseSlug" element={<Learn />} />
        <Route path="/learn/:courseSlug/:lessonId" element={<Learn />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/assistant" element={<Assistant />} />
        <Route path="/roadmap" element={<Roadmap />} />
        <Route path="/certificate/:courseId" element={<CertificatePage />} />
        <Route path="/reviews" element={<ReviewsPage />} />
        <Route path="/referral" element={<ReferralPage />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <FloatingAssistant />
    </>
  )
}
