import { useState } from "react";
import { useParams, Link, useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/Navbar";
import MarkdownRenderer from "@/components/MarkdownRenderer";
import { Button } from "@/components/ui/button";
import {
  Clock,
  BookOpen,
  Star,
  Users,
  CheckCircle,
  Lock,
  PlayCircle,
  ChevronDown,
  ChevronUp,
  Award,
  MessageCircle,
  Infinity,
  ArrowLeft,
} from "lucide-react";

const levelLabels: Record<string, string> = {
  beginner: "Начинающий",
  intermediate: "Средний",
  advanced: "Продвинутый",
};

export default function CourseDetail() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState<"desc" | "program" | "reviews">("desc");
  const [expandedLessons, setExpandedLessons] = useState(true);

  const { data: course, isLoading: courseLoading } = trpc.course.getBySlug.useQuery(
    { slug: slug || "" },
    { enabled: !!slug }
  );

  const { data: lessonsList } = trpc.course.getLessons.useQuery(
    { courseId: course?.id || 0 },
    { enabled: !!course?.id }
  );

  const { data: hasAccess } = trpc.purchase.checkAccess.useQuery(
    { courseId: course?.id || 0 },
    { enabled: !!course?.id && isAuthenticated }
  );

  const { data: purchaseData } = trpc.purchase.getByCourse.useQuery(
    { courseId: course?.id || 0 },
    { enabled: !!course?.id && isAuthenticated }
  );

  const utils = trpc.useUtils();
  const purchaseMutation = trpc.purchase.create.useMutation({
    onSuccess: () => {
      utils.purchase.checkAccess.invalidate();
      utils.purchase.getByCourse.invalidate();
      utils.user.getDashboard.invalidate();
    },
  });

  const handlePurchase = () => {
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }
    if (course) {
      purchaseMutation.mutate({ courseId: course.id });
    }
  };

  if (courseLoading) {
    return (
      <div className="min-h-screen bg-[#0A0A0F]">
        <Navbar />
        <div className="pt-24 px-4">
          <div className="max-w-6xl mx-auto animate-pulse space-y-6">
            <div className="h-64 bg-white/5 rounded-2xl" />
            <div className="h-8 bg-white/5 rounded w-1/3" />
            <div className="h-4 bg-white/5 rounded w-2/3" />
          </div>
        </div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen bg-[#0A0A0F]">
        <Navbar />
        <div className="pt-24 px-4 text-center">
          <p className="text-slate-400 text-lg">Курс не найден</p>
          <Link to="/courses" className="text-[#8B5CF6] mt-4 inline-block">
            Вернуться к каталогу
          </Link>
        </div>
      </div>
    );
  }

  const price = parseFloat(course.price);
  const oldPrice = course.oldPrice ? parseFloat(course.oldPrice) : null;

  return (
    <div className="min-h-screen bg-[#0A0A0F]">
      <Navbar />

      {/* Course hero */}
      <div className="relative pt-16">
        <div className="relative h-64 md:h-80 overflow-hidden">
          <img
            src={course.image || ""}
            alt={course.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0F] via-[#0A0A0F]/60 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10">
            <div className="max-w-6xl mx-auto">
              <Link
                to="/courses"
                className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-white mb-4"
              >
                <ArrowLeft className="w-4 h-4" />
                Все курсы
              </Link>
              <h1 className="text-3xl md:text-5xl font-bold text-white mb-2">
                {course.title}
              </h1>
              <p className="text-lg text-slate-300 mb-4">{course.subtitle}</p>
              <div className="flex flex-wrap items-center gap-4 text-sm text-slate-400">
                <span className="flex items-center gap-1">
                  <BookOpen className="w-4 h-4" />
                  {course.lessonsCount} уроков
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {course.duration}
                </span>
                <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-[#8B5CF6]/15 text-[#8B5CF6]">
                  {levelLabels[course.level]}
                </span>
                <span className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                  {course.rating}
                </span>
                <span className="flex items-center gap-1">
                  <Users className="w-4 h-4" />
                  {course.studentsCount} студентов
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-10">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left column */}
          <div className="lg:col-span-2">
            {/* Tabs */}
            <div className="flex gap-1 mb-6 p-1 rounded-xl bg-[#12121A] border border-white/[0.06]">
              {[
                { key: "desc" as const, label: "Описание" },
                { key: "program" as const, label: "Программа" },
                { key: "reviews" as const, label: "Отзывы" },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-medium transition-all ${
                    activeTab === tab.key
                      ? "bg-[#8B5CF6] text-white"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab content */}
            {activeTab === "desc" && (
              <MarkdownRenderer content={course.longDescription || course.description || ""} />
            )}

            {activeTab === "program" && (
              <div>
                <button
                  onClick={() => setExpandedLessons(!expandedLessons)}
                  className="flex items-center gap-2 text-sm text-slate-400 hover:text-white mb-4"
                >
                  {expandedLessons ? (
                    <ChevronUp className="w-4 h-4" />
                  ) : (
                    <ChevronDown className="w-4 h-4" />
                  )}
                  {lessonsList?.length || 0} уроков
                </button>
                {expandedLessons && (
                  <div className="space-y-2">
                    {lessonsList?.map((lesson) => (
                      <div
                        key={lesson.id}
                        className="flex items-center gap-4 p-4 rounded-xl bg-[#12121A] border border-white/[0.06]"
                      >
                        <div className="shrink-0 w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-sm font-medium text-slate-400">
                          {lesson.order}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm font-medium text-white truncate">
                            {lesson.title}
                          </h4>
                          <span className="text-xs text-slate-500">
                            {lesson.duration}
                          </span>
                        </div>
                        {lesson.isFree ? (
                          <span className="px-2 py-1 rounded-full text-xs bg-emerald-500/15 text-emerald-400">
                            Бесплатно
                          </span>
                        ) : hasAccess ? (
                          <PlayCircle className="w-5 h-5 text-[#8B5CF6]" />
                        ) : (
                          <Lock className="w-5 h-5 text-slate-600" />
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === "reviews" && (
              <div className="space-y-6">
                {[
                  { name: "Алексей", text: "Отличный курс! Всё понятно и доступно.", rating: 5 },
                  { name: "Мария", text: "Наконец-то разобралась в нейросетях. Спасибо!", rating: 5 },
                  { name: "Иван", text: "Очень практичный курс, применяю знания каждый день.", rating: 4 },
                ].map((r, i) => (
                  <div
                    key={i}
                    className="p-5 rounded-xl bg-[#12121A] border border-white/[0.06]"
                  >
                    <div className="flex items-center gap-1 mb-3">
                      {Array.from({ length: r.rating }).map((_x, j) => (
                        <Star
                          key={j}
                          className="w-4 h-4 text-amber-400 fill-amber-400"
                        />
                      ))}
                    </div>
                    <p className="text-slate-300 mb-3">{r.text}</p>
                    <span className="text-sm text-slate-500">{r.name}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right column - sticky purchase card */}
          <div className="lg:col-span-1">
            <div className="lg:sticky lg:top-24">
              <div className="p-6 rounded-2xl bg-[#12121A] border border-white/[0.06]">
                {hasAccess || purchaseData ? (
                  <div>
                    <div className="flex items-center gap-2 mb-4">
                      <CheckCircle className="w-5 h-5 text-emerald-400" />
                      <span className="text-emerald-400 font-medium">
                        Курс куплен
                      </span>
                    </div>
                    <Link to={`/learn/${course.slug}`}>
                      <Button className="w-full gradient-bg text-white hover:opacity-90">
                        {lessonsList && lessonsList.length > 0
                          ? "Продолжить обучение"
                          : "Начать обучение"}
                      </Button>
                    </Link>
                  </div>
                ) : (
                  <div>
                    <div className="flex items-baseline gap-3 mb-4">
                      <span className="text-3xl font-bold gradient-text">
                        {price.toLocaleString("ru-RU")} ₽
                      </span>
                      {oldPrice && (
                        <span className="text-lg text-slate-500 line-through">
                          {oldPrice.toLocaleString("ru-RU")} ₽
                        </span>
                      )}
                    </div>
                    {oldPrice && (
                      <div className="px-3 py-1.5 rounded-lg bg-rose-500/15 text-rose-400 text-sm font-medium mb-4 inline-block">
                        Скидка {Math.round((1 - price / oldPrice) * 100)}%
                      </div>
                    )}
                    <Button
                      onClick={handlePurchase}
                      disabled={purchaseMutation.isPending}
                      className="w-full gradient-bg text-white hover:opacity-90 mb-6"
                    >
                      {purchaseMutation.isPending
                        ? "Оформление..."
                        : "Купить курс"}
                    </Button>
                  </div>
                )}

                {/* Includes */}
                <div className="space-y-3 pt-6 border-t border-white/[0.06]">
                  <h4 className="text-sm font-medium text-white mb-3">
                    Что включено:
                  </h4>
                  {[
                    { icon: Infinity, text: "Доступ навсегда" },
                    { icon: Award, text: "Сертификат о прохождении" },
                    { icon: MessageCircle, text: "Поддержка в чате" },
                    { icon: BookOpen, text: `${course.lessonsCount} уроков` },
                    { icon: Clock, text: course.duration || "" },
                  ].map((item, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-3 text-sm text-slate-400"
                    >
                      <item.icon className="w-4 h-4 text-[#8B5CF6]" />
                      {item.text}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
