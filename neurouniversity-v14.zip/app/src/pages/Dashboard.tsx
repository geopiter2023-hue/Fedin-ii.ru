import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/Navbar";
import CourseCard from "@/components/CourseCard";
import { LOGIN_PATH } from "@/const";
import {
  BookOpen,
  GraduationCap,
  Clock,
  Award,
  TrendingUp,
  Sparkles,
} from "lucide-react";

export default function Dashboard() {
  const { isAuthenticated, isLoading: authLoading } = useAuth({
    redirectOnUnauthenticated: true,
    redirectPath: LOGIN_PATH,
  });

  const { data: stats } = trpc.user.getStats.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: dashboard } = trpc.user.getDashboard.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: allCourses } = trpc.course.list.useQuery({});

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center">
        <div className="animate-pulse text-slate-400">Загрузка...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  const activeCourses = dashboard?.activeCourses || [];
  const hasCourses = activeCourses.length > 0;

  const statCards = [
    {
      icon: BookOpen,
      label: "Курсов куплено",
      value: stats?.coursesPurchased || 0,
      color: "text-[#8B5CF6]",
      bg: "bg-[#8B5CF6]/10",
    },
    {
      icon: GraduationCap,
      label: "Уроков пройдено",
      value: stats?.lessonsCompleted || 0,
      color: "text-emerald-400",
      bg: "bg-emerald-500/10",
    },
    {
      icon: Clock,
      label: "Часов обучения",
      value: stats?.hoursLearned || 0,
      color: "text-sky-400",
      bg: "bg-sky-500/10",
    },
    {
      icon: Award,
      label: "Сертификатов",
      value: stats?.certificates || 0,
      color: "text-amber-400",
      bg: "bg-amber-500/10",
    },
  ];

  return (
    <div className="min-h-screen bg-[#0A0A0F]">
      <Navbar />
      <div className="pt-24 pb-16 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-10">
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">
              Моё <span className="gradient-text">обучение</span>
            </h1>
            <p className="text-slate-400">
              Отслеживайте прогресс и продолжайте учиться
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
            {statCards.map((s, i) => (
              <div
                key={i}
                className="p-5 rounded-2xl bg-[#12121A] border border-white/[0.06]"
              >
                <div
                  className={`w-10 h-10 rounded-xl ${s.bg} flex items-center justify-center mb-3`}
                >
                  <s.icon className={`w-5 h-5 ${s.color}`} />
                </div>
                <div className="text-2xl font-bold text-white mb-1">
                  {s.value}
                </div>
                <div className="text-sm text-slate-500">{s.label}</div>
              </div>
            ))}
          </div>

          {/* Active courses */}
          {hasCourses && (
            <div className="mb-12">
              <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-[#8B5CF6]" />
                Активные курсы
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {activeCourses.map((course) => (
                  <CourseCard
                    key={course.id}
                    course={course}
                    showProgress
                    completedLessons={course.completedLessons}
                    totalLessons={course.totalLessons}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Empty state */}
          {!hasCourses && (
            <div className="mb-12 p-10 rounded-2xl bg-[#12121A] border border-white/[0.06] text-center">
              <div className="w-16 h-16 rounded-full bg-[#8B5CF6]/15 flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-[#8B5CF6]" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">
                Начните обучение
              </h3>
              <p className="text-slate-400 mb-6 max-w-md mx-auto">
                У вас пока нет купленных курсов. Выберите первый курс и начните
                осваивать нейросети.
              </p>
              <Link to="/courses">
                <button className="px-6 py-3 rounded-xl gradient-bg text-white font-medium hover:opacity-90 transition-opacity">
                  Выбрать курс
                </button>
              </Link>
            </div>
          )}

          {/* Recommended courses */}
          <div>
            <h2 className="text-xl font-bold text-white mb-6">
              Рекомендуемые курсы
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {(allCourses || [])
                .filter(
                  (c) => !activeCourses.find((ac) => ac.id === c.id)
                )
                .slice(0, 3)
                .map((course) => (
                  <CourseCard key={course.id} course={course} />
                ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
