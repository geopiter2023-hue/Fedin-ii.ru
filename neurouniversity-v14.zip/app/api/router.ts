import { authRouter } from "./auth-router";
import { courseRouter } from "./courseRouter";
import { lessonRouter } from "./lessonRouter";
import { purchaseRouter } from "./purchaseRouter";
import { userRouter } from "./userRouter";
import { seedRouter } from "./seedRouter";
import { aiRouter } from "./aiRouter";
import { certificateRouter } from "./certificateRouter";
import { reviewRouter } from "./reviewRouter";
import { referralRouter } from "./referralRouter";
import { emailRouter } from "./emailRouter";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  course: courseRouter,
  lesson: lessonRouter,
  purchase: purchaseRouter,
  user: userRouter,
  seed: seedRouter,
  ai: aiRouter,
  certificate: certificateRouter,
  review: reviewRouter,
  referral: referralRouter,
  email: emailRouter,
});

export type AppRouter = typeof appRouter;
