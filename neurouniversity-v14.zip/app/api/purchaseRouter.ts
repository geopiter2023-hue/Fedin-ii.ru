import { z } from "zod";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { purchases, courses } from "@db/schema";
import { eq, and } from "drizzle-orm";

export const purchaseRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userPurchases = await db
      .select({
        id: purchases.id,
        courseId: purchases.courseId,
        amount: purchases.amount,
        status: purchases.status,
        createdAt: purchases.createdAt,
        courseTitle: courses.title,
        courseSlug: courses.slug,
        courseImage: courses.image,
        courseLessonsCount: courses.lessonsCount,
      })
      .from(purchases)
      .innerJoin(courses, eq(purchases.courseId, courses.id))
      .where(
        and(
          eq(purchases.userId, ctx.user.id),
          eq(purchases.status, "completed")
        )
      );
    return userPurchases;
  }),

  getByCourse: authedQuery
    .input(z.object({ courseId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const [purchase] = await db
        .select()
        .from(purchases)
        .where(
          and(
            eq(purchases.userId, ctx.user.id),
            eq(purchases.courseId, input.courseId)
          )
        );
      return purchase || null;
    }),

  create: authedQuery
    .input(z.object({ courseId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [course] = await db
        .select()
        .from(courses)
        .where(eq(courses.id, input.courseId));

      if (!course) {
        throw new Error("Course not found");
      }

      const existing = await db
        .select()
        .from(purchases)
        .where(
          and(
            eq(purchases.userId, ctx.user.id),
            eq(purchases.courseId, input.courseId)
          )
        );

      if (existing.length > 0) {
        return existing[0];
      }

      const [newPurchase] = await db
        .insert(purchases)
        .values({
          userId: ctx.user.id,
          courseId: input.courseId,
          amount: course.price,
          status: "completed",
        })
        .$returningId();

      return db.query.purchases.findFirst({
        where: eq(purchases.id, newPurchase.id),
      });
    }),

  checkAccess: authedQuery
    .input(z.object({ courseId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const [purchase] = await db
        .select()
        .from(purchases)
        .where(
          and(
            eq(purchases.userId, ctx.user.id),
            eq(purchases.courseId, input.courseId),
            eq(purchases.status, "completed")
          )
        );
      return !!purchase;
    }),
});
