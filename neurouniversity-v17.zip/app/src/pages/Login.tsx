import { useState } from "react";
import { Link } from "react-router";
import { trpc } from "@/providers/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Brain,
  Sparkles,
  BookOpen,
  Users,
  Award,
  Zap,
  LogIn,
  UserPlus,
  Mail,
  Lock,
  User,
  ArrowRight,
  AlertCircle,
  CheckCircle,
} from "lucide-react";

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

const features = [
  { icon: BookOpen, text: "22 курса по нейросетям" },
  { icon: Users, text: "2500+ студентов" },
  { icon: Award, text: "Сертификаты о прохождении" },
  { icon: Zap, text: "Практические навыки без кода" },
];

export default function Login() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const loginMutation = trpc.localAuth.login.useMutation({
    onSuccess: (data) => {
      if (data.success && data.token) {
        localStorage.setItem("local_auth_token", data.token);
        setSuccess("Вход выполнен! Перенаправление...");
        setTimeout(() => window.location.href = "/dashboard", 500);
      } else {
        setError(data.error || "Ошибка входа");
      }
    },
    onError: (err) => setError(err.message),
  });

  const registerMutation = trpc.localAuth.register.useMutation({
    onSuccess: (data) => {
      if (data.success && data.token) {
        localStorage.setItem("local_auth_token", data.token);
        setSuccess("Регистрация успешна! Перенаправление...");
        setTimeout(() => window.location.href = "/dashboard", 500);
      } else {
        setError(data.error || "Ошибка регистрации");
      }
    },
    onError: (err) => setError(err.message),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (mode === "login") {
      loginMutation.mutate({ email, password });
    } else {
      if (!name.trim()) {
        setError("Введите имя");
        return;
      }
      if (password.length < 6) {
        setError("Пароль должен быть минимум 6 символов");
        return;
      }
      registerMutation.mutate({ email, password, name });
    }
  };

  const isPending = loginMutation.isPending || registerMutation.isPending;

  return (
    <div className="min-h-screen bg-[#0A0A0F] text-white">
      <div className="max-w-6xl mx-auto px-4 py-8 min-h-screen flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between mb-12">
          <Link to="/" className="flex items-center gap-2">
            <Brain className="w-8 h-8 text-[#8B5CF6]" />
            <span className="text-xl font-bold">
              Нейро<span className="gradient-text">Университет</span>
            </span>
          </Link>
          <Link
            to="/"
            className="text-sm text-slate-400 hover:text-white transition-colors flex items-center gap-1"
          >
            <ArrowRight className="w-4 h-4 rotate-180" />
            На главную
          </Link>
        </div>

        <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left — Info */}
          <div className="space-y-8">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
                {mode === "login" ? (
                  <>
                    Вход в <span className="gradient-text">НейроУниверситет</span>
                  </>
                ) : (
                  <>
                    Регистрация в <span className="gradient-text">НейроУниверситет</span>
                  </>
                )}
              </h1>
              <p className="text-lg text-slate-400 leading-relaxed max-w-lg">
                Осваивайте нейросети вместе с тысячами студентов. Понятные курсы,
                AI-консультант, сертификаты и постоянные обновления.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {features.map((f, i) => (
                <div
                  key={i}
                  className="flex items-center gap-3 p-4 rounded-xl bg-[#12121A] border border-white/[0.06]"
                >
                  <div className="w-10 h-10 rounded-lg gradient-bg flex items-center justify-center shrink-0">
                    <f.icon className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-sm text-slate-300">{f.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right — Auth form */}
          <div className="lg:pl-8">
            <Card className="bg-[#12121A] border-white/[0.06]">
              <CardContent className="p-8">
                {/* Mode toggle */}
                <div className="flex gap-1 p-1 rounded-xl bg-[#0A0A0F] border border-white/[0.06] mb-6">
                  <button
                    onClick={() => { setMode("login"); setError(""); setSuccess(""); }}
                    className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2 ${
                      mode === "login"
                        ? "bg-[#8B5CF6] text-white"
                        : "text-slate-400 hover:text-white"
                    }`}
                  >
                    <LogIn className="w-4 h-4" />
                    Вход
                  </button>
                  <button
                    onClick={() => { setMode("register"); setError(""); setSuccess(""); }}
                    className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2 ${
                      mode === "register"
                        ? "bg-[#8B5CF6] text-white"
                        : "text-slate-400 hover:text-white"
                    }`}
                  >
                    <UserPlus className="w-4 h-4" />
                    Регистрация
                  </button>
                </div>

                {/* Messages */}
                {error && (
                  <div className="flex items-center gap-2 text-sm p-3 rounded-lg bg-red-500/10 text-red-400 mb-4">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    {error}
                  </div>
                )}
                {success && (
                  <div className="flex items-center gap-2 text-sm p-3 rounded-lg bg-green-500/10 text-green-400 mb-4">
                    <CheckCircle className="w-4 h-4 shrink-0" />
                    {success}
                  </div>
                )}

                {/* Form */}
                <form onSubmit={handleSubmit} className="space-y-4">
                  {mode === "register" && (
                    <div>
                      <label className="block text-sm text-slate-400 mb-1.5">Имя</label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                        <Input
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="Ваше имя"
                          className="pl-10 bg-[#0A0A0F] border-white/[0.06] text-white"
                        />
                      </div>
                    </div>
                  )}
                  <div>
                    <label className="block text-sm text-slate-400 mb-1.5">Email</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                      <Input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="your@email.com"
                        className="pl-10 bg-[#0A0A0F] border-white/[0.06] text-white"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm text-slate-400 mb-1.5">Пароль</label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                      <Input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder={mode === "register" ? "Минимум 6 символов" : "Ваш пароль"}
                        className="pl-10 bg-[#0A0A0F] border-white/[0.06] text-white"
                        required
                      />
                    </div>
                  </div>
                  <Button
                    type="submit"
                    disabled={isPending}
                    className="w-full gradient-bg text-white hover:opacity-90 py-6"
                  >
                    {isPending
                      ? "Загрузка..."
                      : mode === "login"
                        ? "Войти"
                        : "Создать аккаунт"}
                  </Button>
                </form>

                {/* Divider */}
                <div className="flex items-center gap-4 my-6">
                  <div className="flex-1 h-px bg-white/[0.06]" />
                  <span className="text-xs text-slate-600">или</span>
                  <div className="flex-1 h-px bg-white/[0.06]" />
                </div>

                {/* OAuth */}
                <Button
                  variant="outline"
                  className="w-full border-[#8B5CF6]/30 text-[#8B5CF6] hover:bg-[#8B5CF6]/10"
                  onClick={() => {
                    window.location.href = getOAuthUrl();
                  }}
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Войти через Kimi
                </Button>

                {/* Browse without login */}
                <div className="mt-6 text-center">
                  <Link
                    to="/courses"
                    className="text-sm text-slate-500 hover:text-[#8B5CF6] transition-colors"
                  >
                    Смотреть курсы без входа
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/[0.06] text-center">
          <p className="text-sm text-slate-600">
            НейроУниверситет 2025. Все права защищены.
          </p>
        </div>
      </div>
    </div>
  );
}
