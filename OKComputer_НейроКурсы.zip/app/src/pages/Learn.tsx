import { useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import {
  CheckCircle,
  Lock,
  PlayCircle,
  ChevronLeft,
  ChevronRight,
  BookOpen,
  ArrowLeft,
  Circle,
} from "lucide-react";

export default function Learn() {
  const { courseSlug, lessonId } = useParams<{
    courseSlug: string;
    lessonId?: string;
  }>();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  const { data: course } = trpc.course.getBySlug.useQuery(
    { slug: courseSlug || "" },
    { enabled: !!courseSlug }
  );

  const { data: lessonsList } = trpc.course.getLessons.useQuery(
    { courseId: course?.id || 0 },
    { enabled: !!course?.id }
  );

  const { data: hasAccess } = trpc.purchase.checkAccess.useQuery(
    { courseId: course?.id || 0 },
    { enabled: !!course?.id && isAuthenticated }
  );

  const { data: progressData } = trpc.lesson.getProgress.useQuery(
    { courseId: course?.id || 0 },
    { enabled: !!course?.id && isAuthenticated }
  );

  const utils = trpc.useUtils();
  const markComplete = trpc.lesson.markComplete.useMutation({
    onSuccess: () => {
      utils.lesson.getProgress.invalidate();
      utils.user.getDashboard.invalidate();
    },
  });

  const completedLessonIds = new Set(
    progressData?.lessons.filter((l) => l.isCompleted).map((l) => l.id) || []
  );

  const currentLessonId = lessonId
    ? parseInt(lessonId)
    : lessonsList?.[0]?.id;

  const currentLesson = lessonsList?.find((l) => l.id === currentLessonId);

  const currentIndex =
    lessonsList?.findIndex((l) => l.id === currentLessonId) ?? -1;
  const prevLesson = currentIndex > 0 ? lessonsList?.[currentIndex - 1] : null;
  const nextLesson =
    currentIndex < (lessonsList?.length ?? 0) - 1
      ? lessonsList?.[currentIndex + 1]
      : null;

  const canAccess =
    hasAccess || currentLesson?.isFree;

  useEffect(() => {
    if (courseSlug && lessonsList && lessonsList.length > 0 && !lessonId) {
      navigate(`/learn/${courseSlug}/${lessonsList[0].id}`, { replace: true });
    }
  }, [courseSlug, lessonsList, lessonId, navigate]);

  if (!course || !lessonsList) {
    return (
      <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center">
        <div className="animate-pulse text-slate-400">Загрузка...</div>
      </div>
    );
  }

  const progressPercent = progressData?.completionRate || 0;

  return (
    <div className="min-h-screen bg-[#0A0A0F] flex">
      {/* Sidebar */}
      <aside className="w-80 shrink-0 border-r border-white/[0.06] bg-[#0D0D14] overflow-y-auto h-screen sticky top-0 hidden lg:block">
        <div className="p-4">
          <Link
            to={`/courses/${course.slug}`}
            className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-white mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            Назад к курсу
          </Link>

          <h3 className="text-sm font-semibold text-white mb-1 line-clamp-2">
            {course.title}
          </h3>

          {/* Progress */}
          <div className="mb-4">
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-slate-400">
                {progressData?.completedLessons || 0} /{" "}
                {progressData?.totalLessons || lessonsList.length} уроков
              </span>
              <span className="text-[#8B5CF6]">{progressPercent}%</span>
            </div>
            <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full gradient-bg transition-all duration-700"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Lessons list */}
          <div className="space-y-1">
            {lessonsList.map((lesson) => {
              const isActive = lesson.id === currentLessonId;
              const isCompleted = completedLessonIds.has(lesson.id);
              const lessonAccessible = hasAccess || lesson.isFree;

              return (
                <button
                  key={lesson.id}
                  onClick={() => {
                    if (lessonAccessible) {
                      navigate(`/learn/${courseSlug}/${lesson.id}`);
                    }
                  }}
                  disabled={!lessonAccessible}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all ${
                    isActive
                      ? "bg-[#8B5CF6]/15 border-l-2 border-[#8B5CF6]"
                      : "hover:bg-white/5 border-l-2 border-transparent"
                  } ${!lessonAccessible ? "opacity-50 cursor-not-allowed" : ""}`}
                >
                  <div className="shrink-0">
                    {isCompleted ? (
                      <CheckCircle className="w-5 h-5 text-emerald-400" />
                    ) : isActive ? (
                      <PlayCircle className="w-5 h-5 text-[#8B5CF6]" />
                    ) : lessonAccessible ? (
                      <Circle className="w-5 h-5 text-slate-600" />
                    ) : (
                      <Lock className="w-5 h-5 text-slate-600" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p
                      className={`text-sm truncate ${
                        isActive ? "text-white font-medium" : "text-slate-400"
                      }`}
                    >
                      {lesson.order}. {lesson.title}
                    </p>
                    <span className="text-xs text-slate-600">
                      {lesson.duration}
                    </span>
                  </div>
                  {lesson.isFree && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-500/15 text-emerald-400 shrink-0">
                      Free
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 min-h-screen">
        {/* Mobile header */}
        <div className="lg:hidden p-4 border-b border-white/[0.06] bg-[#0D0D14]">
          <Link
            to={`/courses/${course.slug}`}
            className="inline-flex items-center gap-1 text-sm text-slate-400 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4" />
            {course.title}
          </Link>
        </div>

        {currentLesson ? (
          <div className="p-4 md:p-8 max-w-4xl">
            {/* Video placeholder */}
            <div className="relative aspect-video rounded-2xl bg-[#12121A] border border-white/[0.06] overflow-hidden mb-6 flex items-center justify-center">
              {canAccess ? (
                <div className="text-center">
                  <div className="w-20 h-20 rounded-full gradient-bg flex items-center justify-center mx-auto mb-4">
                    <PlayCircle className="w-10 h-10 text-white" />
                  </div>
                  <p className="text-white font-medium mb-1">
                    {currentLesson.title}
                  </p>
                  <p className="text-sm text-slate-500">
                    Длительность: {currentLesson.duration}
                  </p>
                  {!hasAccess && currentLesson.isFree && (
                    <p className="text-xs text-emerald-400 mt-2">
                      Бесплатный урок
                    </p>
                  )}
                </div>
              ) : (
                <div className="text-center">
                  <Lock className="w-12 h-12 text-slate-600 mx-auto mb-4" />
                  <p className="text-white font-medium mb-2">
                    Урок заблокирован
                  </p>
                  <p className="text-sm text-slate-500 mb-4">
                    Купите курс, чтобы получить доступ ко всем урокам
                  </p>
                  <Link
                    to={`/courses/${course.slug}`}
                    className="px-6 py-2.5 rounded-xl gradient-bg text-white text-sm font-medium hover:opacity-90 transition-opacity"
                  >
                    Купить курс
                  </Link>
                </div>
              )}
            </div>

            {/* Lesson info */}
            <div className="mb-8">
              <div className="flex items-center gap-3 mb-3">
                <span className="px-2.5 py-1 rounded-lg bg-[#8B5CF6]/15 text-[#8B5CF6] text-xs font-medium">
                  Урок {currentLesson.order}
                </span>
                <span className="text-xs text-slate-500">
                  {currentLesson.duration}
                </span>
              </div>
              <h1 className="text-2xl font-bold text-white mb-4">
                {currentLesson.title}
              </h1>
              <div className="prose prose-invert max-w-none">
                <div className="text-slate-300 leading-relaxed whitespace-pre-line">
                  {currentLesson.content}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-6 border-t border-white/[0.06]">
              {canAccess && (
                <button
                  onClick={() => {
                    if (!completedLessonIds.has(currentLesson.id)) {
                      markComplete.mutate({ lessonId: currentLesson.id });
                    }
                  }}
                  disabled={
                    completedLessonIds.has(currentLesson.id) ||
                    markComplete.isPending
                  }
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    completedLessonIds.has(currentLesson.id)
                      ? "bg-emerald-500/15 text-emerald-400"
                      : "gradient-bg text-white hover:opacity-90"
                  }`}
                >
                  <CheckCircle className="w-4 h-4" />
                  {completedLessonIds.has(currentLesson.id)
                    ? "Урок пройден"
                    : "Отметить как пройденный"}
                </button>
              )}

              <div className="flex items-center gap-3">
                {prevLesson && (
                  <button
                    onClick={() =>
                      navigate(`/learn/${courseSlug}/${prevLesson.id}`)
                    }
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#12121A] border border-white/[0.06] text-sm text-slate-400 hover:text-white transition-colors"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    Предыдущий
                  </button>
                )}
                {nextLesson && (
                  <button
                    onClick={() =>
                      navigate(`/learn/${courseSlug}/${nextLesson.id}`)
                    }
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#12121A] border border-white/[0.06] text-sm text-slate-400 hover:text-white transition-colors"
                  >
                    Следующий
                    <ChevronRight className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Mobile lesson navigation */}
            <div className="lg:hidden mt-8">
              <h4 className="text-sm font-medium text-white mb-3">
                Уроки курса
              </h4>
              <div className="space-y-1 max-h-64 overflow-y-auto">
                {lessonsList.map((lesson) => {
                  const isActive = lesson.id === currentLessonId;
                  const isCompleted = completedLessonIds.has(lesson.id);
                  return (
                    <button
                      key={lesson.id}
                      onClick={() => {
                        if (hasAccess || lesson.isFree) {
                          navigate(`/learn/${courseSlug}/${lesson.id}`);
                        }
                      }}
                      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left ${
                        isActive ? "bg-[#8B5CF6]/15" : "hover:bg-white/5"
                      }`}
                    >
                      {isCompleted ? (
                        <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                      ) : (
                        <BookOpen className="w-4 h-4 text-slate-600 shrink-0" />
                      )}
                      <span
                        className={`text-sm truncate ${
                          isActive ? "text-white" : "text-slate-400"
                        }`}
                      >
                        {lesson.order}. {lesson.title}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center h-64">
            <p className="text-slate-400">Урок не найден</p>
          </div>
        )}
      </main>
    </div>
  );
}
