import { useState } from "react";
import { Link, useLocation } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  Brain,
  Menu,
  X,
  GraduationCap,
  LayoutDashboard,
  LogOut,
  User,
} from "lucide-react";

export default function Navbar() {
  const { user, isAuthenticated, logout } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 h-16 glass">
      <div className="max-w-7xl mx-auto px-4 h-full flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 shrink-0">
          <Brain className="w-7 h-7 text-[#8B5CF6]" />
          <span className="text-lg font-bold text-white hidden sm:block">
            Нейро<span className="gradient-text">Университет</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-6">
          <Link
            to="/courses"
            className={`text-sm transition-colors ${
              isActive("/courses")
                ? "text-[#8B5CF6]"
                : "text-slate-400 hover:text-white"
            }`}
          >
            Курсы
          </Link>
          <Link
            to="/"
            className={`text-sm transition-colors ${
              isActive("/") ? "text-[#8B5CF6]" : "text-slate-400 hover:text-white"
            }`}
          >
            Главная
          </Link>
          {isAuthenticated && (
            <Link
              to="/dashboard"
              className={`text-sm transition-colors ${
                isActive("/dashboard")
                  ? "text-[#8B5CF6]"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Моё обучение
            </Link>
          )}
        </div>

        {/* Auth */}
        <div className="hidden md:flex items-center gap-3">
          {isAuthenticated ? (
            <div className="flex items-center gap-3">
              <Link to="/dashboard">
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
                  {user?.avatar ? (
                    <img
                      src={user.avatar}
                      alt=""
                      className="w-6 h-6 rounded-full"
                    />
                  ) : (
                    <User className="w-5 h-5 text-slate-400" />
                  )}
                  <span className="text-sm text-slate-300">
                    {user?.name || "Пользователь"}
                  </span>
                </div>
              </Link>
              <Button
                variant="ghost"
                size="sm"
                onClick={logout}
                className="text-slate-400 hover:text-white"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          ) : (
            <Link to="/login">
              <Button
                size="sm"
                className="gradient-bg text-white border-0 hover:opacity-90"
              >
                Войти
              </Button>
            </Link>
          )}
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden text-white"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden glass border-t border-white/5">
          <div className="px-4 py-4 space-y-3">
            <Link
              to="/courses"
              className="flex items-center gap-2 text-slate-300 hover:text-white"
              onClick={() => setMenuOpen(false)}
            >
              <GraduationCap className="w-4 h-4" />
              Курсы
            </Link>
            <Link
              to="/"
              className="flex items-center gap-2 text-slate-300 hover:text-white"
              onClick={() => setMenuOpen(false)}
            >
              <Brain className="w-4 h-4" />
              Главная
            </Link>
            {isAuthenticated && (
              <Link
                to="/dashboard"
                className="flex items-center gap-2 text-slate-300 hover:text-white"
                onClick={() => setMenuOpen(false)}
              >
                <LayoutDashboard className="w-4 h-4" />
                Моё обучение
              </Link>
            )}
            {isAuthenticated ? (
              <button
                onClick={() => {
                  logout();
                  setMenuOpen(false);
                }}
                className="flex items-center gap-2 text-slate-400 hover:text-white"
              >
                <LogOut className="w-4 h-4" />
                Выйти
              </button>
            ) : (
              <Link
                to="/login"
                className="flex items-center gap-2 text-[#8B5CF6]"
                onClick={() => setMenuOpen(false)}
              >
                <User className="w-4 h-4" />
                Войти
              </Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
