import { authRouter } from "./auth-router";
import { courseRouter } from "./courseRouter";
import { lessonRouter } from "./lessonRouter";
import { purchaseRouter } from "./purchaseRouter";
import { userRouter } from "./userRouter";
import { seedRouter } from "./seedRouter";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  course: courseRouter,
  lesson: lessonRouter,
  purchase: purchaseRouter,
  user: userRouter,
  seed: seedRouter,
});

export type AppRouter = typeof appRouter;
